/**
 * Sistema de Tracking de Sesión
 * Evita la repetición de cartas y variantes en una misma sesión
 */

import { Variant } from './tarotDatabase';

export interface SessionCard {
  cardId: string;
  section: string;
  variant: Variant;
  timestamp: number;
  sign?: string;
}

export interface SessionHistory {
  cards: SessionCard[];
  startTime: number;
  lastUpdate: number;
}

const SESSION_STORAGE_KEY = 'tarot_session_history';
const SESSION_TIMEOUT = 30 * 60 * 1000; // 30 minutos

/**
 * Gestor de historial de sesión
 */
export class SessionTracker {
  private history: SessionHistory;

  constructor() {
    this.history = this.loadHistory();
  }

  /**
   * Cargar historial de sesión desde sessionStorage
   */
  private loadHistory(): SessionHistory {
    try {
      const stored = sessionStorage.getItem(SESSION_STORAGE_KEY);
      if (stored) {
        const parsed = JSON.parse(stored) as SessionHistory;
        
        // Verificar si la sesión ha expirado
        if (Date.now() - parsed.lastUpdate > SESSION_TIMEOUT) {
          return this.createNewHistory();
        }
        
        return parsed;
      }
    } catch (error) {
      console.warn('Error al cargar historial de sesión:', error);
    }

    return this.createNewHistory();
  }

  /**
   * Crear un nuevo historial de sesión
   */
  private createNewHistory(): SessionHistory {
    return {
      cards: [],
      startTime: Date.now(),
      lastUpdate: Date.now(),
    };
  }

  /**
   * Guardar historial en sessionStorage
   */
  private saveHistory(): void {
    try {
      this.history.lastUpdate = Date.now();
      sessionStorage.setItem(SESSION_STORAGE_KEY, JSON.stringify(this.history));
    } catch (error) {
      console.warn('Error al guardar historial de sesión:', error);
    }
  }

  /**
   * Registrar una carta mostrada
   */
  recordCard(cardId: string, section: string, variant: Variant, sign?: string): void {
    const sessionCard: SessionCard = {
      cardId,
      section,
      variant,
      timestamp: Date.now(),
      sign,
    };

    this.history.cards.push(sessionCard);
    this.saveHistory();
  }

  /**
   * Verificar si una carta ya fue mostrada en esta sección
   */
  hasCardBeenShown(cardId: string, section: string): boolean {
    return this.history.cards.some(
      card => card.cardId === cardId && card.section === section
    );
  }

  /**
   * Obtener variantes ya usadas para una carta en una sección
   */
  getUsedVariants(cardId: string, section: string): Variant[] {
    return this.history.cards
      .filter(card => card.cardId === cardId && card.section === section)
      .map(card => card.variant);
  }

  /**
   * Obtener la variante recomendada (la que menos se ha usado)
   */
  getRecommendedVariant(cardId: string, section: string): Variant {
    const usedVariants = this.getUsedVariants(cardId, section);
    const allVariants: Variant[] = ['luz', 'sombra', 'equilibrio'];

    // Encontrar la variante que menos se ha usado
    const variantCounts = allVariants.map(v => ({
      variant: v,
      count: usedVariants.filter(used => used === v).length,
    }));

    variantCounts.sort((a, b) => a.count - b.count);

    // Si hay un empate, seleccionar aleatoriamente entre los menos usados
    const minCount = variantCounts[0].count;
    const leastUsed = variantCounts.filter(v => v.count === minCount);

    return leastUsed[Math.floor(Math.random() * leastUsed.length)].variant;
  }

  /**
   * Obtener cartas mostradas recientemente (últimas N)
   */
  getRecentCards(limit: number = 10): SessionCard[] {
    return this.history.cards.slice(-limit);
  }

  /**
   * Limpiar historial de sesión
   */
  clearHistory(): void {
    this.history = this.createNewHistory();
    sessionStorage.removeItem(SESSION_STORAGE_KEY);
  }

  /**
   * Obtener estadísticas de la sesión
   */
  getSessionStats(): {
    totalCards: number;
    uniqueCards: number;
    sessionDuration: number;
    cardsBySection: Record<string, number>;
  } {
    const totalCards = this.history.cards.length;
    const uniqueCards = new Set(this.history.cards.map(c => c.cardId)).size;
    const sessionDuration = Date.now() - this.history.startTime;

    const cardsBySection: Record<string, number> = {};
    this.history.cards.forEach(card => {
      cardsBySection[card.section] = (cardsBySection[card.section] || 0) + 1;
    });

    return {
      totalCards,
      uniqueCards,
      sessionDuration,
      cardsBySection,
    };
  }

  /**
   * Obtener historial completo
   */
  getHistory(): SessionHistory {
    return this.history;
  }

  /**
   * Verificar si la sesión está activa
   */
  isSessionActive(): boolean {
    return Date.now() - this.history.lastUpdate < SESSION_TIMEOUT;
  }

  /**
   * Obtener tiempo restante de sesión
   */
  getSessionTimeRemaining(): number {
    const elapsed = Date.now() - this.history.lastUpdate;
    return Math.max(0, SESSION_TIMEOUT - elapsed);
  }
}

/**
 * Instancia global del tracker de sesión
 */
export const sessionTracker = new SessionTracker();

/**
 * Hook para usar el tracker en componentes React
 */
export function useSessionTracker() {
  return {
    recordCard: (cardId: string, section: string, variant: Variant, sign?: string) =>
      sessionTracker.recordCard(cardId, section, variant, sign),
    hasCardBeenShown: (cardId: string, section: string) =>
      sessionTracker.hasCardBeenShown(cardId, section),
    getUsedVariants: (cardId: string, section: string) =>
      sessionTracker.getUsedVariants(cardId, section),
    getRecommendedVariant: (cardId: string, section: string) =>
      sessionTracker.getRecommendedVariant(cardId, section),
    getRecentCards: (limit?: number) =>
      sessionTracker.getRecentCards(limit),
    clearHistory: () =>
      sessionTracker.clearHistory(),
    getSessionStats: () =>
      sessionTracker.getSessionStats(),
    isSessionActive: () =>
      sessionTracker.isSessionActive(),
    getSessionTimeRemaining: () =>
      sessionTracker.getSessionTimeRemaining(),
  };
}
