
// Motor de Inteligencia Esotérica Simulada
// Genera lecturas personalizadas y "humanas" combinando datos del usuario con bases de conocimiento.

interface UserContext {
  name?: string;
  sign?: string;
  question?: string;
  intention?: string;
}

export const personalizeReading = (baseText: string, context: UserContext, type: 'tarot' | 'astro' | 'ritual' | 'numero'): string => {
  const { name, sign, question, intention } = context;
  const cleanName = name ? name.trim() : "Consultante";
  
  // Frases de conexión "Cold Reading" (Lectura en frío)
  const intros = [
    `Sintonizando con tu energía, ${cleanName}...`,
    `Veo en tu aura una vibración muy particular hoy, ${cleanName}.`,
    `Los guías me muestran algo interesante para ti, ${cleanName}.`,
    `Es curioso que preguntes esto, ${cleanName}, porque las cartas indican...`,
    `${cleanName}, el universo ha estado esperando este momento para decirte:`
  ];

  const connectors = [
    "Esto resuena profundamente con tu situación actual.",
    "No es coincidencia que esta respuesta llegue a ti ahora.",
    "Toma esto como una señal clara del destino.",
    "Tu intuición ya te estaba susurrando esto, ¿verdad?",
    "Observa cómo esto se alinea con lo que has estado sintiendo."
  ];

  const signSpecifics: Record<string, string> = {
    aries: "Tu naturaleza de fuego te pide acción inmediata.",
    tauro: "Tu paciencia de tierra será tu mejor aliada aquí.",
    geminis: "Tu mente rápida ya está conectando los puntos.",
    cancer: "Tu intuición emocional no se equivoca.",
    leo: "Tu luz interior necesita brillar en este asunto.",
    virgo: "Tu capacidad de análisis te dará la clave.",
    libra: "El equilibrio que buscas está más cerca de lo que crees.",
    escorpio: "Tu intensidad te permitirá transformar esta situación.",
    sagitario: "Tu optimismo abrirá las puertas correctas.",
    capricornio: "Tu perseverancia está a punto de dar frutos.",
    acuario: "Tu visión única es necesaria para resolver esto.",
    piscis: "Confía en lo que sientes, no solo en lo que ves."
  };

  // Selección aleatoria de frases
  const randomIntro = intros[Math.floor(Math.random() * intros.length)];
  const randomConnector = connectors[Math.floor(Math.random() * connectors.length)];
  const signAdvice = sign && signSpecifics[sign.toLowerCase()] ? signSpecifics[sign.toLowerCase()] : "";

  // Construcción de la respuesta "Inteligente"
  let finalReading = "";

  if (type === 'tarot') {
    finalReading = `${randomIntro} ${baseText} ${question ? `Específicamente sobre tu duda de "${question}", ` : ""} ${signAdvice} ${randomConnector}`;
  } else if (type === 'astro') {
    finalReading = `Hola ${cleanName}. ${signAdvice} Analizando los astros para ti: ${baseText} ${randomConnector}`;
  } else if (type === 'ritual') {
    finalReading = `${cleanName}, para tu intención de "${intention || 'bienestar'}", he canalizado este ritual específico. ${baseText} Realízalo con fe.`;
  } else {
    finalReading = `${randomIntro} ${baseText} ${signAdvice}`;
  }

  return finalReading;
};

export const generateMysticalLoadingMessage = (): string => {
  const messages = [
    "Conectando con el campo mórfico...",
    "Alineando chakras...",
    "Consultando los registros Akáshicos...",
    "Interpretando las señales del universo...",
    "Sintonizando frecuencia vibratoria...",
    "Desvelando el velo del destino...",
    "Recibiendo transmisión de los guías..."
  ];
  return messages[Math.floor(Math.random() * messages.length)];
};
