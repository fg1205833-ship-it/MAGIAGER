/**
 * Motor de Inteligencia Esotérica Avanzado V2
 * 
 * Genera lecturas profundas, contextuales y personalizadas basadas en:
 * - Análisis de la pregunta del usuario
 * - Signo zodiacal y elemento
 * - Tipo de carta y su significado
 * - Variantes semánticas (Luz/Sombra/Equilibrio)
 * - Historial de sesión para evitar repeticiones
 */

import {
  TarotType,
  Section,
  Variant,
  ZodiacSign,
  Element,
  CardInterpretation,
  ZODIAC_TO_ELEMENT,
  ZODIAC_CHARACTERISTICS,
  ELEMENT_CHARACTERISTICS,
  tarotDB,
} from './tarotDatabase';
import { sessionTracker } from './sessionTracking';

/**
 * Contexto de usuario para personalización
 */
export interface UserContext {
  name?: string;
  sign?: ZodiacSign;
  question?: string;
  intention?: string;
  email?: string;
}

/**
 * Análisis de pregunta
 */
export interface QuestionAnalysis {
  intent: Section;
  sentiment: 'positivo' | 'negativo' | 'neutral';
  urgency: 'inmediata' | 'corto_plazo' | 'largo_plazo';
  keywords: string[];
  confidence: number;
}

/**
 * Resultado de generación de lectura
 */
export interface ReadingResult {
  cardId: string;
  cardName: string;
  section: Section;
  variant: Variant;
  interpretation: CardInterpretation;
  personalizedText: string;
  analysis: QuestionAnalysis;
  signInfluence: string;
  elementalGuidance: string;
}

/**
 * Palabras clave para detectar intención
 */
const INTENT_KEYWORDS: Record<Section, string[]> = {
  mesa: ['general', 'situación', 'qué', 'cómo', 'cuándo', 'dónde'],
  amor: ['amor', 'pareja', 'relación', 'romance', 'enamorado', 'crush', 'ex', 'matrimonio', 'boda', 'corazón'],
  dinero: ['dinero', 'dinero', 'finanzas', 'inversión', 'negocio', 'trabajo', 'salario', 'ganancias', 'pérdidas', 'deuda'],
  trabajo: ['trabajo', 'empleo', 'carrera', 'profesión', 'jefe', 'empresa', 'negocio', 'proyecto', 'ascenso', 'despido'],
  salud: ['salud', 'enfermedad', 'médico', 'hospital', 'medicina', 'dolor', 'bienestar', 'cuerpo', 'mente'],
  decisiones: ['decidir', 'decisión', 'elegir', 'opción', 'camino', 'alternativa', 'duda', 'confusión'],
  consejo: ['consejo', 'qué hacer', 'recomendación', 'guía', 'ayuda', 'orientación'],
  pasado_presente_futuro: ['pasado', 'presente', 'futuro', 'antes', 'ahora', 'después', 'ayer', 'hoy', 'mañana'],
};

/**
 * Palabras clave para detectar sentimiento
 */
const SENTIMENT_KEYWORDS = {
  positivo: ['bien', 'bueno', 'feliz', 'alegre', 'esperanza', 'amor', 'éxito', 'fortuna', 'bendición'],
  negativo: ['mal', 'malo', 'triste', 'miedo', 'dolor', 'pérdida', 'fracaso', 'desgracia', 'maldición'],
};

/**
 * Palabras clave para detectar urgencia
 */
const URGENCY_KEYWORDS = {
  inmediata: ['ahora', 'hoy', 'urgente', 'inmediato', 'pronto', 'ya', 'rápido'],
  corto_plazo: ['semana', 'mes', 'pronto', 'próximo', 'cerca'],
  largo_plazo: ['año', 'futuro', 'largo', 'siempre', 'destino'],
};

/**
 * Frases de conexión personalizadas por elemento
 */
const ELEMENT_INTROS: Record<Element, string[]> = {
  fuego: [
    'Tu energía de fuego arde con intensidad en este momento.',
    'Las llamas de tu pasión iluminan el camino.',
    'Tu naturaleza ardiente te impulsa hacia la acción.',
    'El fuego de tu espíritu te guía en esta dirección.',
  ],
  tierra: [
    'Tu solidez de tierra te mantiene anclado en la realidad.',
    'Las raíces de tu ser se profundizan en esta situación.',
    'Tu naturaleza práctica te ofrece estabilidad.',
    'La tierra bajo tus pies te proporciona seguridad.',
  ],
  aire: [
    'Tu mente aérea vuela alto en busca de respuestas.',
    'Las brisas del pensamiento te rodean.',
    'Tu naturaleza intelectual analiza cada detalle.',
    'El aire de la verdad se revela ante ti.',
  ],
  agua: [
    'Tus aguas emocionales fluyen profundamente.',
    'Tu intuición nada en las corrientes del universo.',
    'Tu naturaleza sensible percibe lo invisible.',
    'Las olas de tu intuición te guían.',
  ],
};

/**
 * Conectores contextuales
 */
const CONTEXTUAL_CONNECTORS: Record<Variant, string[]> = {
  luz: [
    'Esta es la oportunidad que buscas.',
    'La luz te muestra el camino correcto.',
    'Las energías positivas fluyen hacia ti.',
    'Este es tu momento de brillo.',
  ],
  sombra: [
    'Presta atención a las sombras ocultas.',
    'Hay lecciones en las dificultades.',
    'Lo que se oculta merece ser explorado.',
    'Las sombras revelan verdades profundas.',
  ],
  equilibrio: [
    'El balance es la clave en este momento.',
    'Integra los opuestos para encontrar paz.',
    'La armonía surge del equilibrio.',
    'Ambos lados de la moneda tienen valor.',
  ],
};

/**
 * Clase para el motor de inteligencia avanzado
 */
export class IntelligenceEngineV2 {
  /**
   * Analizar la pregunta del usuario
   */
  analyzeQuestion(question?: string): QuestionAnalysis {
    const questionLower = (question || '').toLowerCase();
    let intent: Section = 'mesa';
    let sentiment: 'positivo' | 'negativo' | 'neutral' = 'neutral';
    let urgency: 'inmediata' | 'corto_plazo' | 'largo_plazo' = 'largo_plazo';
    const keywords: string[] = [];
    let confidence = 0.5;

    // Detectar intención
    for (const [section, words] of Object.entries(INTENT_KEYWORDS)) {
      const matches = words.filter(word => questionLower.includes(word)).length;
      if (matches > 0) {
        intent = section as Section;
        confidence = Math.min(1, 0.5 + matches * 0.15);
        keywords.push(...words.filter(w => questionLower.includes(w)));
        break;
      }
    }

    // Detectar sentimiento
    const positiveMatches = SENTIMENT_KEYWORDS.positivo.filter(word =>
      questionLower.includes(word)
    ).length;
    const negativeMatches = SENTIMENT_KEYWORDS.negativo.filter(word =>
      questionLower.includes(word)
    ).length;

    if (positiveMatches > negativeMatches) {
      sentiment = 'positivo';
    } else if (negativeMatches > positiveMatches) {
      sentiment = 'negativo';
    }

    // Detectar urgencia
    if (URGENCY_KEYWORDS.inmediata.some(word => questionLower.includes(word))) {
      urgency = 'inmediata';
    } else if (URGENCY_KEYWORDS.corto_plazo.some(word => questionLower.includes(word))) {
      urgency = 'corto_plazo';
    }

    return {
      intent,
      sentiment,
      urgency,
      keywords: [...new Set(keywords)],
      confidence,
    };
  }

  /**
   * Seleccionar la variante más apropiada
   */
  selectVariant(
    cardId: string,
    section: Section,
    analysis: QuestionAnalysis,
    sign?: ZodiacSign
  ): Variant {
    // Primero, intentar usar la variante recomendada por el tracker
    const recommendedVariant = sessionTracker.getRecommendedVariant(cardId, section);

    // Si ya se ha mostrado esta carta en esta sección, usar la variante recomendada
    if (sessionTracker.hasCardBeenShown(cardId, section)) {
      return recommendedVariant;
    }

    // Si no se ha mostrado, seleccionar basado en el análisis
    if (analysis.sentiment === 'positivo') {
      return 'luz';
    } else if (analysis.sentiment === 'negativo') {
      return 'sombra';
    } else {
      return 'equilibrio';
    }
  }

  /**
   * Generar influencia del signo zodiacal
   */
  generateSignInfluence(sign: ZodiacSign, section: Section, variant: Variant): string {
    const characteristics = ZODIAC_CHARACTERISTICS[sign];
    if (!characteristics) return '';

    const element = ZODIAC_TO_ELEMENT[sign];
    const elementTraits = ELEMENT_CHARACTERISTICS[element].traits;

    const influences: Record<Variant, string[]> = {
      luz: [
        `Tu ${characteristics.traits[0]} naturaleza ${sign} te permite ver la oportunidad aquí.`,
        `${characteristics.strengths[0]} es tu fortaleza en este momento.`,
        `Tu ${element} te guía hacia lo positivo.`,
      ],
      sombra: [
        `Cuidado con tu tendencia a ${characteristics.challenges[0]}.`,
        `Tu ${characteristics.traits[0]} naturaleza puede llevarte a extremos.`,
        `Observa cómo tu ${element} puede nublar tu juicio.`,
      ],
      equilibrio: [
        `Equilibra tu ${characteristics.traits[0]} naturaleza con reflexión.`,
        `Usa tu ${characteristics.strengths[0]} de forma consciente.`,
        `Tu ${element} te ofrece tanto oportunidades como desafíos.`,
      ],
    };

    const options = influences[variant];
    return options[Math.floor(Math.random() * options.length)];
  }

  /**
   * Generar guía elemental
   */
  generateElementalGuidance(sign: ZodiacSign, section: Section): string {
    const element = ZODIAC_TO_ELEMENT[sign];
    const elementInfo = ELEMENT_CHARACTERISTICS[element];

    const guidances = [
      `Tu elemento ${element} te sugiere: ${elementInfo.approach}`,
      `Enfócate en ${elementInfo.focus} como lo haría tu elemento ${element}.`,
      `La energía ${element} te aconseja: ${elementInfo.keywords.join(', ')}.`,
    ];

    return guidances[Math.floor(Math.random() * guidances.length)];
  }

  /**
   * Generar lectura personalizada completa
   */
  generateReading(
    cardId: string,
    cardName: string,
    interpretation: CardInterpretation,
    context: UserContext,
    tarotType: TarotType,
    section: Section
  ): ReadingResult {
    // Analizar la pregunta
    const analysis = this.analyzeQuestion(context.question);

    // Seleccionar variante
    const variant = this.selectVariant(cardId, section, analysis, context.sign);

    // Generar influencia del signo
    const signInfluence = context.sign
      ? this.generateSignInfluence(context.sign, section, variant)
      : '';

    // Generar guía elemental
    const elementalGuidance = context.sign
      ? this.generateElementalGuidance(context.sign, section)
      : '';

    // Construir texto personalizado
    const personalizedText = this.buildPersonalizedText(
      interpretation,
      context,
      analysis,
      variant,
      signInfluence,
      elementalGuidance
    );

    // Registrar en el tracker
    sessionTracker.recordCard(cardId, section, variant, context.sign);

    return {
      cardId,
      cardName,
      section,
      variant,
      interpretation,
      personalizedText,
      analysis,
      signInfluence,
      elementalGuidance,
    };
  }

  /**
   * Construir el texto personalizado
   */
  private buildPersonalizedText(
    interpretation: CardInterpretation,
    context: UserContext,
    analysis: QuestionAnalysis,
    variant: Variant,
    signInfluence: string,
    elementalGuidance: string
  ): string {
    const name = context.name || 'Consultante';
    const element = context.sign ? ZODIAC_TO_ELEMENT[context.sign] : 'tierra';

    // Seleccionar intro según elemento
    const intros = ELEMENT_INTROS[element];
    const intro = intros[Math.floor(Math.random() * intros.length)];

    // Seleccionar conector según variante
    const connectors = CONTEXTUAL_CONNECTORS[variant];
    const connector = connectors[Math.floor(Math.random() * connectors.length)];

    // Construir el texto
    let text = `${intro} ${name}, `;
    text += `${interpretation.general} `;

    if (context.question) {
      text += `Específicamente sobre tu pregunta: "${context.question}", `;
    }

    text += `${connector} `;

    if (signInfluence) {
      text += `${signInfluence} `;
    }

    if (interpretation.advice) {
      text += `Mi consejo para ti: ${interpretation.advice} `;
    }

    if (elementalGuidance) {
      text += `${elementalGuidance}`;
    }

    return text.trim();
  }

  /**
   * Generar lectura múltiple (varias cartas)
   */
  generateMultipleReadings(
    cards: Array<{ id: string; name: string }>,
    context: UserContext,
    tarotType: TarotType,
    section: Section
  ): ReadingResult[] {
    return cards.map(card => {
      const cardData = tarotDB.getCard(card.id);
      if (!cardData) {
        return {
          cardId: card.id,
          cardName: card.name,
          section,
          variant: 'equilibrio',
          interpretation: {
            general: 'Interpretación no disponible',
            advice: 'Por favor, intenta de nuevo',
            keywords: [],
          },
          personalizedText: 'Esta carta no tiene interpretación disponible en la base de datos.',
          analysis: this.analyzeQuestion(context.question),
          signInfluence: '',
          elementalGuidance: '',
        };
      }

      const interpretation = tarotDB.getInterpretation(
        card.id,
        section,
        context.sign,
        'equilibrio'
      );

      if (!interpretation) {
        return {
          cardId: card.id,
          cardName: card.name,
          section,
          variant: 'equilibrio',
          interpretation: {
            general: 'Interpretación no disponible',
            advice: 'Por favor, intenta de nuevo',
            keywords: [],
          },
          personalizedText: 'Esta carta no tiene interpretación disponible para esta sección.',
          analysis: this.analyzeQuestion(context.question),
          signInfluence: '',
          elementalGuidance: '',
        };
      }

      return this.generateReading(
        card.id,
        card.name,
        interpretation,
        context,
        tarotType,
        section
      );
    });
  }
}

/**
 * Instancia global del motor de inteligencia
 */
export const intelligenceEngine = new IntelligenceEngineV2();

/**
 * Hook para usar el motor en componentes React
 */
export function useIntelligenceEngine() {
  return {
    analyzeQuestion: (question?: string) =>
      intelligenceEngine.analyzeQuestion(question),
    generateReading: (
      cardId: string,
      cardName: string,
      interpretation: CardInterpretation,
      context: UserContext,
      tarotType: TarotType,
      section: Section
    ) =>
      intelligenceEngine.generateReading(
        cardId,
        cardName,
        interpretation,
        context,
        tarotType,
        section
      ),
    generateMultipleReadings: (
      cards: Array<{ id: string; name: string }>,
      context: UserContext,
      tarotType: TarotType,
      section: Section
    ) =>
      intelligenceEngine.generateMultipleReadings(cards, context, tarotType, section),
  };
}
