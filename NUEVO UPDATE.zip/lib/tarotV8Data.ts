import { tarotMeaningsDB } from './tarotMeaningsDB';

export interface TarotCardV8 {
  id: string;
  name: string;
  image: string;
  keywords: string[];
  meaning: {
    general: string;
    love: string;
    work: string;
    money: string;
    advice: string;
  };
  reversed: {
    general: string;
    love: string;
    work: string;
    money: string;
    advice: string;
  };
}

// Generar el mazo completo usando la base de datos detallada
const generateDeck = (): TarotCardV8[] => {
  const deck: TarotCardV8[] = [];
  
  // Arcanos Mayores
  const majorArcanaNames = [
    "El Loco", "El Mago", "La Sacerdotisa", "La Emperatriz", "El Emperador", 
    "El Sumo Sacerdote", "Los Enamorados", "El Carro", "La Fuerza", "El Ermitaño", 
    "Rueda de la Fortuna", "La Justicia", "El Colgado", "La Muerte", "La Templanza", 
    "El Diablo", "La Torre", "La Estrella", "La Luna", "El Sol", "El Juicio", "El Mundo"
  ];

  majorArcanaNames.forEach((name, index) => {
    const id = `maj_${index}`;
    const meaning = tarotMeaningsDB[id] || {
      general: "Significado no disponible.",
      love: "...", money: "...", work: "...", advice: "..."
    };

    deck.push({
      id,
      name,
      image: "", // Se resuelve dinámicamente
      keywords: ["Arcano Mayor"],
      meaning,
      reversed: {
        general: `Invertida: ${meaning.general} (Bloqueo o retraso)`,
        love: `Invertida: ${meaning.love} (Dificultades)`,
        work: `Invertida: ${meaning.work} (Obstáculos)`,
        money: `Invertida: ${meaning.money} (Pérdidas)`,
        advice: `Invertida: ${meaning.advice} (Revisa tu enfoque)`
      }
    });
  });

  // Arcanos Menores
  const suits = [
    { id: 'wands', name: 'Bastos' },
    { id: 'cups', name: 'Copas' },
    { id: 'swords', name: 'Espadas' },
    { id: 'pentacles', name: 'Oros' }
  ];

  const courtCards = ['page', 'knight', 'queen', 'king'];
  const courtNames = ['Sota', 'Caballero', 'Reina', 'Rey'];

  suits.forEach(suit => {
    // As al 10
    for (let i = 1; i <= 10; i++) {
      const id = `${suit.id}_${i === 1 ? 'ace' : i}`;
      const name = i === 1 ? `As de ${suit.name}` : `${i} de ${suit.name}`;
      const meaning = tarotMeaningsDB[id] || {
        general: "Significado no disponible.",
        love: "...", money: "...", work: "...", advice: "..."
      };

      deck.push({
        id,
        name,
        image: "",
        keywords: [suit.name],
        meaning,
        reversed: {
          general: `Invertida: ${meaning.general}`,
          love: `Invertida: ${meaning.love}`,
          work: `Invertida: ${meaning.work}`,
          money: `Invertida: ${meaning.money}`,
          advice: `Invertida: ${meaning.advice}`
        }
      });
    }

    // Figuras de la Corte
    courtCards.forEach((rank, idx) => {
      const id = `${suit.id}_${rank}`;
      const name = `${courtNames[idx]} de ${suit.name}`;
      const meaning = tarotMeaningsDB[id] || {
        general: "Significado no disponible.",
        love: "...", money: "...", work: "...", advice: "..."
      };

      deck.push({
        id,
        name,
        image: "",
        keywords: [suit.name, "Corte"],
        meaning,
        reversed: {
          general: `Invertida: ${meaning.general}`,
          love: `Invertida: ${meaning.love}`,
          work: `Invertida: ${meaning.work}`,
          money: `Invertida: ${meaning.money}`,
          advice: `Invertida: ${meaning.advice}`
        }
      });
    });
  });

  return deck;
};

export const fullTarotDeckV8 = generateDeck();

// Función auxiliar para obtener la imagen correcta
export const getCardImage = (cardId: string, deckType: 'rws' | 'spanish' | 'marseille' | 'angels'): string => {
  const parts = cardId.split('_');
  const isMajor = parts[0] === 'maj';
  const majorNum = isMajor ? parseInt(parts[1]) : -1;
  const majorNumStr = majorNum < 10 ? `0${majorNum}` : `${majorNum}`;
  
  // Mapeo para Arcanos Menores
  const suitMapRWS: Record<string, string> = { wands: 'bastos', cups: 'copas', swords: 'espadas', pentacles: 'oros' };
  const suitMapMarseille: Record<string, string> = { wands: 'bastos', cups: 'copas', swords: 'espadas', pentacles: 'oros' };
  
  const getMinorNumStr = (rank: string) => {
    if (rank === 'ace') return '01';
    if (rank === 'page') return '10'; // Sota suele ser 10 en española
    if (rank === 'knight') return '11'; // Caballo 11
    if (rank === 'king') return '12'; // Rey 12
    const n = parseInt(rank);
    return n < 10 ? `0${n}` : `${n}`;
  };

  // Baraja Española
  if (deckType === 'spanish') {
    if (isMajor) return '/images/cards/spanish/reverso.png'; // No hay mayores en española tradicional
    const suit = suitMapRWS[parts[0]];
    const num = getMinorNumStr(parts[1]);
    return `/images/cards/spanish/${num}-${suit}.png`;
  } 
  
  // Rider-Waite (RWS)
  if (deckType === 'rws') {
    if (isMajor) {
      const majorNames = [
        "el-loco", "el-mago", "la-sacerdotisa", "la-emperatriz", "el-emperador", 
        "el-sumo-sacerdote", "los-enamorados", "el-carro", "la-fuerza", "el-ermitaño", 
        "la-rueda-de-la-fortuna", "la-justicia", "el-colgado", "la-muerte", "la-templanza", 
        "el-diablo", "la-torre", "la-estrella", "la-luna", "el-sol", "el-juicio", "el-mundo"
      ];
      return `/images/cards/rws/${majorNumStr}-${majorNames[majorNum]}.jpg`;
    }
    const suit = suitMapRWS[parts[0]];
    const num = getMinorNumStr(parts[1]);
    return `/images/cards/rws/${num}-${suit}.jpg`;
  }

  // Marsella (Marseille)
  if (deckType === 'marseille') {
    if (isMajor) {
      const majorNamesMarseille = [
        "el-loco", "el-mago", "la-papisa", "la-emperatriz", "el-emperador", 
        "el-papa", "los-enamorados", "el-carro", "la-justicia", "el-ermitaño", 
        "la-rueda-de-la-fortuna", "la-fuerza", "el-colgado", "la-muerte", "la-templanza", 
        "el-diablo", "la-casa-de-dios", "la-estrella", "la-luna", "el-sol", "el-juicio", "el-mundo"
      ];
      // Ajuste de nombres según archivos reales detectados
      let name = majorNamesMarseille[majorNum];
      if (majorNum === 8) name = "la-fuerza"; // En Marsella a veces es 11, pero en el disco está como 08-la-fuerza.jpg
      if (majorNum === 11) name = "la-justicia";
      return `/images/cards/marseille/${majorNumStr}-${name}.jpg`;
    }
    const suit = suitMapMarseille[parts[0]];
    const num = getMinorNumStr(parts[1]);
    return `/images/cards/marseille/${num}-${suit}.jpg`;
  }

  // Ángeles (Angels)
  if (deckType === 'angels') {
    // Los ángeles están numerados del 01 al 77
    let angelNum = 1;
    if (isMajor) angelNum = majorNum + 1;
    else {
      const suitOffset = { wands: 22, cups: 36, swords: 50, pentacles: 64 }[parts[0]] || 22;
      angelNum = suitOffset + (parseInt(parts[1]) || 1);
    }
    const angelNumStr = angelNum < 10 ? `0${angelNum}` : `${angelNum}`;
    // Como no tenemos todos los nombres, buscamos por prefijo numérico
    return `/images/cards/angels/${angelNumStr}-*.jpg`; // Nota: Esto es pseudocódigo, en el cliente real hay que resolver el path exacto o usar un mapa
  }

  return '/images/cards/back.jpg';
};
