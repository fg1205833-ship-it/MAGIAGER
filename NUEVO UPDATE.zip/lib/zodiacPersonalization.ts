/**
 * Sistema de Personalización por Elemento Zodiacal
 * 
 * Garantiza que cada interpretación sea auténtica, diferenciada y coherente
 * sin caer en genericidad. Utiliza plantillas de personalización que respetan
 * la coherencia simbólica de cada elemento.
 */

import {
  Element,
  ZodiacSign,
  CardInterpretation,
  ZODIAC_TO_ELEMENT,
  ZODIAC_CHARACTERISTICS,
  ELEMENT_CHARACTERISTICS,
} from './tarotDatabase';

/**
 * Contexto de personalización para una carta
 */
export interface PersonalizationContext {
  cardName: string;
  cardSymbolism: string[]; // Símbolos principales de la carta
  baseInterpretation: string;
  section: string;
  variant: 'luz' | 'sombra' | 'equilibrio';
}

/**
 * Reglas de coherencia simbólica por elemento
 */
export const ELEMENT_SYMBOLIC_RULES: Record<Element, {
  actionVerbs: string[];
  focusAreas: string[];
  timeframes: string[];
  riskApproach: string;
  decisionProcess: string;
  successMetrics: string[];
  failurePatterns: string[];
  transformationStyle: string;
}> = {
  fuego: {
    actionVerbs: ['impulsa', 'enciende', 'propulsa', 'acelera', 'conquista', 'ignora', 'arrasa', 'transforma con fuerza'],
    focusAreas: ['acción inmediata', 'competencia', 'visibilidad', 'liderazgo', 'movimiento rápido'],
    timeframes: ['ahora', 'hoy', 'esta semana', 'sin demora'],
    riskApproach: 'Riesgo calculado pero valiente. Aries actúa primero, piensa después.',
    decisionProcess: 'Instintivo, rápido, basado en coraje más que en análisis',
    successMetrics: ['velocidad', 'impacto', 'visibilidad', 'dominio'],
    failurePatterns: ['impulsividad sin reflexión', 'quemar puentes', 'agotamiento rápido'],
    transformationStyle: 'Explosiva, visible, inmediata',
  },
  tierra: {
    actionVerbs: ['construye', 'consolida', 'establece', 'cultiva', 'sedimenta', 'enraíza', 'materializa', 'estabiliza'],
    focusAreas: ['estabilidad', 'recursos tangibles', 'paciencia', 'construcción sólida', 'largo plazo'],
    timeframes: ['gradualmente', 'paso a paso', 'en el tiempo', 'consistentemente'],
    riskApproach: 'Riesgo mínimo. Tauro prefiere lo seguro y probado.',
    decisionProcess: 'Lento, reflexivo, basado en datos y experiencia',
    successMetrics: ['solidez', 'durabilidad', 'crecimiento predecible', 'seguridad'],
    failurePatterns: ['rigidez excesiva', 'miedo al cambio', 'estancamiento'],
    transformationStyle: 'Gradual, sólida, duradera',
  },
  aire: {
    actionVerbs: ['comunica', 'analiza', 'conecta', 'expande', 'cuestiona', 'sintetiza', 'disemina', 'ilumina'],
    focusAreas: ['comunicación', 'perspectiva', 'conexiones', 'inteligencia', 'información'],
    timeframes: ['mentalmente', 'en teoría', 'conceptualmente', 'a través del diálogo'],
    riskApproach: 'Riesgo intelectual. Géminis explora ideas sin necesariamente actuar.',
    decisionProcess: 'Analítico, comparativo, basado en múltiples perspectivas',
    successMetrics: ['claridad', 'conexión', 'comprensión', 'versatilidad'],
    failurePatterns: ['superficialidad', 'análisis paralizante', 'falta de acción'],
    transformationStyle: 'Mental, flexible, adaptable',
  },
  agua: {
    actionVerbs: ['fluye', 'penetra', 'absorbe', 'transforma', 'sana', 'disuelve', 'revela', 'regenera'],
    focusAreas: ['emociones', 'intuición', 'relaciones', 'profundidad', 'lo oculto'],
    timeframes: ['emocionalmente', 'intuitivamente', 'en ciclos', 'en las profundidades'],
    riskApproach: 'Riesgo emocional. Escorpio se sumerge en lo profundo.',
    decisionProcess: 'Intuitivo, emocional, basado en percepción y transformación',
    successMetrics: ['profundidad', 'transformación', 'poder', 'verdad oculta'],
    failurePatterns: ['obsesión', 'resentimiento', 'manipulación'],
    transformationStyle: 'Profunda, transformadora, regeneradora',
  },
};

/**
 * Plantillas de personalización por elemento y variante
 */
export const PERSONALIZATION_TEMPLATES: Record<Element, Record<'luz' | 'sombra' | 'equilibrio', {
  intro: string;
  mainMessage: string;
  actionGuidance: string;
  warningOrInsight: string;
  closingAdvice: string;
}>> = {
  fuego: {
    luz: {
      intro: 'Tu energía de fuego arde con intensidad en este momento.',
      mainMessage: 'Te muestra que tienes el poder de actuar AHORA. No esperes, no analices demasiado: tu instinto es tu mayor fortaleza.',
      actionGuidance: 'Identifica la oportunidad que requiere coraje y acción rápida. Tu naturaleza te permite tomar riesgos que otros no se atreverían.',
      warningOrInsight: 'Mientras otros todavía piensan, tú ya estás actuando. Esa es tu ventaja.',
      closingAdvice: 'Confía en tu velocidad de decisión. La abundancia viene para quien se atreve a actuar.',
    },
    sombra: {
      intro: 'Tu fuego ardiente puede quemar lo que construyes si no tienes cuidado.',
      mainMessage: 'Te advierte sobre la impulsividad que puede destruir lo que has logrado. Tu velocidad puede ser tu mayor enemigo.',
      actionGuidance: 'Antes de actuar, pregúntate: ¿estoy actuando desde el coraje o desde el miedo? ¿Estoy conquistando o destruyendo?',
      warningOrInsight: 'La prisa sin dirección te lleva a quemar puentes y agotarte rápidamente.',
      closingAdvice: 'Canaliza tu fuego hacia objetivos claros, no hacia la destrucción impulsiva.',
    },
    equilibrio: {
      intro: 'Tu fuego necesita dirección y propósito para brillar realmente.',
      mainMessage: 'Te muestra que tu poder está en combinar la acción rápida con la intención clara. Velocidad + Dirección = Éxito.',
      actionGuidance: 'Actúa con rapidez, pero asegúrate de que tu acción sirve a un propósito mayor que tu ego.',
      warningOrInsight: 'Tu verdadera fuerza no está en ganar, sino en conquistar lo que importa.',
      closingAdvice: 'Usa tu velocidad para servir, no solo para dominar.',
    },
  },
  tierra: {
    luz: {
      intro: 'Tu tierra firme te permite construir riqueza que perdura.',
      mainMessage: 'No te pide que actúes con prisa, sino que uses tu paciencia y tu visión a largo plazo. Tienes el don de transformar pequeños recursos en grandes fortunas.',
      actionGuidance: 'Identifica una fuente de ingresos estable que pueda crecer lentamente pero seguramente. Tu consistencia es tu superpoder.',
      warningOrInsight: 'La verdadera riqueza se construye ladrillo a ladrillo, no en un día.',
      closingAdvice: 'No busques dinero fácil. Busca inversiones que crezcan de forma sólida y predecible.',
    },
    sombra: {
      intro: 'Tu tierra puede convertirse en una prisión si te aferras demasiado al pasado.',
      mainMessage: 'Te advierte sobre la rigidez que te impide crecer. Tu miedo al cambio puede paralizarte completamente.',
      actionGuidance: 'Pregúntate: ¿estoy siendo paciente o simplemente tengo miedo? ¿Estoy construyendo o estoy estancado?',
      warningOrInsight: 'La seguridad excesiva es una ilusión que te mantiene atrapado.',
      closingAdvice: 'La paciencia sin movimiento es estancamiento. Necesitas crecer, aunque sea lentamente.',
    },
    equilibrio: {
      intro: 'Tu tierra te ofrece tanto estabilidad como la capacidad de crecer.',
      mainMessage: 'Te muestra que puedes ser paciente sin ser rígido. Puedes crecer sin abandonar tus raíces.',
      actionGuidance: 'Busca cambios graduales que no comprometan tu seguridad. La evolución es posible dentro de la estabilidad.',
      warningOrInsight: 'Tu verdadera fuerza está en adaptarte lentamente, no en resistir el cambio.',
      closingAdvice: 'Cultiva tanto la paciencia como la flexibilidad. Ambas son necesarias para prosperar.',
    },
  },
  aire: {
    luz: {
      intro: 'Tu mente aérea vuela alto en busca de respuestas y conexiones.',
      mainMessage: 'Te muestra que tienes el poder de ver lo que otros no ven. Tu perspectiva única es tu mayor fortaleza.',
      actionGuidance: 'Comunica tus ideas, conecta con otros, expande tu red. Tu capacidad de análisis te abre puertas.',
      warningOrInsight: 'Mientras otros están atrapados en detalles, tú ves el panorama completo.',
      closingAdvice: 'Confía en tu inteligencia y en tu capacidad de adaptación. La claridad es tu ventaja.',
    },
    sombra: {
      intro: 'Tu mente aérea puede perderse en la teoría sin nunca tocar la realidad.',
      mainMessage: 'Te advierte sobre la superficialidad y el análisis paralizante. Demasiada información puede impedir la acción.',
      actionGuidance: 'Pregúntate: ¿estoy pensando o simplemente evitando actuar? ¿Estoy conectando o simplemente dispersándome?',
      warningOrInsight: 'La falta de acción es el mayor fracaso del aire. Las ideas sin implementación son solo humo.',
      closingAdvice: 'Aterriza tus ideas. La verdadera inteligencia está en la ejecución, no solo en el pensamiento.',
    },
    equilibrio: {
      intro: 'Tu mente necesita tanto visión como ejecución para ser realmente poderosa.',
      mainMessage: 'Te muestra que puedes ser inteligente sin ser superficial. Puedes pensar y actuar simultáneamente.',
      actionGuidance: 'Analiza, pero también ejecuta. Conecta con otros, pero también profundiza en relaciones significativas.',
      warningOrInsight: 'Tu verdadera fuerza está en ser el puente entre ideas y realidad.',
      closingAdvice: 'Usa tu inteligencia para crear, no solo para analizar. El mundo necesita tus ideas convertidas en acción.',
    },
  },
  agua: {
    luz: {
      intro: 'Tus aguas emocionales fluyen profundamente hacia la verdad y la transformación.',
      mainMessage: 'Te muestra que tienes el poder de transformar completamente tu situación. Tu intuición ve lo que está oculto.',
      actionGuidance: 'Investiga profundamente, confía en tu intuición, busca las capas ocultas. Tu percepción es tu arma más poderosa.',
      warningOrInsight: 'Mientras otros ven la superficie, tú ves la verdad oculta. Esa es tu verdadera ventaja.',
      closingAdvice: 'Confía en tu intuición. Tu capacidad de transformación es real y profunda.',
    },
    sombra: {
      intro: 'Tus aguas emocionales pueden convertirse en un pantano de obsesión y resentimiento.',
      mainMessage: 'Te advierte sobre la tendencia a quedarte atrapado en lo oculto. Tu intensidad puede volverse destructiva.',
      actionGuidance: 'Pregúntate: ¿estoy transformando o simplemente obsesionándome? ¿Estoy sanando o simplemente revolviendo heridas?',
      warningOrInsight: 'La manipulación y el resentimiento son los mayores peligros del agua en sombra.',
      closingAdvice: 'Transforma tu intensidad en poder, no en venganza. La verdadera fuerza está en la regeneración, no en la destrucción.',
    },
    equilibrio: {
      intro: 'Tus aguas necesitan tanto profundidad como claridad para fluir realmente.',
      mainMessage: 'Te muestra que puedes ser intenso sin ser obsesivo. Puedes transformar sin destruir.',
      actionGuidance: 'Investiga, pero también suelta. Siente profundamente, pero también comunica. Transforma, pero también sana.',
      warningOrInsight: 'Tu verdadera fuerza está en la alquimia: convertir el dolor en sabiduría.',
      closingAdvice: 'Usa tu intuición para sanar, no para herir. Tu poder está en la transformación consciente.',
    },
  },
};

/**
 * Función para personalizar una interpretación según el elemento
 */
export function personalizeByElement(
  baseInterpretation: CardInterpretation,
  element: Element,
  variant: 'luz' | 'sombra' | 'equilibrio',
  context: PersonalizationContext
): CardInterpretation {
  const template = PERSONALIZATION_TEMPLATES[element][variant];
  const rules = ELEMENT_SYMBOLIC_RULES[element];

  // Construir el mensaje personalizado
  const personalizedGeneral = `${template.intro} ${context.cardName} ${template.mainMessage}`;
  
  const personalizedAdvice = `${template.actionGuidance} ${template.warningOrInsight} ${template.closingAdvice}`;

  // Mantener los otros campos de la interpretación base
  return {
    ...baseInterpretation,
    general: personalizedGeneral,
    advice: personalizedAdvice,
    keywords: [
      ...baseInterpretation.keywords,
      ...rules.focusAreas.slice(0, 2),
    ],
  };
}

/**
 * Función para personalizar una interpretación según el signo específico
 */
export function personalizeBySign(
  baseInterpretation: CardInterpretation,
  sign: ZodiacSign,
  variant: 'luz' | 'sombra' | 'equilibrio',
  context: PersonalizationContext
): CardInterpretation {
  const element = ZODIAC_TO_ELEMENT[sign];
  const characteristics = ZODIAC_CHARACTERISTICS[sign];

  // Obtener personalización por elemento
  let personalized = personalizeByElement(baseInterpretation, element, variant, context);

  // Añadir características específicas del signo
  const signSpecificInsight = getSignSpecificInsight(sign, variant, context.section);
  
  personalized.general = `${personalized.general} ${signSpecificInsight}`;

  return personalized;
}

/**
 * Obtener insight específico del signo
 */
function getSignSpecificInsight(
  sign: ZodiacSign,
  variant: 'luz' | 'sombra' | 'equilibrio',
  section: string
): string {
  const characteristics = ZODIAC_CHARACTERISTICS[sign];
  const element = ZODIAC_TO_ELEMENT[sign];

  const insights: Record<ZodiacSign, Record<'luz' | 'sombra' | 'equilibrio', string>> = {
    aries: {
      luz: `Tu ${characteristics.traits[0]} naturaleza Aries te permite ver la oportunidad donde otros ven obstáculos.`,
      sombra: `Cuidado con tu tendencia a ${characteristics.challenges[0]} sin considerar las consecuencias.`,
      equilibrio: `Equilibra tu ${characteristics.traits[0]} naturaleza con reflexión consciente.`,
    },
    tauro: {
      luz: `Tu ${characteristics.traits[0]} naturaleza Tauro te permite construir lo que otros solo sueñan.`,
      sombra: `Cuidado con tu tendencia a ${characteristics.challenges[0]} y resistir el cambio necesario.`,
      equilibrio: `Equilibra tu ${characteristics.traits[0]} naturaleza con flexibilidad.`,
    },
    geminis: {
      luz: `Tu ${characteristics.traits[0]} naturaleza Géminis te permite conectar puntos que otros no ven.`,
      sombra: `Cuidado con tu tendencia a ${characteristics.challenges[0]} y dispersarte en demasiadas direcciones.`,
      equilibrio: `Equilibra tu ${characteristics.traits[0]} naturaleza con profundidad.`,
    },
    cancer: {
      luz: `Tu ${characteristics.traits[0]} naturaleza Cáncer te permite percibir lo que está oculto en los corazones.`,
      sombra: `Cuidado con tu tendencia a ${characteristics.challenges[0]} y quedarte atrapado en el pasado.`,
      equilibrio: `Equilibra tu ${characteristics.traits[0]} naturaleza con desapego consciente.`,
    },
    leo: {
      luz: `Tu ${characteristics.traits[0]} naturaleza Leo te permite brillar y liderar con autenticidad.`,
      sombra: `Cuidado con tu tendencia a ${characteristics.challenges[0]} y necesidad excesiva de admiración.`,
      equilibrio: `Equilibra tu ${characteristics.traits[0]} naturaleza con humildad.`,
    },
    virgo: {
      luz: `Tu ${characteristics.traits[0]} naturaleza Virgo te permite ver los detalles que otros ignoran.`,
      sombra: `Cuidado con tu tendencia a ${characteristics.challenges[0]} y parálisis por perfeccionismo.`,
      equilibrio: `Equilibra tu ${characteristics.traits[0]} naturaleza con aceptación.`,
    },
    libra: {
      luz: `Tu ${characteristics.traits[0]} naturaleza Libra te permite ver ambos lados y encontrar armonía.`,
      sombra: `Cuidado con tu tendencia a ${characteristics.challenges[0]} y falta de decisión.`,
      equilibrio: `Equilibra tu ${characteristics.traits[0]} naturaleza con decisión consciente.`,
    },
    escorpio: {
      luz: `Tu ${characteristics.traits[0]} naturaleza Escorpio te permite transformar lo imposible en realidad.`,
      sombra: `Cuidado con tu tendencia a ${characteristics.challenges[0]} y obsesión destructiva.`,
      equilibrio: `Equilibra tu ${characteristics.traits[0]} naturaleza con compasión.`,
    },
    sagitario: {
      luz: `Tu ${characteristics.traits[0]} naturaleza Sagitario te permite ver el horizonte y expandir posibilidades.`,
      sombra: `Cuidado con tu tendencia a ${characteristics.challenges[0]} y falta de responsabilidad.`,
      equilibrio: `Equilibra tu ${characteristics.traits[0]} naturaleza con compromiso.`,
    },
    capricornio: {
      luz: `Tu ${characteristics.traits[0]} naturaleza Capricornio te permite construir imperios duraderos.`,
      sombra: `Cuidado con tu tendencia a ${characteristics.challenges[0]} y frialdad emocional.`,
      equilibrio: `Equilibra tu ${characteristics.traits[0]} naturaleza con calidez.`,
    },
    acuario: {
      luz: `Tu ${characteristics.traits[0]} naturaleza Acuario te permite ver el futuro y revolucionar lo existente.`,
      sombra: `Cuidado con tu tendencia a ${characteristics.challenges[0]} y distanciamiento emocional.`,
      equilibrio: `Equilibra tu ${characteristics.traits[0]} naturaleza con conexión.`,
    },
    piscis: {
      luz: `Tu ${characteristics.traits[0]} naturaleza Piscis te permite acceder a la sabiduría universal.`,
      sombra: `Cuidado con tu tendencia a ${characteristics.challenges[0]} y escapismo.`,
      equilibrio: `Equilibra tu ${characteristics.traits[0]} naturaleza con anclaje.`,
    },
  };

  return insights[sign][variant];
}

/**
 * Validador de calidad: detecta genericidad
 */
export function validateQualityAndUniqueness(
  interpretation: CardInterpretation,
  previousInterpretations: CardInterpretation[] = []
): {
  isGeneric: boolean;
  uniquenessScore: number;
  warnings: string[];
} {
  const warnings: string[] = [];
  let uniquenessScore = 1.0;

  // Verificar longitud mínima
  if (interpretation.general.length < 100) {
    warnings.push('Interpretación demasiado corta. Necesita más profundidad.');
    uniquenessScore -= 0.2;
  }

  // Verificar palabras genéricas comunes
  const genericWords = ['bueno', 'malo', 'bien', 'mal', 'importante', 'especial', 'único'];
  const genericCount = genericWords.filter(word =>
    interpretation.general.toLowerCase().includes(word)
  ).length;

  if (genericCount > 2) {
    warnings.push('Demasiadas palabras genéricas. Necesita más especificidad.');
    uniquenessScore -= 0.15 * genericCount;
  }

  // Verificar repetición con interpretaciones anteriores
  const currentWords = new Set(interpretation.general.toLowerCase().split(/\s+/));
  for (const prev of previousInterpretations) {
    const prevWords = new Set(prev.general.toLowerCase().split(/\s+/));
    const intersection = new Set([...currentWords].filter(x => prevWords.has(x)));
    
    if (intersection.size > currentWords.size * 0.7) {
      warnings.push('Posible repetición con interpretación anterior.');
      uniquenessScore -= 0.1;
    }
  }

  // Verificar coherencia simbólica (palabras clave presentes)
  if (interpretation.keywords.length < 3) {
    warnings.push('Faltan palabras clave. Necesita más contexto simbólico.');
    uniquenessScore -= 0.1;
  }

  const isGeneric = uniquenessScore < 0.6;

  return {
    isGeneric,
    uniquenessScore: Math.max(0, uniquenessScore),
    warnings,
  };
}
