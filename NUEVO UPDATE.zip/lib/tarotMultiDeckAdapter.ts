/**
 * Adaptador Multi-Tarot
 * 
 * Aplica las interpretaciones base a los 4 tarots diferentes:
 * - Rider-Waite-Smith (RWS)
 * - Marsella
 * - Ángeles
 * - Baraja Española
 * 
 * Cada tarot tiene sus propias características simbólicas que se integran
 * con las interpretaciones base para crear lecturas auténticas y diferenciadas.
 */

import { TarotType, CardInterpretation } from './tarotDatabase';
import { CardSectionInterpretations } from './tarotCardInterpretations';

/**
 * Características simbólicas de cada tarot
 */
export const TAROT_CHARACTERISTICS: Record<TarotType, {
  name: string;
  origin: string;
  symbology: string;
  approach: string;
  strengths: string[];
  focus: string;
  language: string;
}> = {
  rws: {
    name: 'Rider-Waite-Smith',
    origin: 'Inglés (1909)',
    symbology: 'Moderna, visual, detallada, con influencias cabalísticas y astrológicas',
    approach: 'Narrativo y visual. Cada carta cuenta una historia clara.',
    strengths: ['claridad visual', 'narrativa clara', 'accesibilidad', 'profundidad simbólica'],
    focus: 'Interpretación visual y narrativa de los arquetipos',
    language: 'Inglés, universal',
  },
  marseille: {
    name: 'Tarot de Marsella',
    origin: 'Francés (siglo XVI)',
    symbology: 'Clásica, minimalista, simbólica, con influencias renacentistas',
    approach: 'Minimalista y simbólico. Requiere interpretación más profunda.',
    strengths: ['tradición', 'minimalismo', 'profundidad', 'autenticidad histórica'],
    focus: 'Interpretación simbólica profunda de los arquetipos',
    language: 'Francés, clásico',
  },
  angels: {
    name: 'Tarot de Ángeles',
    origin: 'Contemporáneo',
    symbology: 'Espiritual, angélica, compasiva, orientada a la sanación',
    approach: 'Espiritual y compasivo. Enfoque en mensajes de amor y sanación.',
    strengths: ['espiritualidad', 'compasión', 'sanación', 'mensajes positivos'],
    focus: 'Interpretación espiritual y angélica de los arquetipos',
    language: 'Universal, espiritual',
  },
  spanish: {
    name: 'Baraja Española de Tarot',
    origin: 'Español (tradicional)',
    symbology: 'Tradicional, cultural, con influencias españolas e ibéricas',
    approach: 'Tradicional y cultural. Conexión con la tradición ibérica.',
    strengths: ['tradición local', 'autenticidad cultural', 'conexión histórica', 'profundidad'],
    focus: 'Interpretación cultural y tradicional de los arquetipos',
    language: 'Español, local',
  },
};

/**
 * Adaptaciones de interpretaciones por tarot
 */
export const TAROT_INTERPRETATION_ADAPTATIONS: Record<TarotType, {
  intro: string;
  approach: string;
  emphasis: string[];
  tone: string;
}> = {
  rws: {
    intro: 'La carta te muestra claramente',
    approach: 'narrativo y visual',
    emphasis: ['claridad', 'narrativa', 'simbolismo visual', 'profundidad'],
    tone: 'claro, accesible, profundo',
  },
  marseille: {
    intro: 'La carta revela en su minimalismo',
    approach: 'simbólico y tradicional',
    emphasis: ['tradición', 'simbolismo', 'profundidad', 'autenticidad'],
    tone: 'clásico, profundo, contemplativo',
  },
  angels: {
    intro: 'Los ángeles te comunican a través de esta carta',
    approach: 'espiritual y compasivo',
    emphasis: ['espiritualidad', 'compasión', 'sanación', 'amor'],
    tone: 'amoroso, sanador, espiritual',
  },
  spanish: {
    intro: 'La tradición española te muestra a través de esta carta',
    approach: 'cultural y tradicional',
    emphasis: ['tradición', 'cultura', 'profundidad', 'autenticidad'],
    tone: 'tradicional, profundo, auténtico',
  },
};

/**
 * Función para adaptar una interpretación a un tarot específico
 */
export function adaptInterpretationToTarot(
  baseInterpretation: CardInterpretation,
  tarotType: TarotType,
  cardName: string,
  section: string
): CardInterpretation {
  const adaptation = TAROT_INTERPRETATION_ADAPTATIONS[tarotType];
  const characteristics = TAROT_CHARACTERISTICS[tarotType];

  // Construir el mensaje adaptado
  let adaptedGeneral = `${adaptation.intro} ${cardName}: ${baseInterpretation.general}`;

  // Añadir enfoque específico del tarot
  switch (tarotType) {
    case 'rws':
      adaptedGeneral += ` Esta carta del Rider-Waite-Smith te muestra la narrativa clara de tu situación.`;
      break;
    case 'marseille':
      adaptedGeneral += ` En la tradición de Marsella, este símbolo revela una verdad profunda.`;
      break;
    case 'angels':
      adaptedGeneral += ` Los ángeles desean que entiendas este mensaje de amor y sanación.`;
      break;
    case 'spanish':
      adaptedGeneral += ` La tradición española de esta baraja te conecta con sabiduría ancestral.`;
      break;
  }

  // Adaptar el consejo
  let adaptedAdvice = baseInterpretation.advice;
  switch (tarotType) {
    case 'rws':
      adaptedAdvice = `Observa la narrativa visual de esta carta. ${adaptedAdvice}`;
      break;
    case 'marseille':
      adaptedAdvice = `Contempla el símbolo minimalista. ${adaptedAdvice}`;
      break;
    case 'angels':
      adaptedAdvice = `Recibe el mensaje angélico. ${adaptedAdvice}`;
      break;
    case 'spanish':
      adaptedAdvice = `Conecta con la tradición. ${adaptedAdvice}`;
      break;
  }

  // Retornar interpretación adaptada
  return {
    ...baseInterpretation,
    general: adaptedGeneral,
    advice: adaptedAdvice,
    keywords: [
      ...baseInterpretation.keywords,
      characteristics.focus,
    ],
  };
}

/**
 * Función para aplicar todas las adaptaciones a una interpretación completa
 */
export function applyTarotAdaptations(
  sectionInterpretations: CardSectionInterpretations,
  tarotType: TarotType,
  cardName: string
): CardSectionInterpretations {
  const adapted: CardSectionInterpretations = {} as CardSectionInterpretations;

  for (const [section, interpretation] of Object.entries(sectionInterpretations)) {
    adapted[section as keyof CardSectionInterpretations] = adaptInterpretationToTarot(
      interpretation,
      tarotType,
      cardName,
      section
    );
  }

  return adapted;
}

/**
 * Información sobre cómo cada tarot interpreta los arquetipos
 */
export const ARCHETYPE_INTERPRETATION_BY_TAROT: Record<TarotType, {
  majorArcana: string;
  minorArcana: string;
  courtCards: string;
  symbolism: string;
}> = {
  rws: {
    majorArcana: 'Los Arcanos Mayores son narrativas visuales complejas que cuentan la historia del Viaje del Loco.',
    minorArcana: 'Los Arcanos Menores representan situaciones cotidianas con profundidad simbólica.',
    courtCards: 'Las figuras de corte son personajes con características psicológicas claras.',
    symbolism: 'Cada elemento visual tiene significado: colores, números, símbolos astrológicos, etc.',
  },
  marseille: {
    majorArcana: 'Los Arcanos Mayores son símbolos minimalistas que requieren contemplación profunda.',
    minorArcana: 'Los Arcanos Menores son patrones numéricos y de palo con significado tradicional.',
    courtCards: 'Las figuras de corte son arquetipos tradicionales con roles claros.',
    symbolism: 'El minimalismo es intencional: lo que NO se muestra es tan importante como lo que se muestra.',
  },
  angels: {
    majorArcana: 'Los Arcanos Mayores son mensajes angélicos sobre la evolución espiritual.',
    minorArcana: 'Los Arcanos Menores son guías prácticas para la vida cotidiana con enfoque espiritual.',
    courtCards: 'Las figuras de corte son seres angélicos o humanos con cualidades espirituales.',
    symbolism: 'Cada elemento comunica amor, sanación y orientación espiritual.',
  },
  spanish: {
    majorArcana: 'Los Arcanos Mayores son arquetipos de la tradición ibérica y española.',
    minorArcana: 'Los Arcanos Menores mantienen la estructura tradicional con interpretaciones locales.',
    courtCards: 'Las figuras de corte son personajes de la tradición española.',
    symbolism: 'Los símbolos conectan con la historia y la cultura española.',
  },
};

/**
 * Función para obtener descripción de cómo un tarot interpreta una carta
 */
export function getTarotInterpretationApproach(
  tarotType: TarotType,
  cardType: 'major' | 'minor' | 'court'
): string {
  const approaches = ARCHETYPE_INTERPRETATION_BY_TAROT[tarotType];
  
  switch (cardType) {
    case 'major':
      return approaches.majorArcana;
    case 'minor':
      return approaches.minorArcana;
    case 'court':
      return approaches.courtCards;
    default:
      return '';
  }
}

/**
 * Función para crear una lectura multi-tarot
 * Permite comparar cómo diferentes tarots interpretan la misma situación
 */
export function createMultiTarotReading(
  baseInterpretation: CardInterpretation,
  cardName: string,
  section: string
): Record<TarotType, CardInterpretation> {
  const reading: Record<TarotType, CardInterpretation> = {} as Record<TarotType, CardInterpretation>;

  const tarotTypes: TarotType[] = ['rws', 'marseille', 'angels', 'spanish'];

  for (const tarotType of tarotTypes) {
    reading[tarotType] = adaptInterpretationToTarot(
      baseInterpretation,
      tarotType,
      cardName,
      section
    );
  }

  return reading;
}

/**
 * Función para obtener análisis comparativo de tarots
 */
export function getComparativeTarotAnalysis(
  tarotType: TarotType
): {
  name: string;
  strengths: string[];
  approach: string;
  bestFor: string[];
  considerations: string[];
} {
  const characteristics = TAROT_CHARACTERISTICS[tarotType];
  
  const bestForMap: Record<TarotType, string[]> = {
    rws: ['principiantes', 'análisis visual', 'narrativas claras', 'profundidad simbólica'],
    marseille: ['practicantes avanzados', 'tradición clásica', 'contemplación profunda', 'autenticidad histórica'],
    angels: ['espiritualidad', 'sanación emocional', 'mensajes positivos', 'conexión angélica'],
    spanish: ['conexión cultural', 'tradición ibérica', 'autenticidad local', 'profundidad histórica'],
  };

  const considerationsMap: Record<TarotType, string[]> = {
    rws: ['Puede ser demasiado visual para algunos', 'Requiere interpretación de símbolos complejos'],
    marseille: ['Requiere más experiencia para interpretar', 'El minimalismo puede ser confuso al principio'],
    angels: ['Puede ser demasiado positivo para situaciones difíciles', 'Requiere sensibilidad espiritual'],
    spanish: ['Menos conocida internacionalmente', 'Requiere familiaridad con la tradición española'],
  };

  return {
    name: characteristics.name,
    strengths: characteristics.strengths,
    approach: characteristics.approach,
    bestFor: bestForMap[tarotType],
    considerations: considerationsMap[tarotType],
  };
}
