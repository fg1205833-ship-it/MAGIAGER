export interface ZodiacSign {
  name: string;
  element: string;
  quality: string;
  ruler: string;
  dates: string;
  traits: string[];
  affirmation: string;
  description: string;
}

export interface Compatibility {
  score: number; // 0-100
  desc: string;
  tips: string;
}

export const zodiacSignsDB: Record<string, ZodiacSign> = {
  aries: {
    name: "Aries",
    element: "Fuego",
    quality: "Cardinal",
    ruler: "Marte",
    dates: "21 Mar - 19 Abr",
    traits: ["Valiente", "Impulsivo", "Líder", "Enérgico"],
    affirmation: "Yo soy valiente y abro nuevos caminos con confianza.",
    description: "Aries es el pionero del zodiaco, lleno de energía y entusiasmo. Siempre listo para la acción, aunque a veces le falta paciencia."
  },
  taurus: {
    name: "Tauro",
    element: "Tierra",
    quality: "Fijo",
    ruler: "Venus",
    dates: "20 Abr - 20 May",
    traits: ["Paciente", "Fiable", "Sensual", "Terco"],
    affirmation: "Yo construyo mi vida sobre bases sólidas y disfruto de la belleza.",
    description: "Tauro busca la estabilidad y el placer sensorial. Es trabajador y leal, pero puede ser posesivo y resistente al cambio."
  },
  gemini: {
    name: "Géminis",
    element: "Aire",
    quality: "Mutable",
    ruler: "Mercurio",
    dates: "21 May - 20 Jun",
    traits: ["Curioso", "Adaptable", "Comunicativo", "Inquieto"],
    affirmation: "Yo comunico mi verdad y aprendo de todo lo que me rodea.",
    description: "Géminis es el comunicador por excelencia. Versátil e intelectual, siempre busca nueva información, aunque puede ser disperso."
  },
  cancer: {
    name: "Cáncer",
    element: "Agua",
    quality: "Cardinal",
    ruler: "Luna",
    dates: "21 Jun - 22 Jul",
    traits: ["Intuitivo", "Protector", "Emocional", "Hogareño"],
    affirmation: "Yo nutro mis emociones y protejo a los que amo.",
    description: "Cáncer es el signo de la familia y las emociones. Muy sensible y empático, necesita seguridad emocional y un refugio seguro."
  },
  leo: {
    name: "Leo",
    element: "Fuego",
    quality: "Fijo",
    ruler: "Sol",
    dates: "23 Jul - 22 Ago",
    traits: ["Creativo", "Apasionado", "Generoso", "Dramático"],
    affirmation: "Yo brillo con luz propia y expreso mi creatividad con alegría.",
    description: "Leo nació para brillar. Carismático y líder natural, busca el reconocimiento y el amor, aunque debe cuidar su ego."
  },
  virgo: {
    name: "Virgo",
    element: "Tierra",
    quality: "Mutable",
    ruler: "Mercurio",
    dates: "23 Ago - 22 Sep",
    traits: ["Analítico", "Práctico", "Servicial", "Perfeccionista"],
    affirmation: "Yo sirvo con amor y busco la perfección en los detalles.",
    description: "Virgo es el perfeccionista del zodiaco. Metódico y servicial, busca mejorar todo lo que toca, pero puede ser muy crítico."
  },
  libra: {
    name: "Libra",
    element: "Aire",
    quality: "Cardinal",
    ruler: "Venus",
    dates: "23 Sep - 22 Oct",
    traits: ["Diplomático", "Justo", "Sociable", "Indeciso"],
    affirmation: "Yo creo armonía y equilibrio en todas mis relaciones.",
    description: "Libra busca el equilibrio y la belleza. Amante de la paz y la justicia, es excelente mediador pero le cuesta tomar decisiones."
  },
  scorpio: {
    name: "Escorpio",
    element: "Agua",
    quality: "Fijo",
    ruler: "Plutón/Marte",
    dates: "23 Oct - 21 Nov",
    traits: ["Intenso", "Apasionado", "Misterioso", "Celoso"],
    affirmation: "Yo me transformo y renazco de mis cenizas más fuerte.",
    description: "Escorpio es el signo de la transformación. Intenso y profundo, vive las emociones al extremo y tiene un gran poder de regeneración."
  },
  sagittarius: {
    name: "Sagitario",
    element: "Fuego",
    quality: "Mutable",
    ruler: "Júpiter",
    dates: "22 Nov - 21 Dic",
    traits: ["Optimista", "Aventurero", "Filosófico", "Imprudente"],
    affirmation: "Yo exploro el mundo con fe y optimismo.",
    description: "Sagitario es el buscador de la verdad. Amante de la libertad y los viajes, siempre busca expandir sus horizontes físicos y mentales."
  },
  capricorn: {
    name: "Capricornio",
    element: "Tierra",
    quality: "Cardinal",
    ruler: "Saturno",
    dates: "22 Dic - 19 Ene",
    traits: ["Ambicioso", "Disciplinado", "Responsable", "Pesimista"],
    affirmation: "Yo construyo mi éxito con disciplina y perseverancia.",
    description: "Capricornio es el trabajador incansable. Ambicioso y pragmático, escala la montaña del éxito paso a paso, aunque puede ser muy serio."
  },
  aquarius: {
    name: "Acuario",
    element: "Aire",
    quality: "Fijo",
    ruler: "Urano",
    dates: "20 Ene - 18 Feb",
    traits: ["Original", "Humanitario", "Independiente", "Distante"],
    affirmation: "Yo innovo y creo un futuro mejor para la humanidad.",
    description: "Acuario es el visionario. Original y rebelde, valora la libertad y la amistad por encima de todo, pero puede parecer frío emocionalmente."
  },
  pisces: {
    name: "Piscis",
    element: "Agua",
    quality: "Mutable",
    ruler: "Neptuno",
    dates: "19 Feb - 20 Mar",
    traits: ["Soñador", "Compasivo", "Artístico", "Escapista"],
    affirmation: "Yo fluyo con el universo y confío en mi intuición.",
    description: "Piscis es el místico del zodiaco. Empático y soñador, vive en dos mundos a la vez y tiene una conexión espiritual profunda."
  }
};

// Matriz de compatibilidad simplificada (clave: signo1_signo2 en orden alfabético)
export const compatibilityDB: Record<string, Compatibility> = {
  // ARIES
  "aries_aries": { score: 80, desc: "Fuego + Fuego. Pasión explosiva, pero choques de ego frecuentes.", tips: "Turnarse para liderar." },
  "aries_taurus": { score: 60, desc: "Fuego + Tierra. Ritmos muy diferentes. Aries corre, Tauro camina.", tips: "Paciencia mutua." },
  "aries_gemini": { score: 90, desc: "Fuego + Aire. Diversión y aventura garantizada. Nunca se aburren.", tips: "Mantener la chispa." },
  "aries_cancer": { score: 50, desc: "Fuego + Agua. Aries hiere la sensibilidad de Cáncer sin querer.", tips: "Tacto y suavidad." },
  "aries_leo": { score: 95, desc: "Fuego + Fuego. Pareja poderosa y brillante. Pasión desbordante.", tips: "Admirarse mutuamente." },
  "aries_virgo": { score: 40, desc: "Fuego + Tierra. Visiones opuestas. Aries actúa, Virgo analiza.", tips: "Aprender del otro." },
  "aries_libra": { score: 85, desc: "Fuego + Aire. Opuestos complementarios. Atracción magnética.", tips: "Equilibrar deseos." },
  "aries_scorpio": { score: 75, desc: "Fuego + Agua. Intensidad sexual alta, pero luchas de poder.", tips: "Evitar celos." },
  "aries_sagittarius": { score: 95, desc: "Fuego + Fuego. Compañeros de aventura perfectos.", tips: "Viajar juntos." },
  "aries_capricorn": { score: 35, desc: "Fuego + Tierra. Choque de cuernos. Ambiciones diferentes.", tips: "Respetar metas." },
  "aries_aquarius": { score: 85, desc: "Fuego + Aire. Relación excitante y libre. Muy compatibles.", tips: "Dar espacio." },
  "aries_pisces": { score: 55, desc: "Fuego + Agua. Aries puede apagar a Piscis o Piscis ahogar a Aries.", tips: "Sensibilidad." },

  // TAURO
  "taurus_taurus": { score: 90, desc: "Tierra + Tierra. Estabilidad, confort y sensualidad máxima.", tips: "Salir del rutina." },
  "gemini_taurus": { score: 40, desc: "Tierra + Aire. Tauro quiere calma, Géminis quiere acción.", tips: "Comunicación clara." },
  "cancer_taurus": { score: 95, desc: "Tierra + Agua. Hogar dulce hogar. Nutrición mutua.", tips: "Expresar emociones." },
  "leo_taurus": { score: 50, desc: "Tierra + Fuego. Tercos los dos. Choque de voluntades fijas.", tips: "Ceder a veces." },
  "taurus_virgo": { score: 95, desc: "Tierra + Tierra. Entendimiento perfecto y práctico.", tips: "Disfrutar más." },
  "libra_taurus": { score: 75, desc: "Tierra + Aire. Ambos regidos por Venus. Amor por la belleza.", tips: "Evitar indecisión." },
  "scorpio_taurus": { score: 85, desc: "Tierra + Agua. Opuestos complementarios. Atracción fatal.", tips: "Controlar posesividad." },
  "sagittarius_taurus": { score: 30, desc: "Tierra + Fuego. Ritmos incompatibles. Sagitario quiere irse, Tauro quedarse.", tips: "Libertad pactada." },
  "capricorn_taurus": { score: 98, desc: "Tierra + Tierra. La pareja poderosa del zodiaco. Éxito material.", tips: "No solo trabajar." },
  "aquarius_taurus": { score: 20, desc: "Tierra + Aire. Tradición vs Innovación. Difícil entendimiento.", tips: "Respetar diferencias." },
  "pisces_taurus": { score: 85, desc: "Tierra + Agua. Tauro da tierra a los sueños de Piscis.", tips: "Romance suave." },

  // GÉMINIS
  "gemini_gemini": { score: 85, desc: "Aire + Aire. Conversación infinita, pero falta estabilidad.", tips: "Bajar a tierra." },
  "cancer_gemini": { score: 40, desc: "Aire + Agua. Razón vs Emoción. Difícil conexión profunda.", tips: "Escuchar sentimientos." },
  "gemini_leo": { score: 90, desc: "Aire + Fuego. Diversión, fiestas y creatividad. Muy social.", tips: "Halagar a Leo." },
  "gemini_virgo": { score: 60, desc: "Aire + Tierra. Ambos regidos por Mercurio, conexión mental pero tensa.", tips: "Menos crítica." },
  "gemini_libra": { score: 95, desc: "Aire + Aire. Armonía intelectual y social perfecta.", tips: "Tomar decisiones." },
  "gemini_scorpio": { score: 35, desc: "Aire + Agua. Superficialidad vs Profundidad. Desconfianza.", tips: "Honestidad total." },
  "gemini_sagittarius": { score: 90, desc: "Aire + Fuego. Opuestos complementarios. Aventuras y aprendizaje.", tips: "Compromiso real." },
  "capricorn_gemini": { score: 30, desc: "Aire + Tierra. El niño y el anciano. Muy diferentes.", tips: "Madurez." },
  "aquarius_gemini": { score: 95, desc: "Aire + Aire. Conexión mental instantánea. Libertad total.", tips: "Conectar emocionalmente." },
  "gemini_pisces": { score: 50, desc: "Aire + Agua. Lógica vs Fantasía. Confusión frecuente.", tips: "Claridad." },

  // CÁNCER
  "cancer_cancer": { score: 90, desc: "Agua + Agua. Comprensión emocional total, pero riesgo de drama.", tips: "Salir del caparazón." },
  "cancer_leo": { score: 70, desc: "Agua + Fuego. El Sol y la Luna. Protección y calidez.", tips: "Respetar roles." },
  "cancer_virgo": { score: 85, desc: "Agua + Tierra. Cuidado mutuo y servicio. Relación sana.", tips: "Menos preocupación." },
  "cancer_libra": { score: 60, desc: "Agua + Aire. Diferentes formas de ver el conflicto.", tips: "Comunicar necesidades." },
  "cancer_scorpio": { score: 98, desc: "Agua + Agua. Conexión psíquica y profunda. Amor eterno.", tips: "Confianza ciega." },
  "cancer_sagittarius": { score: 30, desc: "Agua + Fuego. Hogareño vs Viajero. Inseguridad para Cáncer.", tips: "Aventuras cortas." },
  "cancer_capricorn": { score: 85, desc: "Agua + Tierra. Opuestos complementarios. Estructura y emoción.", tips: "Equilibrio trabajo-hogar." },
  "aquarius_cancer": { score: 35, desc: "Agua + Aire. Desapego vs Apego. Cáncer sufre por frialdad.", tips: "Independencia." },
  "cancer_pisces": { score: 95, desc: "Agua + Agua. Romance de cuento de hadas. Empatía total.", tips: "Poner límites." },

  // LEO
  "leo_leo": { score: 80, desc: "Fuego + Fuego. Dos reyes en un castillo. Pasión y drama.", tips: "Compartir el trono." },
  "leo_virgo": { score: 45, desc: "Fuego + Tierra. Extravagancia vs Austeridad. Críticas duelen.", tips: "Valorar detalles." },
  "leo_libra": { score: 90, desc: "Fuego + Aire. Pareja elegante y social. Brillo compartido.", tips: "Gastar con cuidado." },
  "leo_scorpio": { score: 60, desc: "Fuego + Agua. Intensidad volcánica. Amor-Odio posible.", tips: "Bajar el ego." },
  "leo_sagittarius": { score: 95, desc: "Fuego + Fuego. Diversión, viajes y optimismo. Pareja feliz.", tips: "Libertad mutua." },
  "capricorn_leo": { score: 50, desc: "Fuego + Tierra. Ambición compartida pero métodos opuestos.", tips: "Respeto mutuo." },
  "aquarius_leo": { score: 85, desc: "Fuego + Aire. Opuestos complementarios. Individualidad y brillo.", tips: "Causas comunes." },
  "leo_pisces": { score: 65, desc: "Fuego + Agua. Leo protege, Piscis adora. Drama romántico.", tips: "Realismo." },

  // VIRGO
  "virgo_virgo": { score: 85, desc: "Tierra + Tierra. Perfección y orden. Rutina impecable.", tips: "Relajarse juntos." },
  "libra_virgo": { score: 65, desc: "Tierra + Aire. Estética y orden. Falta pasión a veces.", tips: "Espontaneidad." },
  "scorpio_virgo": { score: 90, desc: "Tierra + Agua. Lealtad y profundidad. Conexión fuerte.", tips: "Abrirse emocionalmente." },
  "sagittarius_virgo": { score: 35, desc: "Tierra + Fuego. Detalles vs Panorama general. Irritación.", tips: "Tolerancia." },
  "capricorn_virgo": { score: 95, desc: "Tierra + Tierra. Equipo perfecto. Éxito y estabilidad.", tips: "Expresar amor." },
  "aquarius_virgo": { score: 40, desc: "Tierra + Aire. Convencional vs Rebelde. Incomprensión.", tips: "Mente abierta." },
  "pisces_virgo": { score: 85, desc: "Tierra + Agua. Opuestos complementarios. Sanación y servicio.", tips: "Soñar juntos." },

  // LIBRA
  "libra_libra": { score: 90, desc: "Aire + Aire. Belleza, armonía y paz. Indecisión doble.", tips: "Tomar acción." },
  "libra_scorpio": { score: 60, desc: "Aire + Agua. Fascinación mutua pero celos vs coqueteo.", tips: "Claridad." },
  "libra_sagittarius": { score: 90, desc: "Aire + Fuego. Social, divertido y libre. Gran pareja.", tips: "Compromiso." },
  "capricorn_libra": { score: 55, desc: "Aire + Tierra. Estatus social importante para ambos. Frío.", tips: "Calidez." },
  "aquarius_libra": { score: 95, desc: "Aire + Aire. Conexión intelectual y social perfecta.", tips: "Intimidad." },
  "libra_pisces": { score: 70, desc: "Aire + Agua. Romance y fantasía. Falta tierra.", tips: "Pagar facturas." },

  // ESCORPIO
  "scorpio_scorpio": { score: 80, desc: "Agua + Agua. Intensidad nuclear. O todo o nada.", tips: "Perdonar." },
  "sagittarius_scorpio": { score: 40, desc: "Agua + Fuego. Optimismo vs Realismo oscuro. Difícil.", tips: "Respetar espacios." },
  "capricorn_scorpio": { score: 95, desc: "Agua + Tierra. Pareja poderosa y ambiciosa. Lealtad total.", tips: "Suavidad." },
  "aquarius_scorpio": { score: 30, desc: "Agua + Aire. Control vs Libertad. Choque frontal.", tips: "Aceptación." },
  "pisces_scorpio": { score: 98, desc: "Agua + Agua. Almas gemelas. Conexión sin palabras.", tips: "No aislarse." },

  // SAGITARIO
  "sagittarius_sagittarius": { score: 90, desc: "Fuego + Fuego. Aventura total. ¿Quién paga las cuentas?", tips: "Responsabilidad." },
  "capricorn_sagittarius": { score: 45, desc: "Fuego + Tierra. Expansión vs Restricción. Frustrante.", tips: "Metas comunes." },
  "aquarius_sagittarius": { score: 95, desc: "Fuego + Aire. Libertad, ideales y amistad. Excelente.", tips: "Constancia." },
  "pisces_sagittarius": { score: 60, desc: "Fuego + Agua. Ambos regidos por Júpiter. Sueños grandes.", tips: "Realidad." },

  // CAPRICORNIO
  "capricorn_capricorn": { score: 90, desc: "Tierra + Tierra. Imperio en construcción. Seriedad.", tips: "Jugar más." },
  "aquarius_capricorn": { score: 50, desc: "Tierra + Aire. Tradición vs Futuro. Respeto intelectual.", tips: "Innovar." },
  "capricorn_pisces": { score: 85, desc: "Tierra + Agua. Capricornio da estructura, Piscis da magia.", tips: "Sensibilidad." },

  // ACUARIO
  "aquarius_aquarius": { score: 85, desc: "Aire + Aire. Visionarios excéntricos. Mejor amigos que amantes.", tips: "Pasión." },
  "aquarius_pisces": { score: 65, desc: "Aire + Agua. Intelecto vs Emoción. Fascinación extraña.", tips: "Conexión real." },

  // PISCIS
  "pisces_pisces": { score: 90, desc: "Agua + Agua. Océano de emociones. Telepatía y caos.", tips: "Anclarse a tierra." }
};
