/**
 * Base de Datos Jerárquica Unificada de Tarot
 * Estructura: Sección -> Tarot -> Carta -> Signo -> Variante
 * 
 * Este archivo contiene la base de conocimiento completa y jerárquica
 * para todas las interpretaciones de tarot en el sistema.
 */

export type TarotType = 'rws' | 'marseille' | 'angels' | 'spanish';
export type Section = 'mesa' | 'amor' | 'dinero' | 'trabajo' | 'salud' | 'decisiones' | 'consejo' | 'pasado_presente_futuro';
export type Variant = 'luz' | 'sombra' | 'equilibrio';
export type Element = 'fuego' | 'tierra' | 'aire' | 'agua';
export type ZodiacSign = 'aries' | 'tauro' | 'geminis' | 'cancer' | 'leo' | 'virgo' | 'libra' | 'escorpio' | 'sagitario' | 'capricornio' | 'acuario' | 'piscis';

/**
 * Interfaz para una interpretación completa de carta
 */
export interface CardInterpretation {
  general: string;
  love?: string;
  money?: string;
  work?: string;
  health?: string;
  advice: string;
  keywords: string[];
}

/**
 * Interfaz para variantes de una interpretación
 */
export interface InterpretationVariants {
  luz: CardInterpretation;
  sombra: CardInterpretation;
  equilibrio: CardInterpretation;
}

/**
 * Interfaz para interpretaciones por signo zodiacal
 */
export interface SignSpecificInterpretation {
  [key in ZodiacSign]?: InterpretationVariants;
}

/**
 * Interfaz para interpretaciones por elemento
 */
export interface ElementSpecificInterpretation {
  [key in Element]?: InterpretationVariants;
}

/**
 * Interfaz para una carta completa con todas sus interpretaciones
 */
export interface TarotCardComplete {
  id: string;
  name: string;
  suit?: string;
  number?: number;
  isReversed?: boolean;
  // Interpretaciones por sección
  sections: {
    [key in Section]?: {
      // Interpretación genérica (por defecto)
      generic: InterpretationVariants;
      // Interpretaciones específicas por signo
      bySign: SignSpecificInterpretation;
      // Interpretaciones específicas por elemento
      byElement: ElementSpecificInterpretation;
    };
  };
}

/**
 * Mapeo de signos zodiacales a elementos
 */
export const ZODIAC_TO_ELEMENT: Record<ZodiacSign, Element> = {
  aries: 'fuego',
  leo: 'fuego',
  sagitario: 'fuego',
  tauro: 'tierra',
  virgo: 'tierra',
  capricornio: 'tierra',
  geminis: 'aire',
  libra: 'aire',
  acuario: 'aire',
  cancer: 'agua',
  escorpio: 'agua',
  piscis: 'agua',
};

/**
 * Características de cada signo zodiacal
 */
export const ZODIAC_CHARACTERISTICS: Record<ZodiacSign, {
  element: Element;
  ruling_planet: string;
  traits: string[];
  strengths: string[];
  challenges: string[];
}> = {
  aries: {
    element: 'fuego',
    ruling_planet: 'Marte',
    traits: ['valiente', 'impulsivo', 'apasionado', 'competitivo'],
    strengths: ['liderazgo', 'iniciativa', 'energía', 'determinación'],
    challenges: ['impaciencia', 'agresividad', 'impulsividad'],
  },
  tauro: {
    element: 'tierra',
    ruling_planet: 'Venus',
    traits: ['estable', 'práctico', 'sensual', 'leal'],
    strengths: ['paciencia', 'confiabilidad', 'estabilidad', 'sensibilidad'],
    challenges: ['terquedad', 'posesividad', 'resistencia al cambio'],
  },
  geminis: {
    element: 'aire',
    ruling_planet: 'Mercurio',
    traits: ['comunicativo', 'versátil', 'intelectual', 'curioso'],
    strengths: ['adaptabilidad', 'comunicación', 'agilidad mental', 'flexibilidad'],
    challenges: ['superficialidad', 'inconsistencia', 'nerviosismo'],
  },
  cancer: {
    element: 'agua',
    ruling_planet: 'Luna',
    traits: ['emocional', 'intuitivo', 'protector', 'nostálgico'],
    strengths: ['empatía', 'intuición', 'lealtad', 'sensibilidad'],
    challenges: ['melancolía', 'dependencia emocional', 'susceptibilidad'],
  },
  leo: {
    element: 'fuego',
    ruling_planet: 'Sol',
    traits: ['generoso', 'creativo', 'orgulloso', 'carismático'],
    strengths: ['liderazgo', 'creatividad', 'confianza', 'generosidad'],
    challenges: ['orgullo', 'arrogancia', 'necesidad de atención'],
  },
  virgo: {
    element: 'tierra',
    ruling_planet: 'Mercurio',
    traits: ['analítico', 'práctico', 'perfeccionista', 'servicial'],
    strengths: ['análisis', 'precisión', 'organización', 'dedicación'],
    challenges: ['crítica excesiva', 'perfeccionismo', 'ansiedad'],
  },
  libra: {
    element: 'aire',
    ruling_planet: 'Venus',
    traits: ['equilibrado', 'diplomático', 'artístico', 'indeciso'],
    strengths: ['equilibrio', 'diplomacia', 'belleza', 'justicia'],
    challenges: ['indecisión', 'dependencia', 'superficialidad'],
  },
  escorpio: {
    element: 'agua',
    ruling_planet: 'Plutón',
    traits: ['intenso', 'misterioso', 'apasionado', 'transformador'],
    strengths: ['intensidad', 'determinación', 'intuición', 'transformación'],
    challenges: ['obsesión', 'celos', 'resentimiento'],
  },
  sagitario: {
    element: 'fuego',
    ruling_planet: 'Júpiter',
    traits: ['optimista', 'aventurero', 'filosófico', 'expansivo'],
    strengths: ['optimismo', 'aventura', 'sabiduría', 'expansión'],
    challenges: ['impulsividad', 'falta de tacto', 'exceso'],
  },
  capricornio: {
    element: 'tierra',
    ruling_planet: 'Saturno',
    traits: ['ambicioso', 'disciplinado', 'responsable', 'conservador'],
    strengths: ['disciplina', 'responsabilidad', 'ambición', 'estabilidad'],
    challenges: ['rigidez', 'pesimismo', 'frialdad emocional'],
  },
  acuario: {
    element: 'aire',
    ruling_planet: 'Urano',
    traits: ['innovador', 'independiente', 'humanitario', 'excéntrico'],
    strengths: ['innovación', 'independencia', 'humanitarismo', 'originalidad'],
    challenges: ['distanciamiento', 'rebeldía', 'impersonalidad'],
  },
  piscis: {
    element: 'agua',
    ruling_planet: 'Neptuno',
    traits: ['soñador', 'empático', 'artístico', 'espiritual'],
    strengths: ['empatía', 'creatividad', 'espiritualidad', 'compasión'],
    challenges: ['escapismo', 'confusión', 'falta de límites'],
  },
};

/**
 * Características de cada elemento
 */
export const ELEMENT_CHARACTERISTICS: Record<Element, {
  traits: string[];
  approach: string;
  focus: string;
  keywords: string[];
}> = {
  fuego: {
    traits: ['apasionado', 'activo', 'impulsivo', 'transformador'],
    approach: 'Acción inmediata, movimiento, energía',
    focus: 'Inspiración, creatividad, pasión',
    keywords: ['acción', 'energía', 'transformación', 'pasión', 'movimiento'],
  },
  tierra: {
    traits: ['práctico', 'estable', 'sensorial', 'material'],
    approach: 'Análisis cuidadoso, construcción sólida, paciencia',
    focus: 'Recursos, materialidad, estabilidad',
    keywords: ['estabilidad', 'materialidad', 'paciencia', 'construcción', 'recursos'],
  },
  aire: {
    traits: ['intelectual', 'comunicativo', 'versátil', 'abstracto'],
    approach: 'Análisis mental, comunicación clara, perspectiva',
    focus: 'Pensamiento, comunicación, perspectiva',
    keywords: ['pensamiento', 'comunicación', 'perspectiva', 'inteligencia', 'claridad'],
  },
  agua: {
    traits: ['emocional', 'intuitivo', 'sensible', 'fluido'],
    approach: 'Intuición, empatía, flujo emocional',
    focus: 'Emociones, relaciones, intuición',
    keywords: ['emoción', 'intuición', 'relaciones', 'flujo', 'sensibilidad'],
  },
};

/**
 * Clase para gestionar la base de datos de tarot
 */
export class TarotDatabaseManager {
  private database: Map<string, TarotCardComplete> = new Map();

  /**
   * Registrar una carta en la base de datos
   */
  registerCard(card: TarotCardComplete): void {
    this.database.set(card.id, card);
  }

  /**
   * Obtener una carta por ID
   */
  getCard(cardId: string): TarotCardComplete | undefined {
    return this.database.get(cardId);
  }

  /**
   * Obtener interpretación de una carta para una sección específica
   */
  getInterpretation(
    cardId: string,
    section: Section,
    sign?: ZodiacSign,
    variant: Variant = 'equilibrio'
  ): CardInterpretation | null {
    const card = this.getCard(cardId);
    if (!card) return null;

    const sectionData = card.sections[section];
    if (!sectionData) return null;

    // Si hay un signo específico, intentar obtener interpretación por signo
    if (sign && sectionData.bySign[sign]) {
      return sectionData.bySign[sign]![variant];
    }

    // Si hay un elemento, intentar obtener interpretación por elemento
    const element = ZODIAC_TO_ELEMENT[sign || 'aries'];
    if (element && sectionData.byElement[element]) {
      return sectionData.byElement[element]![variant];
    }

    // Fallback a interpretación genérica
    return sectionData.generic[variant];
  }

  /**
   * Obtener todas las variantes de una interpretación
   */
  getVariants(
    cardId: string,
    section: Section,
    sign?: ZodiacSign
  ): InterpretationVariants | null {
    const card = this.getCard(cardId);
    if (!card) return null;

    const sectionData = card.sections[section];
    if (!sectionData) return null;

    // Si hay un signo específico, intentar obtener variantes por signo
    if (sign && sectionData.bySign[sign]) {
      return sectionData.bySign[sign]!;
    }

    // Si hay un elemento, intentar obtener variantes por elemento
    const element = ZODIAC_TO_ELEMENT[sign || 'aries'];
    if (element && sectionData.byElement[element]) {
      return sectionData.byElement[element]!;
    }

    // Fallback a variantes genéricas
    return sectionData.generic;
  }

  /**
   * Obtener todas las cartas
   */
  getAllCards(): TarotCardComplete[] {
    return Array.from(this.database.values());
  }

  /**
   * Obtener cartas por tipo de tarot
   */
  getCardsByType(tarotType: TarotType): TarotCardComplete[] {
    return this.getAllCards().filter(card => {
      // Lógica para filtrar por tipo de tarot
      // Esto se puede expandir según sea necesario
      return true;
    });
  }

  /**
   * Validar que una carta tenga todas las secciones requeridas
   */
  validateCard(card: TarotCardComplete): boolean {
    const requiredSections: Section[] = ['mesa', 'amor', 'dinero', 'trabajo', 'consejo'];
    
    for (const section of requiredSections) {
      if (!card.sections[section]) {
        console.warn(`Carta ${card.id} no tiene sección ${section}`);
        return false;
      }
    }

    return true;
  }
}

/**
 * Instancia global del gestor de base de datos
 */
export const tarotDB = new TarotDatabaseManager();

/**
 * Función helper para crear una interpretación de variantes
 */
export function createVariants(
  luz: CardInterpretation,
  sombra: CardInterpretation,
  equilibrio: CardInterpretation
): InterpretationVariants {
  return { luz, sombra, equilibrio };
}

/**
 * Función helper para crear una interpretación completa
 */
export function createCardInterpretation(
  general: string,
  advice: string,
  keywords: string[],
  love?: string,
  money?: string,
  work?: string,
  health?: string
): CardInterpretation {
  return {
    general,
    love,
    money,
    work,
    health,
    advice,
    keywords,
  };
}
