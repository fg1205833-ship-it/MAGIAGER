// Base de datos completa: 78 Cartas Tarot Rider-Waite + 40 Cartas Baraja Española

export interface TarotCard {
  id: number;
  name: string;
  suit?: string; // Para arcanos menores
  number?: number;
  meaning: string;
  love: string;
  work: string;
  money: string;
  advice: string;
  reversed?: string;
  keywords: string[];
  imageUrl?: string;
}

// --- ARCANOS MAYORES (22 Cartas) ---
export const majorArcana: TarotCard[] = [
  { id: 0, name: "El Loco", meaning: "Comienzos, saltos de fe, espontaneidad.", love: "Romance inesperado y apasionado.", work: "Nuevos proyectos arriesgados.", money: "Inversiones aventureras.", advice: "Confía en el universo.", keywords: ["Inicio", "Fe", "Libertad"], reversed: "Imprudencia, falta de dirección." },
  { id: 1, name: "El Mago", meaning: "Poder personal, manifestación, habilidad.", love: "Atracción magnética, seducción.", work: "Éxito mediante la inteligencia.", money: "Ganancias por habilidad.", advice: "Usa tu poder con sabiduría.", keywords: ["Poder", "Acción", "Ingenio"], reversed: "Manipulación, engaño." },
  { id: 2, name: "La Sacerdotisa", meaning: "Intuición, misterio, sabiduría interior.", love: "Secretos, conexión emocional profunda.", work: "Investigación, análisis profundo.", money: "Ganancias inesperadas.", advice: "Escucha tu intuición.", keywords: ["Intuición", "Misterio", "Silencio"], reversed: "Ignorancia, superficialidad." },
  { id: 3, name: "La Emperatriz", meaning: "Fertilidad, abundancia, creatividad.", love: "Relación fértil y amorosa.", work: "Crecimiento y expansión.", money: "Prosperidad material.", advice: "Nutre tus creaciones.", keywords: ["Abundancia", "Belleza", "Naturaleza"], reversed: "Infertilidad, bloqueo creativo." },
  { id: 4, name: "El Emperador", meaning: "Autoridad, estructura, poder terrenal.", love: "Relación estable y comprometida.", work: "Liderazgo y control.", money: "Estabilidad financiera.", advice: "Sé firme en tus decisiones.", keywords: ["Autoridad", "Orden", "Control"], reversed: "Debilidad, falta de control." },
  { id: 5, name: "El Sumo Sacerdote", meaning: "Tradición, espiritualidad, enseñanza.", love: "Compromiso serio y matrimonio.", work: "Mentoría y enseñanza.", money: "Ganancias por sabiduría.", advice: "Busca la verdad espiritual.", keywords: ["Tradición", "Sabiduría", "Fe"], reversed: "Dogmatismo, rigidez." },
  { id: 6, name: "Los Enamorados", meaning: "Amor, elección, armonía.", love: "Amor verdadero y profundo.", work: "Asociaciones beneficiosas.", money: "Decisiones financieras acertadas.", advice: "Elige desde el corazón.", keywords: ["Amor", "Elección", "Unión"], reversed: "Separación, conflicto." },
  { id: 7, name: "El Carro", meaning: "Victoria, determinación, movimiento.", love: "Conquista amorosa.", work: "Avance rápido en carrera.", money: "Éxito financiero rotundo.", advice: "Toma las riendas de tu vida.", keywords: ["Victoria", "Control", "Movimiento"], reversed: "Obstáculos, falta de dirección." },
  { id: 8, name: "La Fuerza", meaning: "Coraje, compasión, paciencia.", love: "Relación apasionada pero equilibrada.", work: "Persistencia y resiliencia.", money: "Estabilidad mediante esfuerzo.", advice: "La verdadera fuerza es interior.", keywords: ["Coraje", "Paciencia", "Control"], reversed: "Debilidad, impotencia." },
  { id: 9, name: "El Ermitaño", meaning: "Introspección, soledad, guía interior.", love: "Necesidad de espacio personal.", work: "Trabajo solitario y reflexivo.", money: "Ganancias por análisis profundo.", advice: "La respuesta está dentro de ti.", keywords: ["Introspección", "Soledad", "Búsqueda"], reversed: "Aislamiento excesivo." },
  { id: 10, name: "Rueda de la Fortuna", meaning: "Cambio, destino, ciclos.", love: "Encuentros kármicos.", work: "Cambios inesperados.", money: "Giros de fortuna.", advice: "Fluye con los cambios.", keywords: ["Cambio", "Destino", "Ciclos"], reversed: "Mala suerte, estancamiento." },
  { id: 11, name: "La Justicia", meaning: "Verdad, equilibrio, ley.", love: "Trato justo en la pareja.", work: "Contratos y negociaciones.", money: "Justicia financiera.", advice: "Actúa con integridad.", keywords: ["Verdad", "Equilibrio", "Ley"], reversed: "Injusticia, parcialidad." },
  { id: 12, name: "El Colgado", meaning: "Pausa, sacrificio, nueva perspectiva.", love: "Estancamiento temporal.", work: "Proyectos en pausa.", money: "Retención de dinero.", advice: "Cambia tu perspectiva.", keywords: ["Pausa", "Sacrificio", "Espera"], reversed: "Liberación, movimiento." },
  { id: 13, name: "La Muerte", meaning: "Transformación, finales, renacimiento.", love: "Fin de una etapa relacional.", work: "Cambio radical de carrera.", money: "Transformación financiera.", advice: "Suelta lo viejo para lo nuevo.", keywords: ["Transformación", "Fin", "Renacimiento"], reversed: "Estancamiento, resistencia." },
  { id: 14, name: "La Templanza", meaning: "Equilibrio, moderación, paciencia.", love: "Relación tranquila y sanadora.", work: "Colaboración armoniosa.", money: "Equilibrio financiero.", advice: "Ten paciencia, todo llega.", keywords: ["Equilibrio", "Moderación", "Paciencia"], reversed: "Desequilibrio, exceso." },
  { id: 15, name: "El Diablo", meaning: "Apegos, sombra, tentación.", love: "Pasión obsesiva o tóxica.", work: "Sentirse atrapado laboralmente.", money: "Deudas y ataduras.", advice: "Rompe tus cadenas.", keywords: ["Apego", "Sombra", "Tentación"], reversed: "Liberación, ruptura." },
  { id: 16, name: "La Torre", meaning: "Caos, ruptura, revelación.", love: "Ruptura inesperada.", work: "Pérdida de empleo.", money: "Pérdida financiera.", advice: "Lo que cae, debe caer.", keywords: ["Caos", "Ruptura", "Verdad"], reversed: "Estabilización, recuperación." },
  { id: 17, name: "La Estrella", meaning: "Esperanza, inspiración, fe.", love: "Amor puro y sanador.", work: "Inspiración creativa.", money: "Esperanza financiera.", advice: "Mantén la fe en ti.", keywords: ["Esperanza", "Inspiración", "Fe"], reversed: "Desesperanza, duda." },
  { id: 18, name: "La Luna", meaning: "Ilusión, miedo, intuición.", love: "Confusión emocional.", work: "Ambiente confuso.", money: "Incertidumbre financiera.", advice: "Enfrenta tus miedos.", keywords: ["Ilusión", "Miedo", "Intuición"], reversed: "Claridad, verdad." },
  { id: 19, name: "El Sol", meaning: "Alegría, éxito, claridad.", love: "Amor pleno y feliz.", work: "Éxito y reconocimiento.", money: "Prosperidad radiante.", advice: "Disfruta tu luz.", keywords: ["Alegría", "Éxito", "Claridad"], reversed: "Oscuridad, fracaso." },
  { id: 20, name: "El Juicio", meaning: "Renacimiento, llamado, evaluación.", love: "Reconciliación o nueva etapa.", work: "Descubrimiento de vocación.", money: "Evaluación financiera.", advice: "Escucha tu llamado.", keywords: ["Renacimiento", "Llamado", "Verdad"], reversed: "Negación, retraso." },
  { id: 21, name: "El Mundo", meaning: "Completitud, logro, viaje.", love: "Unión cósmica, matrimonio.", work: "Meta alcanzada.", money: "Éxito total.", advice: "Celebra tu logro.", keywords: ["Completitud", "Logro", "Viaje"], reversed: "Incompletitud, demora." }
];

// --- ARCANOS MENORES: COPAS (14 Cartas) ---
export const cupsCards: TarotCard[] = [
  { id: 22, name: "As de Copas", suit: "Copas", number: 1, meaning: "Nuevo amor, inspiración emocional.", love: "Nuevo romance o profundización.", work: "Inspiración creativa.", money: "Oportunidad emocional.", advice: "Abre tu corazón.", keywords: ["Nuevo", "Amor", "Inspiración"], reversed: "Bloqueo emocional." },
  { id: 23, name: "Dos de Copas", suit: "Copas", number: 2, meaning: "Unión, asociación, amor.", love: "Pareja armoniosa.", work: "Asociación beneficiosa.", money: "Acuerdo financiero.", advice: "Celebra la unión.", keywords: ["Unión", "Asociación", "Amor"], reversed: "Separación, desacuerdo." },
  { id: 24, name: "Tres de Copas", suit: "Copas", number: 3, meaning: "Celebración, amistad, alegría.", love: "Diversión en pareja.", work: "Celebración laboral.", money: "Ganancias compartidas.", advice: "Celebra con otros.", keywords: ["Celebración", "Amistad", "Alegría"], reversed: "Aislamiento, tristeza." },
  { id: 25, name: "Cuatro de Copas", suit: "Copas", number: 4, meaning: "Apatía, reflexión, oportunidad rechazada.", love: "Desinterés temporal.", work: "Falta de motivación.", money: "Oportunidad no vista.", advice: "Abre los ojos.", keywords: ["Apatía", "Reflexión", "Rechazo"], reversed: "Aceptación, movimiento." },
  { id: 26, name: "Cinco de Copas", suit: "Copas", number: 5, meaning: "Pérdida, duelo, tristeza.", love: "Ruptura emocional.", work: "Decepción laboral.", money: "Pérdida financiera.", advice: "Permite el duelo.", keywords: ["Pérdida", "Duelo", "Tristeza"], reversed: "Recuperación, esperanza." },
  { id: 27, name: "Seis de Copas", suit: "Copas", number: 6, meaning: "Nostalgia, inocencia, generosidad.", love: "Amor del pasado resurge.", work: "Mentoría y enseñanza.", money: "Herencia o regalo.", advice: "Honra el pasado.", keywords: ["Nostalgia", "Inocencia", "Generosidad"], reversed: "Resentimiento, apego." },
  { id: 28, name: "Siete de Copas", suit: "Copas", number: 7, meaning: "Ilusión, tentación, fantasía.", love: "Ilusiones románticas.", work: "Opciones confusas.", money: "Tentaciones financieras.", advice: "Distingue realidad de ilusión.", keywords: ["Ilusión", "Tentación", "Fantasía"], reversed: "Claridad, verdad." },
  { id: 29, name: "Ocho de Copas", suit: "Copas", number: 8, meaning: "Abandono, búsqueda, partida.", love: "Alejamiento emocional.", work: "Cambio de trabajo.", money: "Inversión en nuevo proyecto.", advice: "A veces hay que partir.", keywords: ["Abandono", "Búsqueda", "Partida"], reversed: "Retorno, reconciliación." },
  { id: 30, name: "Nueve de Copas", suit: "Copas", number: 9, meaning: "Deseo cumplido, satisfacción, abundancia.", love: "Felicidad en pareja.", work: "Satisfacción laboral.", money: "Abundancia emocional.", advice: "Disfruta lo que tienes.", keywords: ["Deseo", "Satisfacción", "Abundancia"], reversed: "Insatisfacción, exceso." },
  { id: 31, name: "Diez de Copas", suit: "Copas", number: 10, meaning: "Armonía familiar, felicidad, hogar.", love: "Familia feliz.", work: "Ambiente laboral armónico.", money: "Estabilidad familiar.", advice: "Cultiva la armonía.", keywords: ["Armonía", "Familia", "Hogar"], reversed: "Conflicto familiar." },
  { id: 32, name: "Sota de Copas", suit: "Copas", number: 11, meaning: "Joven sensible, mensaje emocional.", love: "Persona joven y sensible.", work: "Mensaje importante.", money: "Noticia emocional.", advice: "Escucha los mensajes.", keywords: ["Joven", "Sensible", "Mensaje"], reversed: "Inmadurez, engaño." },
  { id: 33, name: "Caballo de Copas", suit: "Copas", number: 12, meaning: "Propuesta, invitación, romance.", love: "Propuesta amorosa.", work: "Invitación profesional.", money: "Oportunidad romántica.", advice: "Acepta la invitación.", keywords: ["Propuesta", "Invitación", "Romance"], reversed: "Rechazo, demora." },
  { id: 34, name: "Reina de Copas", suit: "Copas", number: 13, meaning: "Mujer emocional, intuitiva, compasiva.", love: "Mujer amorosa y comprensiva.", work: "Liderazgo empático.", money: "Generosidad financiera.", advice: "Confía en tu intuición.", keywords: ["Mujer", "Intuición", "Compasión"], reversed: "Manipulación emocional." },
  { id: 35, name: "Rey de Copas", suit: "Copas", number: 14, meaning: "Hombre emocional, artístico, sabio.", love: "Hombre sensible y amoroso.", work: "Liderazgo creativo.", money: "Éxito artístico.", advice: "Expresa tus emociones.", keywords: ["Hombre", "Emocional", "Sabio"], reversed: "Inestabilidad emocional." }
];

// --- ARCANOS MENORES: ESPADAS (14 Cartas) ---
export const swordsCards: TarotCard[] = [
  { id: 36, name: "As de Espadas", suit: "Espadas", number: 1, meaning: "Verdad, claridad, nuevo comienzo mental.", love: "Verdad revelada.", work: "Claridad en decisiones.", money: "Oportunidad clara.", advice: "Busca la verdad.", keywords: ["Verdad", "Claridad", "Comienzo"], reversed: "Confusión, engaño." },
  { id: 37, name: "Dos de Espadas", suit: "Espadas", number: 2, meaning: "Indecisión, equilibrio, dilema.", love: "Indecisión en pareja.", work: "Decisión difícil.", money: "Dilema financiero.", advice: "Toma una decisión.", keywords: ["Indecisión", "Dilema", "Equilibrio"], reversed: "Decisión tomada." },
  { id: 38, name: "Tres de Espadas", suit: "Espadas", number: 3, meaning: "Dolor, separación, conflicto.", love: "Ruptura, dolor emocional.", work: "Conflicto laboral.", money: "Pérdida económica.", advice: "Enfrenta el dolor.", keywords: ["Dolor", "Separación", "Conflicto"], reversed: "Reconciliación, sanación." },
  { id: 39, name: "Cuatro de Espadas", suit: "Espadas", number: 4, meaning: "Descanso, pausa, recuperación.", love: "Pausa en la relación.", work: "Descanso merecido.", money: "Pausa en inversiones.", advice: "Descansa y recuperate.", keywords: ["Descanso", "Pausa", "Recuperación"], reversed: "Inquietud, ansiedad." },
  { id: 40, name: "Cinco de Espadas", suit: "Espadas", number: 5, meaning: "Conflicto, derrota, tensión.", love: "Conflicto sin ganador.", work: "Tensión laboral.", money: "Pérdida en negociación.", advice: "Busca la paz.", keywords: ["Conflicto", "Derrota", "Tensión"], reversed: "Reconciliación, paz." },
  { id: 41, name: "Seis de Espadas", suit: "Espadas", number: 6, meaning: "Transición, viaje, movimiento.", love: "Separación temporal.", work: "Cambio de ubicación.", money: "Movimiento financiero.", advice: "El cambio llega.", keywords: ["Transición", "Viaje", "Movimiento"], reversed: "Estancamiento, demora." },
  { id: 42, name: "Siete de Espadas", suit: "Espadas", number: 7, meaning: "Engaño, estrategia, secreto.", love: "Infidelidad o secreto.", work: "Engaño laboral.", money: "Fraude financiero.", advice: "Cuidado con engaños.", keywords: ["Engaño", "Estrategia", "Secreto"], reversed: "Verdad revelada." },
  { id: 43, name: "Ocho de Espadas", suit: "Espadas", number: 8, meaning: "Restricción, prisión, limitación.", love: "Sentirse atrapado.", work: "Limitaciones laborales.", money: "Restricciones financieras.", advice: "Libérate.", keywords: ["Restricción", "Prisión", "Limitación"], reversed: "Libertad, liberación." },
  { id: 44, name: "Nueve de Espadas", suit: "Espadas", number: 9, meaning: "Ansiedad, pesadilla, preocupación.", love: "Ansiedad en pareja.", work: "Estrés laboral.", money: "Preocupación financiera.", advice: "Calma tu mente.", keywords: ["Ansiedad", "Pesadilla", "Preocupación"], reversed: "Paz mental, alivio." },
  { id: 45, name: "Diez de Espadas", suit: "Espadas", number: 10, meaning: "Fin, traición, crisis.", love: "Ruptura definitiva.", work: "Fin de proyecto.", money: "Pérdida total.", advice: "Un ciclo termina.", keywords: ["Fin", "Traición", "Crisis"], reversed: "Recuperación, nuevo comienzo." },
  { id: 46, name: "Sota de Espadas", suit: "Espadas", number: 11, meaning: "Joven inquisitivo, mensajero.", love: "Joven comunicativo.", work: "Noticia importante.", money: "Mensaje financiero.", advice: "Escucha el mensaje.", keywords: ["Joven", "Inquisitivo", "Mensaje"], reversed: "Engaño, confusión." },
  { id: 47, name: "Caballo de Espadas", suit: "Espadas", number: 12, meaning: "Acción rápida, conflicto, verdad.", love: "Confrontación necesaria.", work: "Acción decisiva.", money: "Negociación fuerte.", advice: "Sé directo.", keywords: ["Acción", "Conflicto", "Verdad"], reversed: "Impulsividad, arrogancia." },
  { id: 48, name: "Reina de Espadas", suit: "Espadas", number: 13, meaning: "Mujer inteligente, independiente, clara.", love: "Mujer independiente.", work: "Liderazgo intelectual.", money: "Éxito por inteligencia.", advice: "Piensa claramente.", keywords: ["Mujer", "Inteligencia", "Independencia"], reversed: "Frialdad, crueldad." },
  { id: 49, name: "Rey de Espadas", suit: "Espadas", number: 14, meaning: "Hombre inteligente, autoridad, verdad.", love: "Hombre intelectual.", work: "Autoridad inteligente.", money: "Éxito estratégico.", advice: "Sé lógico y justo.", keywords: ["Hombre", "Inteligencia", "Autoridad"], reversed: "Tiranía, crueldad." }
];

// --- ARCANOS MENORES: BASTOS (14 Cartas) ---
export const wandsCards: TarotCard[] = [
  { id: 50, name: "As de Bastos", suit: "Bastos", number: 1, meaning: "Inspiración, crecimiento, energía.", love: "Pasión despierta.", work: "Proyecto emocionante.", money: "Oportunidad de crecimiento.", advice: "Sigue tu inspiración.", keywords: ["Inspiración", "Crecimiento", "Energía"], reversed: "Bloqueo creativo." },
  { id: 51, name: "Dos de Bastos", suit: "Bastos", number: 2, meaning: "Planificación, decisión, poder.", love: "Decisión en relación.", work: "Plan de acción.", money: "Decisión financiera.", advice: "Planifica tu futuro.", keywords: ["Planificación", "Decisión", "Poder"], reversed: "Indecisión, demora." },
  { id: 52, name: "Tres de Bastos", suit: "Bastos", number: 3, meaning: "Expansión, visión, oportunidad.", love: "Relación que crece.", work: "Expansión laboral.", money: "Oportunidad de crecimiento.", advice: "Expande tus horizontes.", keywords: ["Expansión", "Visión", "Oportunidad"], reversed: "Limitación, demora." },
  { id: 53, name: "Cuatro de Bastos", suit: "Bastos", number: 4, meaning: "Celebración, armonía, comunidad.", love: "Celebración en pareja.", work: "Celebración laboral.", money: "Ganancia celebrada.", advice: "Celebra tu éxito.", keywords: ["Celebración", "Armonía", "Comunidad"], reversed: "Conflicto, discordia." },
  { id: 54, name: "Cinco de Bastos", suit: "Bastos", number: 5, meaning: "Conflicto, competencia, tensión.", love: "Conflicto en pareja.", work: "Competencia laboral.", money: "Lucha financiera.", advice: "Busca la armonía.", keywords: ["Conflicto", "Competencia", "Tensión"], reversed: "Resolución, paz." },
  { id: 55, name: "Seis de Bastos", suit: "Bastos", number: 6, meaning: "Reconocimiento, éxito, victoria.", love: "Admiración mutua.", work: "Reconocimiento profesional.", money: "Éxito financiero.", advice: "Acepta tu éxito.", keywords: ["Reconocimiento", "Éxito", "Victoria"], reversed: "Fracaso, humillación." },
  { id: 56, name: "Siete de Bastos", suit: "Bastos", number: 7, meaning: "Desafío, defensa, determinación.", love: "Defensa de la relación.", work: "Desafío laboral.", money: "Defensa de patrimonio.", advice: "Defiende tu posición.", keywords: ["Desafío", "Defensa", "Determinación"], reversed: "Rendición, debilidad." },
  { id: 57, name: "Ocho de Bastos", suit: "Bastos", number: 8, meaning: "Movimiento rápido, energía, acción.", love: "Relación que avanza.", work: "Acción rápida.", money: "Movimiento financiero.", advice: "Actúa rápido.", keywords: ["Movimiento", "Energía", "Acción"], reversed: "Demora, estancamiento." },
  { id: 58, name: "Nueve de Bastos", suit: "Bastos", number: 9, meaning: "Resistencia, perseverancia, fuerza.", love: "Relación que resiste.", work: "Perseverancia laboral.", money: "Estabilidad financiera.", advice: "Persevera.", keywords: ["Resistencia", "Perseverancia", "Fuerza"], reversed: "Debilidad, rendición." },
  { id: 59, name: "Diez de Bastos", suit: "Bastos", number: 10, meaning: "Carga, responsabilidad, peso.", love: "Relación pesada.", work: "Carga laboral.", money: "Responsabilidad financiera.", advice: "Suelta lo que no necesitas.", keywords: ["Carga", "Responsabilidad", "Peso"], reversed: "Alivio, liberación." },
  { id: 60, name: "Sota de Bastos", suit: "Bastos", number: 11, meaning: "Joven entusiasta, mensajero.", love: "Joven apasionado.", work: "Noticia emocionante.", money: "Oportunidad entusiasta.", advice: "Sigue tu entusiasmo.", keywords: ["Joven", "Entusiasta", "Mensaje"], reversed: "Impulsividad, inmadurez." },
  { id: 61, name: "Caballo de Bastos", suit: "Bastos", number: 12, meaning: "Acción, aventura, energía.", love: "Aventura amorosa.", work: "Acción enérgica.", money: "Inversión aventurera.", advice: "Sé aventurero.", keywords: ["Acción", "Aventura", "Energía"], reversed: "Impulsividad, prisa." },
  { id: 62, name: "Reina de Bastos", suit: "Bastos", number: 13, meaning: "Mujer apasionada, creativa, carismática.", love: "Mujer apasionada.", work: "Liderazgo carismático.", money: "Éxito creativo.", advice: "Sé auténtica.", keywords: ["Mujer", "Pasión", "Carisma"], reversed: "Manipulación, arrogancia." },
  { id: 63, name: "Rey de Bastos", suit: "Bastos", number: 14, meaning: "Hombre apasionado, líder, visionario.", love: "Hombre apasionado.", work: "Liderazgo visionario.", money: "Éxito empresarial.", advice: "Lidera con pasión.", keywords: ["Hombre", "Pasión", "Liderazgo"], reversed: "Tiranía, arrogancia." }
];

// --- ARCANOS MENORES: OROS (14 Cartas) ---
export const coinsCards: TarotCard[] = [
  { id: 64, name: "As de Oros", suit: "Oros", number: 1, meaning: "Oportunidad material, riqueza, prosperidad.", love: "Relación valiosa.", work: "Oportunidad económica.", money: "Prosperidad material.", advice: "Abre las puertas a la riqueza.", keywords: ["Oportunidad", "Riqueza", "Prosperidad"], reversed: "Pérdida, desperdicio." },
  { id: 65, name: "Dos de Oros", suit: "Oros", number: 2, meaning: "Equilibrio, flexibilidad, adaptación.", love: "Equilibrio en pareja.", work: "Adaptación laboral.", money: "Equilibrio financiero.", advice: "Mantén el equilibrio.", keywords: ["Equilibrio", "Flexibilidad", "Adaptación"], reversed: "Desequilibrio, caos." },
  { id: 66, name: "Tres de Oros", suit: "Oros", number: 3, meaning: "Colaboración, maestría, trabajo en equipo.", love: "Trabajo conjunto en pareja.", work: "Colaboración exitosa.", money: "Ganancia por asociación.", advice: "Trabaja en equipo.", keywords: ["Colaboración", "Maestría", "Equipo"], reversed: "Falta de cooperación." },
  { id: 67, name: "Cuatro de Oros", suit: "Oros", number: 4, meaning: "Avaricia, control, seguridad.", love: "Posesividad en pareja.", work: "Control excesivo.", money: "Acumulación de riqueza.", advice: "Suelta el control.", keywords: ["Avaricia", "Control", "Seguridad"], reversed: "Generosidad, liberación." },
  { id: 68, name: "Cinco de Oros", suit: "Oros", number: 5, meaning: "Pobreza, pérdida, dificultad.", love: "Dificultad económica.", work: "Pérdida laboral.", money: "Pérdida financiera.", advice: "Busca ayuda.", keywords: ["Pobreza", "Pérdida", "Dificultad"], reversed: "Recuperación, ayuda." },
  { id: 69, name: "Seis de Oros", suit: "Oros", number: 6, meaning: "Generosidad, caridad, compartir.", love: "Generosidad en pareja.", work: "Recompensa por trabajo.", money: "Ganancias compartidas.", advice: "Sé generoso.", keywords: ["Generosidad", "Caridad", "Compartir"], reversed: "Avaricia, deuda." },
  { id: 70, name: "Siete de Oros", suit: "Oros", number: 7, meaning: "Evaluación, paciencia, inversión.", love: "Evaluación de relación.", work: "Evaluación de proyecto.", money: "Inversión a largo plazo.", advice: "Ten paciencia.", keywords: ["Evaluación", "Paciencia", "Inversión"], reversed: "Impaciencia, fracaso." },
  { id: 71, name: "Ocho de Oros", suit: "Oros", number: 8, meaning: "Maestría, aprendizaje, dedicación.", love: "Dedicación en pareja.", work: "Aprendizaje y maestría.", money: "Ganancia por habilidad.", advice: "Dedícate a tu oficio.", keywords: ["Maestría", "Aprendizaje", "Dedicación"], reversed: "Falta de dedicación." },
  { id: 72, name: "Nueve de Oros", suit: "Oros", number: 9, meaning: "Abundancia, lujo, independencia.", love: "Relación próspera.", work: "Éxito independiente.", money: "Abundancia material.", advice: "Disfruta tu riqueza.", keywords: ["Abundancia", "Lujo", "Independencia"], reversed: "Dependencia, pérdida." },
  { id: 73, name: "Diez de Oros", suit: "Oros", number: 10, meaning: "Riqueza familiar, herencia, legado.", love: "Familia próspera.", work: "Legado empresarial.", money: "Herencia, riqueza familiar.", advice: "Construye tu legado.", keywords: ["Riqueza", "Familia", "Herencia"], reversed: "Pérdida familiar." },
  { id: 74, name: "Sota de Oros", suit: "Oros", number: 11, meaning: "Joven práctico, mensajero material.", love: "Joven responsable.", work: "Noticia económica.", money: "Oportunidad práctica.", advice: "Sé práctico.", keywords: ["Joven", "Práctico", "Mensaje"], reversed: "Irresponsabilidad." },
  { id: 75, name: "Caballo de Oros", suit: "Oros", number: 12, meaning: "Confiabilidad, responsabilidad, trabajo.", love: "Pareja confiable.", work: "Trabajo confiable.", money: "Ganancia segura.", advice: "Sé responsable.", keywords: ["Confiabilidad", "Responsabilidad", "Trabajo"], reversed: "Irresponsabilidad, negligencia." },
  { id: 76, name: "Reina de Oros", suit: "Oros", number: 13, meaning: "Mujer práctica, generosa, maternal.", love: "Mujer práctica y amorosa.", work: "Liderazgo práctico.", money: "Éxito por practicidad.", advice: "Sé práctica y generosa.", keywords: ["Mujer", "Práctica", "Generosidad"], reversed: "Avaricia, frialdad." },
  { id: 77, name: "Rey de Oros", suit: "Oros", number: 14, meaning: "Hombre próspero, confiable, generoso.", love: "Hombre próspero.", work: "Liderazgo empresarial.", money: "Éxito financiero.", advice: "Sé próspero y generoso.", keywords: ["Hombre", "Prosperidad", "Confiabilidad"], reversed: "Avaricia, negligencia." }
];

// --- BARAJA ESPAÑOLA (40 Cartas) ---
export interface SpanishCard {
  id: number;
  name: string;
  suit: string;
  number: number;
  meaning: string;
  love: string;
  work: string;
  money: string;
}

export const spanishDeck: SpanishCard[] = [
  // OROS (Dinero, Éxito, Materialidad)
  { id: 0, name: "As de Oros", suit: "Oros", number: 1, meaning: "Riqueza, éxito, oportunidad material.", love: "Relación valiosa.", work: "Oportunidad de negocio.", money: "Dinero que llega." },
  { id: 1, name: "Dos de Oros", suit: "Oros", number: 2, meaning: "Equilibrio financiero, cambios.", love: "Relación equilibrada.", work: "Cambios laborales.", money: "Equilibrio de dinero." },
  { id: 2, name: "Tres de Oros", suit: "Oros", number: 3, meaning: "Trabajo en equipo, éxito laboral.", love: "Trabajo conjunto.", work: "Éxito en proyecto.", money: "Ganancia por trabajo." },
  { id: 3, name: "Cuatro de Oros", suit: "Oros", number: 4, meaning: "Estabilidad, seguridad, avaricia.", love: "Seguridad en pareja.", work: "Estabilidad laboral.", money: "Dinero seguro." },
  { id: 4, name: "Cinco de Oros", suit: "Oros", number: 5, meaning: "Dificultad, pobreza, necesidad.", love: "Dificultad económica.", work: "Pérdida de empleo.", money: "Pérdida de dinero." },
  { id: 5, name: "Seis de Oros", suit: "Oros", number: 6, meaning: "Generosidad, regalo, ayuda.", love: "Regalo de amor.", work: "Recompensa.", money: "Dinero compartido." },
  { id: 6, name: "Siete de Oros", suit: "Oros", number: 7, meaning: "Paciencia, inversión, espera.", love: "Espera en relación.", work: "Inversión a largo plazo.", money: "Dinero invertido." },
  { id: 7, name: "Sota de Oros", suit: "Oros", number: 10, meaning: "Joven responsable, mensajero.", love: "Joven confiable.", work: "Noticia de dinero.", money: "Oportunidad económica." },
  { id: 8, name: "Caballo de Oros", suit: "Oros", number: 11, meaning: "Hombre práctico, trabajador.", love: "Hombre responsable.", work: "Colega confiable.", money: "Ganancia segura." },
  { id: 9, name: "Rey de Oros", suit: "Oros", number: 12, meaning: "Hombre rico, exitoso, generoso.", love: "Hombre próspero.", work: "Jefe exitoso.", money: "Gran riqueza." },
  
  // COPAS (Amor, Emociones, Relaciones)
  { id: 10, name: "As de Copas", suit: "Copas", number: 1, meaning: "Amor, alegría, nueva relación.", love: "Nuevo amor.", work: "Alegría laboral.", money: "Ganancia emocional." },
  { id: 11, name: "Dos de Copas", suit: "Copas", number: 2, meaning: "Unión, pareja, amor.", love: "Pareja armoniosa.", work: "Asociación.", money: "Acuerdo beneficioso." },
  { id: 12, name: "Tres de Copas", suit: "Copas", number: 3, meaning: "Celebración, amistad, alegría.", love: "Celebración en pareja.", work: "Celebración laboral.", money: "Ganancia celebrada." },
  { id: 13, name: "Cuatro de Copas", suit: "Copas", number: 4, meaning: "Reflexión, apatía, oportunidad.", love: "Reflexión en pareja.", work: "Falta de motivación.", money: "Oportunidad no vista." },
  { id: 14, name: "Cinco de Copas", suit: "Copas", number: 5, meaning: "Tristeza, pérdida, duelo.", love: "Ruptura, dolor.", work: "Decepción.", money: "Pérdida emocional." },
  { id: 15, name: "Seis de Copas", suit: "Copas", number: 6, meaning: "Nostalgia, inocencia, generosidad.", love: "Amor del pasado.", work: "Mentoría.", money: "Herencia." },
  { id: 16, name: "Siete de Copas", suit: "Copas", number: 7, meaning: "Ilusión, tentación, fantasía.", love: "Ilusiones románticas.", work: "Opciones confusas.", money: "Tentaciones." },
  { id: 17, name: "Sota de Copas", suit: "Copas", number: 10, meaning: "Joven sensible, mensajero emocional.", love: "Joven sensible.", work: "Mensaje emocional.", money: "Noticia importante." },
  { id: 18, name: "Caballo de Copas", suit: "Copas", number: 11, meaning: "Hombre emocional, artístico.", love: "Hombre sensible.", work: "Liderazgo creativo.", money: "Éxito artístico." },
  { id: 19, name: "Rey de Copas", suit: "Copas", number: 12, meaning: "Hombre sabio, emocional, compasivo.", love: "Hombre amoroso.", work: "Liderazgo empático.", money: "Éxito por sabiduría." },
  
  // ESPADAS (Conflicto, Verdad, Retos)
  { id: 20, name: "As de Espadas", suit: "Espadas", number: 1, meaning: "Verdad, claridad, nuevo comienzo.", love: "Verdad revelada.", work: "Claridad en decisiones.", money: "Oportunidad clara." },
  { id: 21, name: "Dos de Espadas", suit: "Espadas", number: 2, meaning: "Indecisión, dilema, equilibrio.", love: "Indecisión.", work: "Decisión difícil.", money: "Dilema financiero." },
  { id: 22, name: "Tres de Espadas", suit: "Espadas", number: 3, meaning: "Dolor, separación, conflicto.", love: "Ruptura, dolor.", work: "Conflicto.", money: "Pérdida." },
  { id: 23, name: "Cuatro de Espadas", suit: "Espadas", number: 4, meaning: "Descanso, pausa, recuperación.", love: "Pausa.", work: "Descanso.", money: "Pausa en inversiones." },
  { id: 24, name: "Cinco de Espadas", suit: "Espadas", number: 5, meaning: "Conflicto, derrota, tensión.", love: "Conflicto sin ganador.", work: "Tensión laboral.", money: "Lucha financiera." },
  { id: 25, name: "Seis de Espadas", suit: "Espadas", number: 6, meaning: "Transición, viaje, movimiento.", love: "Separación temporal.", work: "Cambio de ubicación.", money: "Movimiento financiero." },
  { id: 26, name: "Siete de Espadas", suit: "Espadas", number: 7, meaning: "Engaño, estrategia, secreto.", love: "Infidelidad.", work: "Engaño laboral.", money: "Fraude." },
  { id: 27, name: "Sota de Espadas", suit: "Espadas", number: 10, meaning: "Joven inquisitivo, espía.", love: "Joven curioso.", work: "Investigación.", money: "Noticia importante." },
  { id: 28, name: "Caballo de Espadas", suit: "Espadas", number: 11, meaning: "Hombre conflictivo, directo.", love: "Confrontación.", work: "Acción decisiva.", money: "Negociación fuerte." },
  { id: 29, name: "Rey de Espadas", suit: "Espadas", number: 12, meaning: "Hombre inteligente, justo, autoridad.", love: "Hombre intelectual.", work: "Autoridad inteligente.", money: "Éxito estratégico." },
  
  // BASTOS (Energía, Acción, Pasión)
  { id: 30, name: "As de Bastos", suit: "Bastos", number: 1, meaning: "Inspiración, energía, nuevo comienzo.", love: "Pasión despierta.", work: "Proyecto emocionante.", money: "Oportunidad de crecimiento." },
  { id: 31, name: "Dos de Bastos", suit: "Bastos", number: 2, meaning: "Planificación, decisión, poder.", love: "Decisión en relación.", work: "Plan de acción.", money: "Decisión financiera." },
  { id: 32, name: "Tres de Bastos", suit: "Bastos", number: 3, meaning: "Expansión, visión, oportunidad.", love: "Relación que crece.", work: "Expansión laboral.", money: "Oportunidad de crecimiento." },
  { id: 33, name: "Cuatro de Bastos", suit: "Bastos", number: 4, meaning: "Celebración, armonía, comunidad.", love: "Celebración.", work: "Celebración laboral.", money: "Ganancia celebrada." },
  { id: 34, name: "Cinco de Bastos", suit: "Bastos", number: 5, meaning: "Conflicto, competencia, tensión.", love: "Conflicto en pareja.", work: "Competencia laboral.", money: "Lucha financiera." },
  { id: 35, name: "Seis de Bastos", suit: "Bastos", number: 6, meaning: "Reconocimiento, éxito, victoria.", love: "Admiración mutua.", work: "Reconocimiento profesional.", money: "Éxito financiero." },
  { id: 36, name: "Siete de Bastos", suit: "Bastos", number: 7, meaning: "Desafío, defensa, determinación.", love: "Defensa de relación.", work: "Desafío laboral.", money: "Defensa de patrimonio." },
  { id: 37, name: "Sota de Bastos", suit: "Bastos", number: 10, meaning: "Joven entusiasta, mensajero.", love: "Joven apasionado.", work: "Noticia emocionante.", money: "Oportunidad entusiasta." },
  { id: 38, name: "Caballo de Bastos", suit: "Bastos", number: 11, meaning: "Hombre apasionado, aventurero.", love: "Aventura amorosa.", work: "Acción enérgica.", money: "Inversión aventurera." },
  { id: 39, name: "Rey de Bastos", suit: "Bastos", number: 12, meaning: "Hombre apasionado, líder, visionario.", love: "Hombre apasionado.", work: "Liderazgo visionario.", money: "Éxito empresarial." }
];
