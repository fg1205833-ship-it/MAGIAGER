// Base de datos de conocimiento esotérico para el Oráculo V5

// --- TAROT: Significados detallados ---
export const tarotData = [
  { 
    id: 0, 
    name: "El Loco", 
    keywords: ["Inicios", "Espontaneidad", "Fe ciega", "Libertad"],
    meaning: "El Loco representa el comienzo de un viaje, la inocencia y el salto de fe. Te invita a confiar en el universo y lanzarte a lo desconocido sin miedo.",
    love: "En el amor, indica un romance inesperado, divertido y sin ataduras. Atrévete a ser tú mismo.",
    work: "Momento ideal para emprender proyectos arriesgados o creativos. Sigue tu instinto, no la lógica.",
    advice: "No pienses tanto, ¡actúa! La vida es una aventura."
  },
  { 
    id: 1, 
    name: "El Mago", 
    keywords: ["Manifestación", "Poder", "Habilidad", "Acción"],
    meaning: "Tienes todas las herramientas necesarias para triunfar. El Mago es el puente entre el cielo y la tierra; lo que imaginas, puedes crearlo.",
    love: "Tienes el poder de atraer a quien deseas. Sé claro con tus intenciones y toma la iniciativa.",
    work: "Éxito rotundo en nuevos proyectos. Usa tus talentos y habilidades comunicativas para convencer.",
    advice: "Cree en tu propio poder. Eres el arquitecto de tu destino."
  },
  { 
    id: 2, 
    name: "La Sacerdotisa", 
    keywords: ["Intuición", "Misterio", "Subconsciente", "Silencio"],
    meaning: "Es momento de mirar hacia adentro. La Sacerdotisa guarda los secretos del universo y te pide confiar en tu voz interior más que en la razón.",
    love: "Amor platónico o secreto. Conecta emocionalmente antes de actuar. Escucha lo que no se dice.",
    work: "No reveles todos tus planes todavía. Observa, estudia y espera el momento adecuado.",
    advice: "Tu intuición sabe la respuesta. Medita y escucha."
  },
  { 
    id: 3, 
    name: "La Emperatriz", 
    keywords: ["Fertilidad", "Abundancia", "Naturaleza", "Belleza"],
    meaning: "La energía femenina creadora en su máxima expresión. Indica crecimiento, prosperidad y el disfrute de los placeres de la vida.",
    love: "Relación sensual, fértil y llena de cariño. Posible embarazo o nacimiento de proyectos conjuntos.",
    work: "Tus ideas están floreciendo. Es un periodo de cosecha y abundancia material.",
    advice: "Conecta con la naturaleza y nutre tus creaciones con amor."
  },
  { 
    id: 4, 
    name: "El Emperador", 
    keywords: ["Autoridad", "Estructura", "Control", "Paternidad"],
    meaning: "Representa el orden, la disciplina y el poder terrenal. Es momento de poner reglas claras y construir bases sólidas.",
    love: "Relación estable y comprometida, aunque quizás un poco rígida. Busca seguridad y protección.",
    work: "Liderazgo y organización. Es hora de tomar el mando y estructurar tus objetivos.",
    advice: "Sé firme en tus decisiones y establece límites claros."
  },
  { 
    id: 5, 
    name: "El Sumo Sacerdote", 
    keywords: ["Tradición", "Enseñanza", "Creencias", "Guía"],
    meaning: "Busca la sabiduría en la tradición o en un mentor. Representa las instituciones, la moral y el aprendizaje espiritual.",
    love: "Compromiso serio, matrimonio o relación basada en valores compartidos.",
    work: "Sigue las reglas establecidas. Buen momento para formarte o enseñar a otros.",
    advice: "Busca el consejo de alguien sabio o apégate a tus valores fundamentales."
  },
  { 
    id: 6, 
    name: "Los Enamorados", 
    keywords: ["Amor", "Elección", "Armonía", "Valores"],
    meaning: "Más allá del romance, esta carta habla de decisiones importantes alineadas con tus valores. La unión de dualidades.",
    love: "Conexión profunda de almas gemelas. Una decisión crucial en la relación.",
    work: "Asociaciones beneficiosas. Debes elegir el camino que resuene con tu corazón, no solo con tu bolsillo.",
    advice: "Elige desde el amor, no desde el miedo."
  },
  { 
    id: 7, 
    name: "El Carro", 
    keywords: ["Victoria", "Voluntad", "Determinación", "Viaje"],
    meaning: "Avance rápido y triunfo mediante el control de fuerzas opuestas. El éxito está asegurado si mantienes la disciplina.",
    love: "Conquista amorosa. Superación de obstáculos en la pareja mediante el esfuerzo conjunto.",
    work: "Logro de metas ambiciosas. No te detengas ante nada, tienes la fuerza para ganar.",
    advice: "Toma las riendas de tu vida y avanza con confianza."
  },
  { 
    id: 8, 
    name: "La Fuerza", 
    keywords: ["Coraje", "Compasión", "Paciencia", "Control suave"],
    meaning: "La verdadera fuerza no es bruta, es espiritual. Domina tus instintos con amor y paciencia. Resiliencia ante la adversidad.",
    love: "Relación apasionada pero que requiere paciencia y comprensión mutua.",
    work: "Persistencia. Resuelve conflictos con diplomacia y seguridad en ti mismo.",
    advice: "Sé valiente y gentil al mismo tiempo. Tienes una fuerza interior inagotable."
  },
  { 
    id: 9, 
    name: "El Ermitaño", 
    keywords: ["Introspección", "Soledad", "Guía interior", "Búsqueda"],
    meaning: "Aléjate del ruido del mundo para encontrar tu propia luz. Es un tiempo de reflexión profunda y maduración.",
    love: "Necesidad de espacio personal o soltería voluntaria para sanar y conocerse mejor.",
    work: "Investigación profunda. Trabaja solo y concéntrate en los detalles.",
    advice: "La respuesta que buscas está dentro de ti, no fuera."
  },
  { 
    id: 10, 
    name: "Rueda de la Fortuna", 
    keywords: ["Cambio", "Destino", "Ciclos", "Suerte"],
    meaning: "El universo está girando. Lo que estaba abajo sube y viceversa. Acepta los cambios inevitables del destino.",
    love: "Encuentros kármicos. Cambios repentinos en la dinámica de la relación.",
    work: "Golpe de suerte o cambio inesperado de circunstancias. Adáptate rápido.",
    advice: "Fluye con los cambios, no te resistas. Todo es temporal."
  },
  { 
    id: 11, 
    name: "La Justicia", 
    keywords: ["Verdad", "Equilibrio", "Ley", "Causa y efecto"],
    meaning: "Recibirás lo que mereces. La Justicia trae claridad y verdad. Todas las acciones tienen consecuencias.",
    love: "Trato justo en la pareja. Si has dado amor, recibirás amor. Posibles formalizaciones legales.",
    work: "Contratos, negociaciones y evaluaciones objetivas. Sé honesto e íntegro.",
    advice: "Busca el equilibrio y actúa con integridad absoluta."
  },
  { 
    id: 12, 
    name: "El Colgado", 
    keywords: ["Pausa", "Sacrificio", "Nueva perspectiva", "Espera"],
    meaning: "Detente. No es momento de actuar, sino de ver las cosas desde otro ángulo. A veces hay que sacrificar algo para ganar sabiduría.",
    love: "Estancamiento temporal. Necesitas soltar el control para que la relación evolucione.",
    work: "Proyectos en pausa. No fuerces las cosas, aprovecha para replantear la estrategia.",
    advice: "Cambia tu perspectiva y encontrarás la solución."
  },
  { 
    id: 13, 
    name: "La Muerte", 
    keywords: ["Transformación", "Finales", "Renacimiento", "Cambio profundo"],
    meaning: "No temas, no es muerte física. Es el fin necesario de una etapa para que nazca algo nuevo y mejor. Deja ir lo viejo.",
    love: "Fin de una relación o de una dinámica tóxica. Transformación radical de la pareja.",
    work: "Cierre de un ciclo laboral o cambio total de carrera. Reinventarse es necesario.",
    advice: "Suelta lo que ya no tiene vida para dejar espacio a lo nuevo."
  },
  { 
    id: 14, 
    name: "La Templanza", 
    keywords: ["Equilibrio", "Moderación", "Paciencia", "Sanación"],
    meaning: "Mezcla los opuestos para encontrar la armonía. La paciencia y la moderación son tus mejores aliadas ahora.",
    love: "Relación tranquila, sanadora y equilibrada. La comunicación fluye suavemente.",
    work: "Colaboración armoniosa. Evita los extremos y busca el punto medio.",
    advice: "Ten paciencia. Las cosas se están gestando en el tiempo divino."
  },
  { 
    id: 15, 
    name: "El Diablo", 
    keywords: ["Apegos", "Materialismo", "Sombra", "Tentación"],
    meaning: "Estás atado a algo que no te hace bien (miedos, vicios, personas). Reconoce tus cadenas para poder liberarte.",
    love: "Pasión obsesiva, celos o relación tóxica basada en la dependencia.",
    work: "Ambición desmedida o sentirse atrapado en un trabajo que odias por dinero.",
    advice: "Rompe las cadenas autoimpuestas. Eres libre si decides serlo."
  },
  { 
    id: 16, 
    name: "La Torre", 
    keywords: ["Caos", "Revelación", "Ruptura", "Despertar"],
    meaning: "Una estructura falsa se derrumba repentinamente. Aunque doloroso, es necesario para construir sobre verdad. Iluminación súbita.",
    love: "Ruptura inesperada o revelación de una verdad oculta que cambia todo.",
    work: "Pérdida de empleo o colapso de un proyecto mal cimentado. Oportunidad de empezar de cero.",
    advice: "Deja que caiga lo que tenga que caer. Lo que es real permanecerá."
  },
  { 
    id: 17, 
    name: "La Estrella", 
    keywords: ["Esperanza", "Inspiración", "Sanación", "Fe"],
    meaning: "Después de la tormenta (La Torre), llega la calma. Renovación espiritual, optimismo y conexión con el universo.",
    love: "Amor puro, sanación de heridas pasadas. Futuro prometedor en la relación.",
    work: "Inspiración creativa. Estás en el camino correcto hacia tus sueños.",
    advice: "Mantén la fe y sigue tu estrella guía. El universo te bendice."
  },
  { 
    id: 18, 
    name: "La Luna", 
    keywords: ["Ilusión", "Miedo", "Intuición", "Subconsciente"],
    meaning: "No todo es lo que parece. Hay sombras y confusiones. Confía en tu instinto para navegar la oscuridad y enfrentar tus miedos.",
    love: "Secretos, confusiones o idealización excesiva. Cuidado con los engaños.",
    work: "Ambiente laboral confuso o falta de información clara. No tomes decisiones precipitadas.",
    advice: "Enfrenta tus sombras y presta atención a tus sueños."
  },
  { 
    id: 19, 
    name: "El Sol", 
    keywords: ["Alegría", "Éxito", "Vitalidad", "Claridad"],
    meaning: "La mejor carta del tarot. Felicidad absoluta, éxito, calor y luz. Todo sale bien y la verdad brilla.",
    love: "Amor pleno, matrimonio feliz, familia. Relación cálida y transparente.",
    work: "Reconocimiento público, éxito rotundo y realización personal.",
    advice: "Disfruta el momento y comparte tu luz con el mundo."
  },
  { 
    id: 20, 
    name: "El Juicio", 
    keywords: ["Renacimiento", "Llamado", "Perdón", "Evaluación"],
    meaning: "Un despertar espiritual. Es hora de evaluar el pasado, perdonar y renacer a una nueva versión de ti mismo.",
    love: "Reconciliación o decisión de elevar la relación a un nivel superior.",
    work: "Descubrimiento de tu verdadera vocación. Un llamado a hacer algo significativo.",
    advice: "Escucha la llamada de tu alma y libérate del pasado."
  },
  { 
    id: 21, 
    name: "El Mundo", 
    keywords: ["Completitud", "Logro", "Viajes", "Ciclo cumplido"],
    meaning: "Has llegado a la meta. Integración total, éxito y celebración. El mundo está a tus pies.",
    love: "Relación perfecta, unión cósmica. Boda o viaje en pareja.",
    work: "Meta alcanzada, éxito internacional o culminación de un gran proyecto.",
    advice: "Celebra tus logros. Un ciclo termina y otro comienza en un nivel superior."
  }
];

// --- ASTROLOGÍA: Compatibilidad y Signos ---
export const zodiacSigns = [
  { name: "Aries", dates: "21 Mar - 19 Abr", element: "Fuego", planet: "Marte", traits: "Valiente, impulsivo, líder." },
  { name: "Tauro", dates: "20 Abr - 20 May", element: "Tierra", planet: "Venus", traits: "Paciente, confiable, sensual." },
  { name: "Géminis", dates: "21 May - 20 Jun", element: "Aire", planet: "Mercurio", traits: "Curioso, adaptable, comunicativo." },
  { name: "Cáncer", dates: "21 Jun - 22 Jul", element: "Agua", planet: "Luna", traits: "Emocional, protector, intuitivo." },
  { name: "Leo", dates: "23 Jul - 22 Ago", element: "Fuego", planet: "Sol", traits: "Creativo, apasionado, generoso." },
  { name: "Virgo", dates: "23 Ago - 22 Sep", element: "Tierra", planet: "Mercurio", traits: "Analítico, práctico, perfeccionista." },
  { name: "Libra", dates: "23 Sep - 22 Oct", element: "Aire", planet: "Venus", traits: "Diplomático, idealista, social." },
  { name: "Escorpio", dates: "23 Oct - 21 Nov", element: "Agua", planet: "Plutón", traits: "Intenso, misterioso, determinado." },
  { name: "Sagitario", dates: "22 Nov - 21 Dic", element: "Fuego", planet: "Júpiter", traits: "Optimista, aventurero, honesto." },
  { name: "Capricornio", dates: "22 Dic - 19 Ene", element: "Tierra", planet: "Saturno", traits: "Ambicioso, disciplinado, prudente." },
  { name: "Acuario", dates: "20 Ene - 18 Feb", element: "Aire", planet: "Urano", traits: "Original, humanitario, independiente." },
  { name: "Piscis", dates: "19 Feb - 20 Mar", element: "Agua", planet: "Neptuno", traits: "Soñador, empático, artístico." }
];

export const compatibilityData: Record<string, Record<string, { score: number, text: string }>> = {
  "Fuego": {
    "Fuego": { score: 90, text: "¡Explosión de pasión! Mucha energía y aventura, pero cuidado con los choques de ego." },
    "Tierra": { score: 50, text: "Relación difícil. La Tierra apaga el Fuego, pero el Fuego puede quemar la Tierra. Requiere paciencia." },
    "Aire": { score: 95, text: "El Aire aviva el Fuego. Una de las mejores combinaciones, llena de estímulo mental y acción." },
    "Agua": { score: 40, text: "Vapor y confusión. El Agua apaga el Fuego. Emociones vs Acción. Reto kármico." }
  },
  "Tierra": {
    "Fuego": { score: 50, text: "Ritmos diferentes. El Fuego quiere correr, la Tierra quiere construir. Pueden aprender mucho si toleran." },
    "Tierra": { score: 95, text: "Estabilidad total. Construyen imperios juntos. Puede faltar chispa, pero sobra lealtad." },
    "Aire": { score: 60, text: "Poco en común. La Tierra es práctica, el Aire es teórico. Pueden desconectarse fácilmente." },
    "Agua": { score: 100, text: "Fertilidad pura. El Agua nutre la Tierra. Relación profunda, productiva y amorosa." }
  },
  "Aire": {
    "Fuego": { score: 95, text: "Dinámicos e imparables. Se inspiran mutuamente. Nunca se aburrirán." },
    "Tierra": { score: 60, text: "El Aire se siente atrapado, la Tierra se siente insegura. Necesitan mucha comunicación." },
    "Aire": { score: 90, text: "Conexión mental instantánea. Grandes conversaciones, pero pueden faltar emociones profundas." },
    "Agua": { score: 50, text: "Difícil. El Aire analiza, el Agua siente. Pueden no entenderse el idioma emocional." }
  },
  "Agua": {
    "Fuego": { score: 40, text: "Intenso pero peligroso. El Agua hierve o apaga el Fuego. Dramas pasionales asegurados." },
    "Tierra": { score: 100, text: "Unión perfecta. Se complementan y se cuidan. Hogar, seguridad y amor profundo." },
    "Aire": { score: 50, text: "El Agua necesita contención, el Aire libertad. Pueden sentirse incomprendidos." },
    "Agua": { score: 95, text: "Telepatía emocional. Se entienden sin hablar, pero cuidado con ahogarse en el drama mutuo." }
  }
};

// --- SUEÑOS: Diccionario básico ---
export const dreamDictionary = [
  { keyword: "Volar", meaning: "Deseo de libertad, superación de obstáculos, perspectiva superior." },
  { keyword: "Caer", meaning: "Inseguridad, pérdida de control, miedo al fracaso." },
  { keyword: "Dientes", meaning: "Miedo a envejecer, pérdida de poder personal, ansiedad por la apariencia o comunicación." },
  { keyword: "Agua", meaning: "Estado emocional. Agua clara = paz; Agua turbia = confusión emocional." },
  { keyword: "Persecución", meaning: "Estás evitando algo en tu vida vigilia. Un problema que no quieres enfrentar." },
  { keyword: "Muerte", meaning: "Transformación, fin de una etapa, cambio radical (rara vez es literal)." },
  { keyword: "Desnudez", meaning: "Vulnerabilidad, miedo a ser expuesto, o deseo de honestidad total." },
  { keyword: "Examen", meaning: "Miedo a ser juzgado, falta de preparación, autocrítica excesiva." },
  { keyword: "Serpiente", meaning: "Traición, sanación, energía sexual, transformación (kundalini)." },
  { keyword: "Fuego", meaning: "Pasión, ira, purificación, destrucción para crear algo nuevo." }
];

// --- CHAKRAS: Test y Guía ---
export const chakrasData = [
  { id: 1, name: "Raíz (Muladhara)", color: "Rojo", location: "Base columna", issue: "Miedo, inseguridad, problemas financieros.", heal: "Camina descalzo, usa rojo, come proteínas." },
  { id: 2, name: "Sacro (Svadhisthana)", color: "Naranja", location: "Bajo vientre", issue: "Culpa, bloqueo creativo, problemas sexuales.", heal: "Baila, bebe agua, usa naranja, crea arte." },
  { id: 3, name: "Plexo Solar (Manipura)", color: "Amarillo", location: "Estómago", issue: "Vergüenza, baja autoestima, falta de control.", heal: "Toma sol, haz abdominales, usa amarillo." },
  { id: 4, name: "Corazón (Anahata)", color: "Verde", location: "Pecho", issue: "Dolor, soledad, rencor, falta de empatía.", heal: "Abraza, perdona, usa verde o rosa, pasa tiempo en la naturaleza." },
  { id: 5, name: "Garganta (Vishuddha)", color: "Azul", location: "Garganta", issue: "Mentiras, timidez, no poder decir 'no'.", heal: "Canta, grita, escribe, usa azul turquesa." },
  { id: 6, name: "Tercer Ojo (Ajna)", color: "Índigo", location: "Entrecejo", issue: "Ilusión, falta de intuición, pesadillas.", heal: "Medita, visualiza, usa índigo o amatista." },
  { id: 7, name: "Corona (Sahasrara)", color: "Violeta/Blanco", location: "Tope cabeza", issue: "Apego material, desconexión espiritual.", heal: "Oración, silencio, ayuno, usa violeta o blanco." }
];
