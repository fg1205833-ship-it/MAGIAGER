/**
 * Generador Dinámico de Interpretaciones de Tarot
 * 
 * Genera interpretaciones únicas y auténticas combinando:
 * - Núcleo simbólico de la carta
 * - Sección (mesa, amor, dinero, etc.)
 * - Elemento zodiacal (fuego, tierra, aire, agua)
 * - Variante (luz, sombra, equilibrio)
 * - Tipo de tarot (RWS, Marsella, Ángeles, Español)
 * 
 * TODO es generado dinámicamente. No hay archivos estáticos explosivos.
 */

import {
  CardInterpretation,
  Element,
  Variant,
  Section,
  TarotType,
  ELEMENT_CHARACTERISTICS,
  ZODIAC_CHARACTERISTICS,
  ZODIAC_TO_ELEMENT,
} from './tarotDatabase';
import { SymbolicCore, getSymbolicCore } from './tarotSymbolicCores';
import {
  ELEMENT_SYMBOLIC_RULES,
  PERSONALIZATION_TEMPLATES,
} from './zodiacPersonalization';
import {
  TAROT_INTERPRETATION_ADAPTATIONS,
} from './tarotMultiDeckAdapter';

/**
 * Generador de interpretaciones
 */
export class InterpretationGenerator {
  /**
   * Generar interpretación completa para una carta
   */
  static generateInterpretation(
    cardId: string,
    section: Section,
    element: Element,
    variant: Variant,
    tarotType: TarotType
  ): CardInterpretation | null {
    const core = getSymbolicCore(cardId);
    if (!core) return null;

    // Paso 1: Obtener el enfoque de la sección
    const sectionFocus = core.sectionFocus[section];
    if (!sectionFocus) return null;

    // Paso 2: Generar la interpretación base
    const baseInterpretation = this.generateBaseInterpretation(
      core,
      section,
      sectionFocus,
      element,
      variant
    );

    // Paso 3: Personalizar por elemento
    const personalizedInterpretation = this.personalizeByElement(
      baseInterpretation,
      core,
      element,
      variant,
      section
    );

    // Paso 4: Adaptar al tarot específico
    const adaptedInterpretation = this.adaptToTarot(
      personalizedInterpretation,
      core,
      tarotType,
      variant
    );

    return adaptedInterpretation;
  }

  /**
   * Generar interpretación base a partir del núcleo simbólico
   */
  private static generateBaseInterpretation(
    core: SymbolicCore,
    section: Section,
    sectionFocus: { focus: string; challenge: string; opportunity: string },
    element: Element,
    variant: Variant
  ): CardInterpretation {
    // Seleccionar la expresión correcta según la variante
    const expression =
      variant === 'luz'
        ? core.lightExpression
        : variant === 'sombra'
          ? core.shadowExpression
          : core.balanceExpression;

    // Construir el mensaje general
    const general = `${core.name}: ${sectionFocus.focus}. ${expression}`;

    // Construir el consejo
    const advice = this.generateAdvice(core, section, sectionFocus, variant);

    // Generar palabras clave
    const keywords = this.generateKeywords(core, section, element, variant);

    return {
      general,
      advice,
      keywords,
    };
  }

  /**
   * Generar consejo contextualizado
   */
  private static generateAdvice(
    core: SymbolicCore,
    section: Section,
    sectionFocus: { focus: string; challenge: string; opportunity: string },
    variant: Variant
  ): string {
    const adviceTemplates: Record<Variant, string[]> = {
      luz: [
        `Aprovecha esta oportunidad: ${sectionFocus.opportunity}`,
        `Confía en esta manifestación: ${sectionFocus.focus}`,
        `Actúa desde tu poder: ${sectionFocus.opportunity}`,
      ],
      sombra: [
        `Cuidado con: ${sectionFocus.challenge}`,
        `Observa: ${sectionFocus.challenge}`,
        `Reflexiona sobre: ${sectionFocus.challenge}`,
      ],
      equilibrio: [
        `Equilibra: ${sectionFocus.challenge} con ${sectionFocus.opportunity}`,
        `Integra: ${sectionFocus.focus} manteniendo ${sectionFocus.opportunity}`,
        `Busca el balance entre el desafío y la oportunidad`,
      ],
    };

    const templates = adviceTemplates[variant];
    return templates[Math.floor(Math.random() * templates.length)];
  }

  /**
   * Generar palabras clave contextualizadas
   */
  private static generateKeywords(
    core: SymbolicCore,
    section: Section,
    element: Element,
    variant: Variant
  ): string[] {
    const keywords = [...core.coreSymbols];

    // Añadir palabras clave del elemento
    const elementRules = ELEMENT_SYMBOLIC_RULES[element];
    keywords.push(...elementRules.focusAreas.slice(0, 2));

    // Añadir palabras clave de la variante
    const variantKeywords: Record<Variant, string[]> = {
      luz: ['oportunidad', 'crecimiento', 'manifestación'],
      sombra: ['desafío', 'lección', 'transformación'],
      equilibrio: ['balance', 'integración', 'armonía'],
    };
    keywords.push(...variantKeywords[variant].slice(0, 1));

    // Remover duplicados
    return [...new Set(keywords)].slice(0, 8);
  }

  /**
   * Personalizar por elemento zodiacal
   */
  private static personalizeByElement(
    baseInterpretation: CardInterpretation,
    core: SymbolicCore,
    element: Element,
    variant: Variant,
    section: Section
  ): CardInterpretation {
    const template = PERSONALIZATION_TEMPLATES[element][variant];
    const rules = ELEMENT_SYMBOLIC_RULES[element];

    // Obtener la influencia del elemento en la carta
    const elementInfluence =
      element === 'fuego'
        ? core.fireInfluence
        : element === 'tierra'
          ? core.earthInfluence
          : element === 'aire'
            ? core.airInfluence
            : core.waterInfluence;

    // Construir el mensaje personalizado
    const personalizedGeneral = `${template.intro} ${core.name}: ${baseInterpretation.general} ${elementInfluence}`;

    // Personalizar el consejo
    const personalizedAdvice = `${template.actionGuidance} ${baseInterpretation.advice}`;

    return {
      ...baseInterpretation,
      general: personalizedGeneral,
      advice: personalizedAdvice,
    };
  }

  /**
   * Adaptar al tarot específico
   */
  private static adaptToTarot(
    interpretation: CardInterpretation,
    core: SymbolicCore,
    tarotType: TarotType,
    variant: Variant
  ): CardInterpretation {
    const adaptation = TAROT_INTERPRETATION_ADAPTATIONS[tarotType];

    // Añadir matiz del tarot
    const tarotMatiz = this.getTarotMatiz(tarotType, core, variant);

    const adaptedGeneral = `${interpretation.general} ${tarotMatiz}`;

    return {
      ...interpretation,
      general: adaptedGeneral,
    };
  }

  /**
   * Obtener matiz específico del tarot
   */
  private static getTarotMatiz(
    tarotType: TarotType,
    core: SymbolicCore,
    variant: Variant
  ): string {
    const matices: Record<TarotType, Record<Variant, string>> = {
      rws: {
        luz: `En el Rider-Waite-Smith, esta carta te muestra visualmente la narrativa clara de tu situación.`,
        sombra: `El Rider-Waite-Smith revela los detalles visuales de lo que está oculto.`,
        equilibrio: `El Rider-Waite-Smith integra los elementos visuales en una narrativa coherente.`,
      },
      marseille: {
        luz: `La tradición de Marsella revela el símbolo profundo en su minimalismo.`,
        sombra: `Marsella te muestra lo que está oculto en el espacio vacío.`,
        equilibrio: `Marsella integra lo visible y lo invisible en equilibrio.`,
      },
      angels: {
        luz: `Los ángeles te comunican un mensaje de amor y sanación.`,
        sombra: `Los ángeles te advierten con compasión sobre lo que necesitas sanar.`,
        equilibrio: `Los ángeles te guían hacia el balance y la paz interior.`,
      },
      spanish: {
        luz: `La tradición española conecta este arquetipo con sabiduría ancestral.`,
        sombra: `La baraja española revela lecciones de la tradición.`,
        equilibrio: `La tradición española integra el pasado y el presente.`,
      },
    };

    return matices[tarotType][variant];
  }

  /**
   * Generar interpretación completa para múltiples contextos
   */
  static generateCompleteReading(
    cardId: string,
    sections: Section[],
    elements: Element[],
    variants: Variant[],
    tarotTypes: TarotType[]
  ): Record<string, Record<string, Record<string, Record<string, CardInterpretation>>>> {
    const reading: any = {};

    for (const section of sections) {
      reading[section] = {};
      for (const element of elements) {
        reading[section][element] = {};
        for (const variant of variants) {
          reading[section][element][variant] = {};
          for (const tarotType of tarotTypes) {
            reading[section][element][variant][tarotType] =
              this.generateInterpretation(cardId, section, element, variant, tarotType) ||
              { general: 'No disponible', advice: 'No disponible', keywords: [] };
          }
        }
      }
    }

    return reading;
  }

  /**
   * Validar que la interpretación no es genérica
   */
  static validateUniqueness(
    interpretation: CardInterpretation,
    previousInterpretations: CardInterpretation[] = []
  ): {
    isUnique: boolean;
    score: number;
    issues: string[];
  } {
    const issues: string[] = [];
    let score = 1.0;

    // Verificar longitud
    if (interpretation.general.length < 80) {
      issues.push('Interpretación demasiado corta');
      score -= 0.2;
    }

    // Verificar palabras genéricas
    const genericWords = ['bueno', 'malo', 'bien', 'mal', 'importante', 'especial'];
    const genericCount = genericWords.filter(word =>
      interpretation.general.toLowerCase().includes(word)
    ).length;

    if (genericCount > 2) {
      issues.push('Demasiadas palabras genéricas');
      score -= 0.15;
    }

    // Verificar repetición
    for (const prev of previousInterpretations) {
      const similarity = this.calculateSimilarity(
        interpretation.general,
        prev.general
      );
      if (similarity > 0.7) {
        issues.push('Posible repetición con interpretación anterior');
        score -= 0.2;
        break;
      }
    }

    // Verificar palabras clave
    if (interpretation.keywords.length < 3) {
      issues.push('Faltan palabras clave');
      score -= 0.1;
    }

    return {
      isUnique: score > 0.6,
      score: Math.max(0, score),
      issues,
    };
  }

  /**
   * Calcular similitud entre dos textos
   */
  private static calculateSimilarity(text1: string, text2: string): number {
    const words1 = new Set(text1.toLowerCase().split(/\s+/));
    const words2 = new Set(text2.toLowerCase().split(/\s+/));

    const intersection = new Set([...words1].filter(x => words2.has(x)));
    const union = new Set([...words1, ...words2]);

    return intersection.size / union.size;
  }
}

/**
 * Función helper para generar interpretación simple
 */
export function generateTarotInterpretation(
  cardId: string,
  section: Section,
  element: Element,
  variant: Variant,
  tarotType: TarotType
): CardInterpretation | null {
  return InterpretationGenerator.generateInterpretation(
    cardId,
    section,
    element,
    variant,
    tarotType
  );
}

/**
 * Función helper para generar lectura completa
 */
export function generateCompleteReading(
  cardId: string,
  sections?: Section[],
  elements?: Element[],
  variants?: Variant[],
  tarotTypes?: TarotType[]
): Record<string, Record<string, Record<string, Record<string, CardInterpretation>>>> {
  return InterpretationGenerator.generateCompleteReading(
    cardId,
    sections || ['mesa', 'amor', 'dinero'],
    elements || ['fuego', 'tierra'],
    variants || ['luz', 'sombra'],
    tarotTypes || ['rws', 'marseille']
  );
}
