export interface TarotMeaning {
  general: string;
  love: string;
  money: string;
  work: string;
  advice: string;
}

export const tarotMeaningsDB: Record<string, TarotMeaning> = {
  "maj_0": {
    "general": "El Loco representa nuevos comienzos, espontaneidad y fe en el universo. Es el salto al vacío necesario para evolucionar.",
    "love": "Un nuevo amor inesperado, relaciones sin ataduras o un soplo de aire fresco en la pareja.",
    "money": "Riesgos financieros que pueden salir bien si se tiene fe, pero cuidado con la imprudencia.",
    "work": "Cambio de carrera, proyectos creativos o una nueva forma de ver tu profesión.",
    "advice": "Atrévete a ser diferente y confía en tu instinto. Es momento de saltar."
  },
  "maj_1": {
    "general": "El Mago simboliza el poder de manifestación y la habilidad para usar los recursos disponibles. Tienes el control.",
    "love": "Magnetismo personal, capacidad para conquistar y comunicación clara en la relación.",
    "money": "Habilidad para generar ingresos a través de talentos propios. Momento de acción comercial.",
    "work": "Éxito en negociaciones, liderazgo y capacidad para resolver cualquier problema técnico.",
    "advice": "Utiliza todas tus herramientas. Tienes el poder de crear tu propia realidad."
  },
  "maj_2": {
    "general": "La Sacerdotisa representa la intuición profunda, el misterio y el conocimiento oculto. Escucha el silencio.",
    "love": "Conexión espiritual, sentimientos que se guardan en secreto o necesidad de paciencia en el amor.",
    "money": "Maneja tus finanzas con discreción. No es momento de grandes gastos, sino de observación.",
    "work": "Sabiduría aplicada, investigación y necesidad de mantener la calma ante el caos laboral.",
    "advice": "Mira hacia adentro. La respuesta no está en el mundo exterior, sino en tu intuición."
  },
  "maj_3": {
    "general": "La Emperatriz es la abundancia, la fertilidad y la creatividad en su máxima expresión. La madre nutricia.",
    "love": "Amor pleno, posible embarazo, sensualidad y cuidado mutuo en la relación.",
    "money": "Prosperidad material, crecimiento de inversiones y comodidad financiera.",
    "work": "Proyectos que florecen, creatividad productiva y un ambiente laboral armonioso.",
    "advice": "Nutre tus ideas con amor. Permite que la belleza y la abundancia entren en tu vida."
  },
  "maj_4": {
    "general": "El Emperador simboliza la estructura, el orden, la autoridad y la estabilidad. El poder de la voluntad.",
    "love": "Relación sólida y estable, protección y compromiso serio. Estructura familiar fuerte.",
    "money": "Control estricto de las finanzas, ahorro disciplinado y estabilidad económica a largo plazo.",
    "work": "Liderazgo firme, organización y éxito a través de la disciplina y el respeto a las jerarquías.",
    "advice": "Pon orden en tus asuntos. La disciplina es el camino hacia el éxito duradero."
  },
  "maj_5": {
    "general": "El Hierofante representa la tradición, las instituciones, la guía espiritual y el aprendizaje formal.",
    "love": "Valores compartidos, compromiso tradicional o búsqueda de consejo en la pareja.",
    "money": "Finanzas conservadoras. Sigue los métodos probados y busca asesoría profesional.",
    "work": "Trabajo en organizaciones grandes, mentoría o necesidad de seguir las reglas establecidas.",
    "advice": "Busca el consejo de alguien con experiencia. Respeta las tradiciones que funcionan."
  },
  "maj_6": {
    "general": "Los Enamorados simbolizan la elección del corazón, la armonía y las relaciones significativas.",
    "love": "Pasión, unión profunda y la necesidad de tomar una decisión importante sobre el futuro amoroso.",
    "money": "Decisiones financieras que requieren equilibrio entre la lógica y lo que realmente deseas.",
    "work": "Sociedades exitosas basadas en la confianza mutua. Elecciones profesionales éticas.",
    "advice": "Sigue a tu corazón, pero asegúrate de que tus valores estén alineados con tu elección."
  },
  "maj_7": {
    "general": "El Carro representa la victoria, la determinación y el control sobre fuerzas opuestas. Avance rápido.",
    "love": "Conquista amorosa, superación de obstáculos en la pareja y avance decidido hacia una meta común.",
    "money": "Éxito financiero logrado con esfuerzo y dirección clara. Control sobre los gastos.",
    "work": "Ambición recompensada, viajes de negocios y triunfo sobre la competencia.",
    "advice": "Mantén las riendas firmes. Con determinación y enfoque, alcanzarás tu destino."
  },
  "maj_8": {
    "general": "La Fuerza simboliza el coraje interno, la paciencia y el dominio de los instintos mediante la compasión.",
    "love": "Pasión equilibrada con ternura. Capacidad para resolver conflictos con amor y suavidad.",
    "money": "Resiliencia económica. Capacidad para manejar situaciones difíciles con calma y control.",
    "work": "Liderazgo persuasivo, no impositivo. Fuerza moral para enfrentar retos laborales.",
    "advice": "No uses la fuerza bruta. La suavidad y la persistencia vencerán cualquier obstáculo."
  },
  "maj_9": {
    "general": "El Ermitaño representa la introspección, la búsqueda de la verdad y la soledad necesaria para sanar.",
    "love": "Necesidad de espacio personal, reflexión sobre lo que se busca en una pareja o soltería consciente.",
    "money": "Prudencia extrema. Momento de analizar gastos y no dejarse llevar por el materialismo.",
    "work": "Trabajo independiente, investigación profunda y necesidad de alejarse del ruido para concentrarse.",
    "advice": "Retírate un momento del mundo. La luz que buscas está dentro de ti."
  },
  "maj_10": {
    "general": "La Rueda de la Fortuna simboliza el cambio constante, los ciclos del destino y las nuevas oportunidades.",
    "love": "Giros inesperados en la vida amorosa, encuentros fortuitos o cambios de ciclo en la pareja.",
    "money": "Fluctuaciones económicas. Suerte repentina o cambios en la situación financiera que requieren adaptación.",
    "work": "Nuevas oportunidades que llegan por destino. Adaptabilidad ante los cambios de la empresa.",
    "advice": "Acepta que la vida es cambio. Fluye con el movimiento y aprovecha la oportunidad cuando subas."
  },
  "maj_11": {
    "general": "La Justicia representa el equilibrio, la verdad, la ley del karma y la honestidad radical.",
    "love": "Trato justo, honestidad en la comunicación y necesidad de equilibrio emocional en la relación.",
    "money": "Asuntos legales, contratos y equilibrio entre ingresos y egresos. Justicia financiera.",
    "work": "Integridad profesional, evaluaciones justas y resolución de conflictos mediante la lógica.",
    "advice": "Sé honesto contigo mismo y con los demás. Cosecharás exactamente lo que has sembrado."
  },
  "maj_12": {
    "general": "El Colgado simboliza el sacrificio voluntario, la pausa necesaria y el cambio de perspectiva.",
    "love": "Ver la relación desde otro ángulo, sacrificio por el ser amado o un periodo de espera necesaria.",
    "money": "Estancamiento temporal. No fuerces las inversiones; espera a tener una visión más clara.",
    "work": "Sentirse atrapado en el trabajo. Es momento de observar y no actuar impulsivamente.",
    "advice": "Suelta el control. A veces, al rendirnos y cambiar nuestra visión, encontramos la solución."
  },
  "maj_13": {
    "general": "La Muerte representa la transformación profunda, el final de un ciclo y el renacimiento necesario.",
    "love": "Fin de una etapa o relación que ya no sirve para que algo nuevo y mejor pueda nacer.",
    "money": "Cambio drástico en las finanzas. Elimina gastos innecesarios y prepárate para una nueva etapa.",
    "work": "Cierre de proyectos o empleos. Transformación profesional radical hacia algo más auténtico.",
    "advice": "No temas al final. Para que el fénix renazca, las cenizas deben quedar atrás."
  },
  "maj_14": {
    "general": "La Templanza simboliza la moderación, el equilibrio, la paciencia y la transmutación de energías.",
    "love": "Armonía, paz y comunicación fluida. Capacidad de combinar diferencias para crear algo hermoso.",
    "money": "Gestión equilibrada de los recursos. Evita los extremos y busca la estabilidad a largo plazo.",
    "work": "Cooperación, diplomacia y éxito a través de la mezcla de diferentes talentos y paciencia.",
    "advice": "Busca el equilibrio en todo lo que hagas. La paciencia es tu mejor aliada ahora."
  },
  "maj_15": {
    "general": "El Diablo representa las ataduras materiales, las sombras, la tentación y el poder del subconsciente.",
    "love": "Pasión intensa pero posiblemente tóxica, celos, obsesión o dependencia emocional.",
    "money": "Obsesión por el dinero, deudas por impulsividad o estar atrapado en un sistema materialista.",
    "work": "Ambiente laboral tóxico, ambición desmedida o sentirse esclavo de un empleo por dinero.",
    "advice": "Identifica tus cadenas. El primer paso para liberarte es reconocer qué te tiene atrapado."
  },
  "maj_16": {
    "general": "La Torre simboliza la ruptura repentina de estructuras falsas, la revelación y el cambio inevitable.",
    "love": "Crisis necesaria que rompe ilusiones, rupturas inesperadas o una verdad impactante que lo cambia todo.",
    "money": "Colapso financiero repentino o gastos imprevistos que obligan a reconstruir desde cero.",
    "work": "Despidos, cierres de empresas o fracasos de proyectos que no tenían cimientos sólidos.",
    "advice": "Deja que caiga lo que no es real. Sobre las ruinas de lo falso, construirás la verdad."
  },
  "maj_17": {
    "general": "La Estrella representa la esperanza, la inspiración, la sanación y la conexión con lo divino.",
    "love": "Sanación de heridas pasadas, esperanza en el amor y una relación llena de luz y transparencia.",
    "money": "Recuperación económica, optimismo justificado y flujo de abundancia natural.",
    "work": "Inspiración creativa, reconocimiento y un futuro brillante en tu carrera profesional.",
    "advice": "Confía en el universo. Estás en el camino correcto y la luz te guía."
  },
  "maj_18": {
    "general": "La Luna simboliza el mundo de los sueños, la confusión, los miedos ocultos y la intuición femenina.",
    "love": "Incertidumbre, ilusiones engañosas o necesidad de enfrentar miedos profundos en la pareja.",
    "money": "Falta de claridad financiera. Cuidado con engaños o inversiones que parecen lo que no son.",
    "work": "Confusión en los objetivos, chismes en el trabajo o necesidad de usar la intuición ante la falta de datos.",
    "advice": "No te dejes llevar por las sombras. Enfrenta tus miedos y busca la claridad tras la niebla."
  },
  "maj_19": {
    "general": "El Sol representa la alegría plena, el éxito, la vitalidad y la claridad absoluta.",
    "love": "Felicidad compartida, amor radiante, éxito en la pareja y momentos de gran celebración.",
    "money": "Éxito financiero total, prosperidad y claridad para realizar inversiones exitosas.",
    "work": "Reconocimiento público, éxito en proyectos y un periodo de gran energía y productividad.",
    "advice": "Brilla con toda tu intensidad. Es tu momento de disfrutar y compartir tu éxito."
  },
  "maj_20": {
    "general": "El Juicio simboliza el despertar, la evaluación del pasado, el perdón y el llamado a una nueva vida.",
    "love": "Reconciliación, superación de viejos patrones o una decisión final que libera el corazón.",
    "money": "Resolución de deudas antiguas, evaluación de finanzas y una nueva oportunidad económica.",
    "work": "Vocación encontrada, cambio de rumbo profesional tras una reflexión profunda o ascenso merecido.",
    "advice": "Escucha tu llamado interior. Perdona el pasado y prepárate para renacer."
  },
  "maj_21": {
    "general": "El Mundo representa la culminación exitosa, la integración, el viaje y la plenitud total.",
    "love": "Realización amorosa, unión perfecta o viaje inolvidable con la pareja. Ciclo de amor completado.",
    "money": "Éxito financiero global, recompensas por el esfuerzo y seguridad económica total.",
    "work": "Logros internacionales, finalización exitosa de grandes proyectos y reconocimiento mundial.",
    "advice": "Celebra tus logros. Has llegado a la meta y el mundo está a tus pies."
  },
  "wands_ace": {
    "general": "El As de Bastos representa un nuevo comienzo potente en el plano de la acción.",
    "love": "Nuevo inicio apasionado.",
    "money": "Oportunidad de crear proyectos.",
    "work": "Nueva chispa creativa.",
    "advice": "Aprovecha esta semilla. Tienes todo el potencial para que crezca."
  },
  "wands_2": {
    "general": "El 2 de Bastos indica dualidad en tus acciones.",
    "love": "Situación de equilibrio y crecimiento.",
    "money": "Cuidado con gastos imprevistos.",
    "work": "Esfuerzo individual necesario.",
    "advice": "Enfócate en la energía del 2 para equilibrar tu situación actual."
  },
  "wands_3": {
    "general": "El 3 de Bastos indica expansión en tus acciones.",
    "love": "Retos que requieren comunicación.",
    "money": "Cuidado con gastos imprevistos.",
    "work": "Colaboración y éxito compartido.",
    "advice": "Enfócate en la energía del 3 para equilibrar tu situación actual."
  },
  "wands_4": {
    "general": "El 4 de Bastos indica estabilidad en tus acciones.",
    "love": "Situación de equilibrio y crecimiento.",
    "money": "Progreso constante y seguro.",
    "work": "Esfuerzo individual necesario.",
    "advice": "Enfócate en la energía del 4 para equilibrar tu situación actual."
  },
  "wands_5": {
    "general": "El 5 de Bastos indica pérdida en tus acciones.",
    "love": "Retos que requieren comunicación.",
    "money": "Cuidado con gastos imprevistos.",
    "work": "Esfuerzo individual necesario.",
    "advice": "Enfócate en la energía del 5 para equilibrar tu situación actual."
  },
  "wands_6": {
    "general": "El 6 de Bastos indica viaje en tus acciones.",
    "love": "Situación de equilibrio y crecimiento.",
    "money": "Progreso constante y seguro.",
    "work": "Colaboración y éxito compartido.",
    "advice": "Enfócate en la energía del 6 para equilibrar tu situación actual."
  },
  "wands_7": {
    "general": "El 7 de Bastos indica opciones en tus acciones.",
    "love": "Retos que requieren comunicación.",
    "money": "Cuidado con gastos imprevistos.",
    "work": "Esfuerzo individual necesario.",
    "advice": "Enfócate en la energía del 7 para equilibrar tu situación actual."
  },
  "wands_8": {
    "general": "El 8 de Bastos indica movimiento en tus acciones.",
    "love": "Situación de equilibrio y crecimiento.",
    "money": "Progreso constante y seguro.",
    "work": "Esfuerzo individual necesario.",
    "advice": "Enfócate en la energía del 8 para equilibrar tu situación actual."
  },
  "wands_9": {
    "general": "El 9 de Bastos indica ansiedad en tus acciones.",
    "love": "Retos que requieren comunicación.",
    "money": "Cuidado con gastos imprevistos.",
    "work": "Colaboración y éxito compartido.",
    "advice": "Enfócate en la energía del 9 para equilibrar tu situación actual."
  },
  "wands_10": {
    "general": "El 10 de Bastos indica culminación en tus acciones.",
    "love": "Situación de equilibrio y crecimiento.",
    "money": "Progreso constante y seguro.",
    "work": "Esfuerzo individual necesario.",
    "advice": "Enfócate en la energía del 10 para equilibrar tu situación actual."
  },
  "wands_page": {
    "general": "Sota de Bastos: Representa un mensaje.",
    "love": "Persona joven o noticia.",
    "money": "Pequeña oportunidad.",
    "work": "Aprendizaje.",
    "advice": "Actúa con la energía de Sota para resolver tu consulta."
  },
  "wands_knight": {
    "general": "Caballero de Bastos: Representa una acción rápida.",
    "love": "Persona que llega rápido.",
    "money": "Inversión arriesgada.",
    "work": "Viajes o cambios.",
    "advice": "Actúa con la energía de Caballero para resolver tu consulta."
  },
  "wands_queen": {
    "general": "Reina de Bastos: Representa maestría emocional/creativa.",
    "love": "Persona madura y amorosa.",
    "money": "Gestión sabia.",
    "work": "Creatividad liderada.",
    "advice": "Actúa con la energía de Reina para resolver tu consulta."
  },
  "wands_king": {
    "general": "Rey de Bastos: Representa autoridad y éxito.",
    "love": "Persona protectora y estable.",
    "money": "Gran éxito financiero.",
    "work": "Puesto de alta dirección.",
    "advice": "Actúa con la energía de Rey para resolver tu consulta."
  },
  "cups_ace": {
    "general": "El As de Copas representa un nuevo comienzo potente en el plano de las emociones.",
    "love": "Nuevo inicio emocional.",
    "money": "Oportunidad de invertir con el corazón.",
    "work": "Nueva vocación.",
    "advice": "Aprovecha esta semilla. Tienes todo el potencial para que crezca."
  },
  "cups_2": {
    "general": "El 2 de Copas indica dualidad en tus sentimientos.",
    "love": "Situación de equilibrio y crecimiento.",
    "money": "Cuidado con gastos imprevistos.",
    "work": "Esfuerzo individual necesario.",
    "advice": "Enfócate en la energía del 2 para equilibrar tu situación actual."
  },
  "cups_3": {
    "general": "El 3 de Copas indica expansión en tus sentimientos.",
    "love": "Retos que requieren comunicación.",
    "money": "Cuidado con gastos imprevistos.",
    "work": "Colaboración y éxito compartido.",
    "advice": "Enfócate en la energía del 3 para equilibrar tu situación actual."
  },
  "cups_4": {
    "general": "El 4 de Copas indica estabilidad en tus sentimientos.",
    "love": "Situación de equilibrio y crecimiento.",
    "money": "Progreso constante y seguro.",
    "work": "Esfuerzo individual necesario.",
    "advice": "Enfócate en la energía del 4 para equilibrar tu situación actual."
  },
  "cups_5": {
    "general": "El 5 de Copas indica pérdida en tus sentimientos.",
    "love": "Retos que requieren comunicación.",
    "money": "Cuidado con gastos imprevistos.",
    "work": "Esfuerzo individual necesario.",
    "advice": "Enfócate en la energía del 5 para equilibrar tu situación actual."
  },
  "cups_6": {
    "general": "El 6 de Copas indica viaje en tus sentimientos.",
    "love": "Situación de equilibrio y crecimiento.",
    "money": "Progreso constante y seguro.",
    "work": "Colaboración y éxito compartido.",
    "advice": "Enfócate en la energía del 6 para equilibrar tu situación actual."
  },
  "cups_7": {
    "general": "El 7 de Copas indica opciones en tus sentimientos.",
    "love": "Retos que requieren comunicación.",
    "money": "Cuidado con gastos imprevistos.",
    "work": "Esfuerzo individual necesario.",
    "advice": "Enfócate en la energía del 7 para equilibrar tu situación actual."
  },
  "cups_8": {
    "general": "El 8 de Copas indica movimiento en tus sentimientos.",
    "love": "Situación de equilibrio y crecimiento.",
    "money": "Progreso constante y seguro.",
    "work": "Esfuerzo individual necesario.",
    "advice": "Enfócate en la energía del 8 para equilibrar tu situación actual."
  },
  "cups_9": {
    "general": "El 9 de Copas indica ansiedad en tus sentimientos.",
    "love": "Retos que requieren comunicación.",
    "money": "Cuidado con gastos imprevistos.",
    "work": "Colaboración y éxito compartido.",
    "advice": "Enfócate en la energía del 9 para equilibrar tu situación actual."
  },
  "cups_10": {
    "general": "El 10 de Copas indica culminación en tus sentimientos.",
    "love": "Situación de equilibrio y crecimiento.",
    "money": "Progreso constante y seguro.",
    "work": "Esfuerzo individual necesario.",
    "advice": "Enfócate en la energía del 10 para equilibrar tu situación actual."
  },
  "cups_page": {
    "general": "Sota de Copas: Representa un mensaje.",
    "love": "Persona joven o noticia.",
    "money": "Pequeña oportunidad.",
    "work": "Aprendizaje.",
    "advice": "Actúa con la energía de Sota para resolver tu consulta."
  },
  "cups_knight": {
    "general": "Caballero de Copas: Representa una acción rápida.",
    "love": "Persona que llega rápido.",
    "money": "Inversión arriesgada.",
    "work": "Viajes o cambios.",
    "advice": "Actúa con la energía de Caballero para resolver tu consulta."
  },
  "cups_queen": {
    "general": "Reina de Copas: Representa maestría emocional/creativa.",
    "love": "Persona madura y amorosa.",
    "money": "Gestión sabia.",
    "work": "Creatividad liderada.",
    "advice": "Actúa con la energía de Reina para resolver tu consulta."
  },
  "cups_king": {
    "general": "Rey de Copas: Representa autoridad y éxito.",
    "love": "Persona protectora y estable.",
    "money": "Gran éxito financiero.",
    "work": "Puesto de alta dirección.",
    "advice": "Actúa con la energía de Rey para resolver tu consulta."
  },
  "swords_ace": {
    "general": "El As de Espadas representa un nuevo comienzo potente en el plano de el pensamiento.",
    "love": "Nuevo inicio que requiere claridad.",
    "money": "Oportunidad de tomar decisiones lógicas.",
    "work": "Nueva estrategia.",
    "advice": "Aprovecha esta semilla. Tienes todo el potencial para que crezca."
  },
  "swords_2": {
    "general": "El 2 de Espadas indica dualidad en tus pensamientos.",
    "love": "Situación de equilibrio y crecimiento.",
    "money": "Cuidado con gastos imprevistos.",
    "work": "Esfuerzo individual necesario.",
    "advice": "Enfócate en la energía del 2 para equilibrar tu situación actual."
  },
  "swords_3": {
    "general": "El 3 de Espadas indica expansión en tus pensamientos.",
    "love": "Retos que requieren comunicación.",
    "money": "Cuidado con gastos imprevistos.",
    "work": "Colaboración y éxito compartido.",
    "advice": "Enfócate en la energía del 3 para equilibrar tu situación actual."
  },
  "swords_4": {
    "general": "El 4 de Espadas indica estabilidad en tus pensamientos.",
    "love": "Situación de equilibrio y crecimiento.",
    "money": "Progreso constante y seguro.",
    "work": "Esfuerzo individual necesario.",
    "advice": "Enfócate en la energía del 4 para equilibrar tu situación actual."
  },
  "swords_5": {
    "general": "El 5 de Espadas indica pérdida en tus pensamientos.",
    "love": "Retos que requieren comunicación.",
    "money": "Cuidado con gastos imprevistos.",
    "work": "Esfuerzo individual necesario.",
    "advice": "Enfócate en la energía del 5 para equilibrar tu situación actual."
  },
  "swords_6": {
    "general": "El 6 de Espadas indica viaje en tus pensamientos.",
    "love": "Situación de equilibrio y crecimiento.",
    "money": "Progreso constante y seguro.",
    "work": "Colaboración y éxito compartido.",
    "advice": "Enfócate en la energía del 6 para equilibrar tu situación actual."
  },
  "swords_7": {
    "general": "El 7 de Espadas indica opciones en tus pensamientos.",
    "love": "Retos que requieren comunicación.",
    "money": "Cuidado con gastos imprevistos.",
    "work": "Esfuerzo individual necesario.",
    "advice": "Enfócate en la energía del 7 para equilibrar tu situación actual."
  },
  "swords_8": {
    "general": "El 8 de Espadas indica movimiento en tus pensamientos.",
    "love": "Situación de equilibrio y crecimiento.",
    "money": "Progreso constante y seguro.",
    "work": "Esfuerzo individual necesario.",
    "advice": "Enfócate en la energía del 8 para equilibrar tu situación actual."
  },
  "swords_9": {
    "general": "El 9 de Espadas indica ansiedad en tus pensamientos.",
    "love": "Retos que requieren comunicación.",
    "money": "Cuidado con gastos imprevistos.",
    "work": "Colaboración y éxito compartido.",
    "advice": "Enfócate en la energía del 9 para equilibrar tu situación actual."
  },
  "swords_10": {
    "general": "El 10 de Espadas indica culminación en tus pensamientos.",
    "love": "Situación de equilibrio y crecimiento.",
    "money": "Progreso constante y seguro.",
    "work": "Esfuerzo individual necesario.",
    "advice": "Enfócate en la energía del 10 para equilibrar tu situación actual."
  },
  "swords_page": {
    "general": "Sota de Espadas: Representa un mensaje.",
    "love": "Persona joven o noticia.",
    "money": "Pequeña oportunidad.",
    "work": "Aprendizaje.",
    "advice": "Actúa con la energía de Sota para resolver tu consulta."
  },
  "swords_knight": {
    "general": "Caballero de Espadas: Representa una acción rápida.",
    "love": "Persona que llega rápido.",
    "money": "Inversión arriesgada.",
    "work": "Viajes o cambios.",
    "advice": "Actúa con la energía de Caballero para resolver tu consulta."
  },
  "swords_queen": {
    "general": "Reina de Espadas: Representa maestría emocional/creativa.",
    "love": "Persona madura y amorosa.",
    "money": "Gestión sabia.",
    "work": "Creatividad liderada.",
    "advice": "Actúa con la energía de Reina para resolver tu consulta."
  },
  "swords_king": {
    "general": "Rey de Espadas: Representa autoridad y éxito.",
    "love": "Persona protectora y estable.",
    "money": "Gran éxito financiero.",
    "work": "Puesto de alta dirección.",
    "advice": "Actúa con la energía de Rey para resolver tu consulta."
  },
  "pentacles_ace": {
    "general": "El As de Oros representa un nuevo comienzo potente en el plano de lo material.",
    "love": "Nuevo inicio estable.",
    "money": "Oportunidad de ganar dinero real.",
    "work": "Nueva oferta de empleo.",
    "advice": "Aprovecha esta semilla. Tienes todo el potencial para que crezca."
  },
  "pentacles_2": {
    "general": "El 2 de Oros indica dualidad en tus finanzas.",
    "love": "Situación de equilibrio y crecimiento.",
    "money": "Cuidado con gastos imprevistos.",
    "work": "Esfuerzo individual necesario.",
    "advice": "Enfócate en la energía del 2 para equilibrar tu situación actual."
  },
  "pentacles_3": {
    "general": "El 3 de Oros indica expansión en tus finanzas.",
    "love": "Retos que requieren comunicación.",
    "money": "Cuidado con gastos imprevistos.",
    "work": "Colaboración y éxito compartido.",
    "advice": "Enfócate en la energía del 3 para equilibrar tu situación actual."
  },
  "pentacles_4": {
    "general": "El 4 de Oros indica estabilidad en tus finanzas.",
    "love": "Situación de equilibrio y crecimiento.",
    "money": "Progreso constante y seguro.",
    "work": "Esfuerzo individual necesario.",
    "advice": "Enfócate en la energía del 4 para equilibrar tu situación actual."
  },
  "pentacles_5": {
    "general": "El 5 de Oros indica pérdida en tus finanzas.",
    "love": "Retos que requieren comunicación.",
    "money": "Cuidado con gastos imprevistos.",
    "work": "Esfuerzo individual necesario.",
    "advice": "Enfócate en la energía del 5 para equilibrar tu situación actual."
  },
  "pentacles_6": {
    "general": "El 6 de Oros indica viaje en tus finanzas.",
    "love": "Situación de equilibrio y crecimiento.",
    "money": "Progreso constante y seguro.",
    "work": "Colaboración y éxito compartido.",
    "advice": "Enfócate en la energía del 6 para equilibrar tu situación actual."
  },
  "pentacles_7": {
    "general": "El 7 de Oros indica opciones en tus finanzas.",
    "love": "Retos que requieren comunicación.",
    "money": "Cuidado con gastos imprevistos.",
    "work": "Esfuerzo individual necesario.",
    "advice": "Enfócate en la energía del 7 para equilibrar tu situación actual."
  },
  "pentacles_8": {
    "general": "El 8 de Oros indica movimiento en tus finanzas.",
    "love": "Situación de equilibrio y crecimiento.",
    "money": "Progreso constante y seguro.",
    "work": "Esfuerzo individual necesario.",
    "advice": "Enfócate en la energía del 8 para equilibrar tu situación actual."
  },
  "pentacles_9": {
    "general": "El 9 de Oros indica ansiedad en tus finanzas.",
    "love": "Retos que requieren comunicación.",
    "money": "Cuidado con gastos imprevistos.",
    "work": "Colaboración y éxito compartido.",
    "advice": "Enfócate en la energía del 9 para equilibrar tu situación actual."
  },
  "pentacles_10": {
    "general": "El 10 de Oros indica culminación en tus finanzas.",
    "love": "Situación de equilibrio y crecimiento.",
    "money": "Progreso constante y seguro.",
    "work": "Esfuerzo individual necesario.",
    "advice": "Enfócate en la energía del 10 para equilibrar tu situación actual."
  },
  "pentacles_page": {
    "general": "Sota de Oros: Representa un mensaje.",
    "love": "Persona joven o noticia.",
    "money": "Pequeña oportunidad.",
    "work": "Aprendizaje.",
    "advice": "Actúa con la energía de Sota para resolver tu consulta."
  },
  "pentacles_knight": {
    "general": "Caballero de Oros: Representa una acción rápida.",
    "love": "Persona que llega rápido.",
    "money": "Inversión arriesgada.",
    "work": "Viajes o cambios.",
    "advice": "Actúa con la energía de Caballero para resolver tu consulta."
  },
  "pentacles_queen": {
    "general": "Reina de Oros: Representa maestría emocional/creativa.",
    "love": "Persona madura y amorosa.",
    "money": "Gestión sabia.",
    "work": "Creatividad liderada.",
    "advice": "Actúa con la energía de Reina para resolver tu consulta."
  },
  "pentacles_king": {
    "general": "Rey de Oros: Representa autoridad y éxito.",
    "love": "Persona protectora y estable.",
    "money": "Gran éxito financiero.",
    "work": "Puesto de alta dirección.",
    "advice": "Actúa con la energía de Rey para resolver tu consulta."
  }
};