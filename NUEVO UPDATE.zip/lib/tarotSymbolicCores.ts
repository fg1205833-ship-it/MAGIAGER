/**
 * Núcleos Simbólicos de Cartas de Tarot
 * 
 * Define la esencia única de cada carta. A partir de estos núcleos,
 * se generan dinámicamente todas las interpretaciones para:
 * - Todas las secciones
 * - Todos los elementos zodiacales
 * - Todas las variantes (Luz/Sombra/Equilibrio)
 * - Todos los tarots (RWS, Marsella, Ángeles, Español)
 * 
 * Esto evita archivos estáticos explosivos y garantiza coherencia.
 */

import { Element, Variant, Section } from './tarotDatabase';

/**
 * Núcleo simbólico de una carta
 */
export interface SymbolicCore {
  cardId: string;
  name: string;
  number?: number;
  suit?: string;
  type: 'major' | 'minor';
  
  // Esencia de la carta
  coreArchetype: string; // El arquetipo fundamental (ej: "Transformación", "Poder", "Comunicación")
  coreMeaning: string; // Significado central en una frase
  coreSymbols: string[]; // Símbolos principales
  coreConflict: string; // El conflicto o tensión que representa
  coreResolution: string; // Cómo se resuelve ese conflicto
  
  // Manifestaciones por variante
  lightExpression: string; // Cómo se expresa en luz
  shadowExpression: string; // Cómo se expresa en sombra
  balanceExpression: string; // Cómo se expresa en equilibrio
  
  // Influencias por elemento
  fireInfluence: string; // Cómo el fuego activa esta carta
  earthInfluence: string; // Cómo la tierra ancla esta carta
  airInfluence: string; // Cómo el aire ilumina esta carta
  waterInfluence: string; // Cómo el agua profundiza esta carta
  
  // Manifestaciones por sección
  sectionFocus: Record<Section, {
    focus: string; // En qué se enfoca esta carta en esta sección
    challenge: string; // El desafío en esta sección
    opportunity: string; // La oportunidad en esta sección
  }>;
}

/**
 * ARCANOS MAYORES - Núcleos Simbólicos
 */

export const MAJOR_ARCANA_CORES: Record<string, SymbolicCore> = {
  'maj_0': {
    cardId: 'maj_0',
    name: 'El Loco',
    number: 0,
    type: 'major',
    coreArchetype: 'El Salto al Vacío',
    coreMeaning: 'Fe en lo desconocido, nuevo comienzo, riesgo consciente',
    coreSymbols: ['el acantilado', 'el perro', 'el sol', 'la mochila', 'la libertad'],
    coreConflict: 'Miedo vs Aventura, Seguridad vs Libertad',
    coreResolution: 'Confiar en el proceso, saltar con fe',
    lightExpression: 'Valentía para lo nuevo, fe genuina, espontaneidad auténtica',
    shadowExpression: 'Impulsividad ciega, falta de dirección, caos destructivo',
    balanceExpression: 'Fe consciente, aventura responsable, libertad con propósito',
    fireInfluence: 'Impulsa la acción rápida y la conquista de lo nuevo',
    earthInfluence: 'Ancla la aventura en la realidad, requiere paciencia',
    airInfluence: 'Ilumina las posibilidades, expande la perspectiva',
    waterInfluence: 'Profundiza la intuición, conecta con el flujo emocional',
    sectionFocus: {
      mesa: {
        focus: 'Nueva situación llena de posibilidades',
        challenge: 'No saber qué viene',
        opportunity: 'Saltar al vacío con fe',
      },
      amor: {
        focus: 'Nuevo romance inesperado',
        challenge: 'Miedo a lo desconocido en el amor',
        opportunity: 'Abrirse a una conexión sorpresiva',
      },
      dinero: {
        focus: 'Inversión arriesgada con potencial',
        challenge: 'Riesgo financiero sin garantías',
        opportunity: 'Ganancias extraordinarias si actúas',
      },
      trabajo: {
        focus: 'Cambio de carrera o nuevo proyecto',
        challenge: 'Abandonar la seguridad del presente',
        opportunity: 'Explorar nuevas posibilidades profesionales',
      },
      salud: {
        focus: 'Nuevas prácticas de sanación',
        challenge: 'Probar lo desconocido en salud',
        opportunity: 'Descubrir métodos que funcionan',
      },
      decisiones: {
        focus: 'Decisión que requiere fe',
        challenge: 'No tener certeza antes de decidir',
        opportunity: 'Confiar en la intuición',
      },
      consejo: {
        focus: 'Ten fe en ti mismo',
        challenge: 'Superar el miedo al cambio',
        opportunity: 'Vivir auténticamente',
      },
      pasado_presente_futuro: {
        focus: 'Transformación a través de la fe',
        challenge: 'Soltar el pasado',
        opportunity: 'Crear un futuro extraordinario',
      },
    },
  },

  'maj_1': {
    cardId: 'maj_1',
    name: 'El Mago',
    number: 1,
    type: 'major',
    coreArchetype: 'El Poder Personal',
    coreMeaning: 'Manifestación, habilidad, control consciente de recursos',
    coreSymbols: ['la mesa de trabajo', 'los cuatro elementos', 'el símbolo del infinito', 'la varita', 'la intención'],
    coreConflict: 'Poder vs Responsabilidad, Capacidad vs Ética',
    coreResolution: 'Usar el poder con integridad',
    lightExpression: 'Maestría consciente, creación auténtica, poder responsable',
    shadowExpression: 'Manipulación, abuso de poder, engaño',
    balanceExpression: 'Poder ético, liderazgo consciente, creación responsable',
    fireInfluence: 'Acelera la manifestación, impulsa la acción decidida',
    earthInfluence: 'Materializa las ideas, construye sólidamente',
    airInfluence: 'Comunica con claridad, expande las posibilidades',
    waterInfluence: 'Profundiza la intención, conecta con el propósito emocional',
    sectionFocus: {
      mesa: {
        focus: 'Tienes el poder para manifestar',
        challenge: 'Usar el poder correctamente',
        opportunity: 'Crear la realidad que deseas',
      },
      amor: {
        focus: 'Tu magnetismo atrae',
        challenge: 'No manipular emocionalmente',
        opportunity: 'Crear conexión auténtica',
      },
      dinero: {
        focus: 'Tu habilidad genera ingresos',
        challenge: 'Usar la inteligencia éticamente',
        opportunity: 'Crear riqueza duradera',
      },
      trabajo: {
        focus: 'Tu competencia es reconocida',
        challenge: 'Liderar sin arrogancia',
        opportunity: 'Asumir mayor responsabilidad',
      },
      salud: {
        focus: 'Tu mente sana tu cuerpo',
        challenge: 'No negar síntomas reales',
        opportunity: 'Tomar control de tu salud',
      },
      decisiones: {
        focus: 'Tienes el poder de decidir',
        challenge: 'Decidir desde la integridad',
        opportunity: 'Elegir conscientemente',
      },
      consejo: {
        focus: 'Reconoce tu poder',
        challenge: 'Usar el poder responsablemente',
        opportunity: 'Manifestar tu propósito',
      },
      pasado_presente_futuro: {
        focus: 'Tu poder se desarrolla',
        challenge: 'Aprender de los errores',
        opportunity: 'Dominar tu destino',
      },
    },
  },

  'maj_2': {
    cardId: 'maj_2',
    name: 'La Sacerdotisa',
    number: 2,
    type: 'major',
    coreArchetype: 'La Sabiduría Interior',
    coreMeaning: 'Intuición, misterio, conocimiento oculto, escucha profunda',
    coreSymbols: ['el velo', 'el libro cerrado', 'la luna', 'el silencio', 'la intuición'],
    coreConflict: 'Conocimiento vs Misterio, Acción vs Observación',
    coreResolution: 'Escuchar el silencio, confiar en la intuición',
    lightExpression: 'Intuición clara, sabiduría profunda, misterio revelador',
    shadowExpression: 'Secretos destructivos, intuición negada, misterio paralizante',
    balanceExpression: 'Intuición y lógica integradas, misterio respetado',
    fireInfluence: 'Enciende la intuición, impulsa la acción desde la sabiduría',
    earthInfluence: 'Ancla la intuición en la realidad, requiere paciencia',
    airInfluence: 'Ilumina los misterios, expande la comprensión',
    waterInfluence: 'Profundiza la intuición, conecta con lo emocional oculto',
    sectionFocus: {
      mesa: {
        focus: 'La respuesta está dentro de ti',
        challenge: 'Confiar en la intuición',
        opportunity: 'Descubrir la verdad oculta',
      },
      amor: {
        focus: 'Conexión espiritual profunda',
        challenge: 'Revelar secretos',
        opportunity: 'Intimidad auténtica',
      },
      dinero: {
        focus: 'Oportunidades ocultas',
        challenge: 'Investigar antes de actuar',
        opportunity: 'Descubrir riqueza oculta',
      },
      trabajo: {
        focus: 'Sabiduría y profundidad',
        challenge: 'Aprender lo que no es obvio',
        opportunity: 'Dominar tu campo',
      },
      salud: {
        focus: 'Tu cuerpo habla',
        challenge: 'Escuchar los síntomas',
        opportunity: 'Sanación desde la raíz',
      },
      decisiones: {
        focus: 'La intuición sabe',
        challenge: 'Confiar sin certeza',
        opportunity: 'Decidir desde la sabiduría',
      },
      consejo: {
        focus: 'Desarrolla tu intuición',
        challenge: 'Superar la duda',
        opportunity: 'Vivir desde la sabiduría',
      },
      pasado_presente_futuro: {
        focus: 'El misterio se revela',
        challenge: 'Soltar la necesidad de saber',
        opportunity: 'Confiar en el proceso',
      },
    },
  },
};

/**
 * ARCANOS MENORES - Núcleos Simbólicos
 */

export const MINOR_ARCANA_CORES: Record<string, SymbolicCore> = {
  // COPAS
  'cups_ace': {
    cardId: 'cups_ace',
    name: 'As de Copas',
    suit: 'Copas',
    type: 'minor',
    coreArchetype: 'La Apertura Emocional',
    coreMeaning: 'Nuevo amor, inspiración emocional, conexión profunda',
    coreSymbols: ['la copa rebosante', 'el agua que fluye', 'la mano divina', 'la apertura', 'el regalo'],
    coreConflict: 'Apertura vs Protección, Vulnerabilidad vs Seguridad',
    coreResolution: 'Abrirse a la conexión auténtica',
    lightExpression: 'Amor genuino, conexión auténtica, inspiración emocional',
    shadowExpression: 'Amor superficial, conexión falsa, emoción negada',
    balanceExpression: 'Amor consciente, vulnerabilidad segura, conexión auténtica',
    fireInfluence: 'Enciende la pasión, acelera la conexión',
    earthInfluence: 'Ancla el amor en la realidad, requiere compromiso',
    airInfluence: 'Comunica el amor, expande la comprensión emocional',
    waterInfluence: 'Profundiza la emoción, conecta con el flujo del corazón',
    sectionFocus: {
      mesa: {
        focus: 'Nuevo comienzo emocional',
        challenge: 'Abrirse a lo nuevo',
        opportunity: 'Conexión transformadora',
      },
      amor: {
        focus: 'Nuevo romance o profundización',
        challenge: 'Vulnerabilidad auténtica',
        opportunity: 'Amor verdadero',
      },
      dinero: {
        focus: 'Oportunidad con corazón',
        challenge: 'Actuar desde la pasión',
        opportunity: 'Abundancia que fluye',
      },
      trabajo: {
        focus: 'Proyecto que apasiona',
        challenge: 'Mantener la pasión',
        opportunity: 'Trabajo que amas',
      },
      salud: {
        focus: 'Sanación emocional',
        challenge: 'Abrir el corazón',
        opportunity: 'Bienestar integral',
      },
      decisiones: {
        focus: 'Decidir desde el corazón',
        challenge: 'Confiar en la emoción',
        opportunity: 'Decisión auténtica',
      },
      consejo: {
        focus: 'Abre tu corazón',
        challenge: 'Superar el miedo a la vulnerabilidad',
        opportunity: 'Vivir desde el amor',
      },
      pasado_presente_futuro: {
        focus: 'El corazón se abre',
        challenge: 'Soltar el cierre emocional',
        opportunity: 'Futuro lleno de amor',
      },
    },
  },

  'swords_ace': {
    cardId: 'swords_ace',
    name: 'As de Espadas',
    suit: 'Espadas',
    type: 'minor',
    coreArchetype: 'La Verdad Revelada',
    coreMeaning: 'Claridad, verdad, comunicación, revelación',
    coreSymbols: ['la espada que corta', 'la verdad que hiere', 'la claridad', 'la comunicación', 'la revelación'],
    coreConflict: 'Verdad vs Confort, Claridad vs Ilusión',
    coreResolution: 'Hablar la verdad con compasión',
    lightExpression: 'Verdad liberadora, comunicación clara, claridad reveladora',
    shadowExpression: 'Verdad hiriente, comunicación cortante, claridad despiadada',
    balanceExpression: 'Verdad compasiva, comunicación honesta, claridad integradora',
    fireInfluence: 'Acelera la verdad, impulsa la comunicación directa',
    earthInfluence: 'Ancla la verdad en hechos, requiere paciencia',
    airInfluence: 'Ilumina la verdad, expande la comprensión',
    waterInfluence: 'Profundiza la verdad emocional, conecta con la compasión',
    sectionFocus: {
      mesa: {
        focus: 'La verdad se revela',
        challenge: 'Aceptar la verdad',
        opportunity: 'Actuar desde la claridad',
      },
      amor: {
        focus: 'Verdad en la relación',
        challenge: 'Comunicación honesta',
        opportunity: 'Intimidad auténtica',
      },
      dinero: {
        focus: 'Claridad financiera',
        challenge: 'Enfrentar la realidad',
        opportunity: 'Decisiones informadas',
      },
      trabajo: {
        focus: 'Verdad profesional',
        challenge: 'Comunicación clara',
        opportunity: 'Resolución de conflictos',
      },
      salud: {
        focus: 'Diagnóstico claro',
        challenge: 'Aceptar la verdad',
        opportunity: 'Acción informada',
      },
      decisiones: {
        focus: 'Decidir desde la verdad',
        challenge: 'Enfrentar la realidad',
        opportunity: 'Decisión informada',
      },
      consejo: {
        focus: 'Habla tu verdad',
        challenge: 'Comunicar con compasión',
        opportunity: 'Vivir auténticamente',
      },
      pasado_presente_futuro: {
        focus: 'La verdad se revela',
        challenge: 'Soltar las ilusiones',
        opportunity: 'Futuro basado en la verdad',
      },
    },
  },
};

/**
 * Función para obtener núcleo simbólico de una carta
 */
export function getSymbolicCore(cardId: string): SymbolicCore | null {
  return MAJOR_ARCANA_CORES[cardId] || MINOR_ARCANA_CORES[cardId] || null;
}

/**
 * Función para obtener todos los núcleos
 */
export function getAllSymbolicCores(): Record<string, SymbolicCore> {
  return {
    ...MAJOR_ARCANA_CORES,
    ...MINOR_ARCANA_CORES,
  };
}

/**
 * Función para validar que un núcleo simbólico es auténtico
 */
export function validateSymbolicCore(core: SymbolicCore): {
  isValid: boolean;
  warnings: string[];
} {
  const warnings: string[] = [];

  if (!core.coreArchetype || core.coreArchetype.length < 5) {
    warnings.push('Arquetipo muy corto o vacío');
  }

  if (!core.coreMeaning || core.coreMeaning.length < 10) {
    warnings.push('Significado central muy corto');
  }

  if (!core.coreSymbols || core.coreSymbols.length < 3) {
    warnings.push('Faltan símbolos principales');
  }

  if (!core.lightExpression || !core.shadowExpression || !core.balanceExpression) {
    warnings.push('Faltan expresiones de variantes');
  }

  const sectionCount = Object.keys(core.sectionFocus).length;
  if (sectionCount < 8) {
    warnings.push(`Solo ${sectionCount} secciones definidas, se requieren 8`);
  }

  return {
    isValid: warnings.length === 0,
    warnings,
  };
}
