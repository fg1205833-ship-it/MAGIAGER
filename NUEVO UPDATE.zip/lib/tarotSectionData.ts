/**
 * Datos de Interpretaciones Específicas por Sección
 * 
 * Este archivo contiene las interpretaciones detalladas para cada sección
 * (mesa, amor, dinero, trabajo, etc.) con variantes de Luz, Sombra y Equilibrio.
 * 
 * Cada sección tiene interpretaciones distintas para la MISMA carta,
 * reflejando cómo el contexto cambia completamente el significado.
 */

import {
  TarotCardComplete,
  InterpretationVariants,
  createVariants,
  createCardInterpretation,
  tarotDB,
} from './tarotDatabase';

/**
 * Arcanos Mayores - Interpretaciones por Sección
 */

// EL LOCO (0)
export const LOCO_MESA: InterpretationVariants = createVariants(
  createCardInterpretation(
    'Una situación nueva y llena de posibilidades está frente a ti. El universo te invita a saltar al vacío con fe.',
    'Atrévete a lo desconocido. La vida comienza donde termina la zona de confort.',
    ['nuevo comienzo', 'fe', 'aventura', 'espontaneidad']
  ),
  createCardInterpretation(
    'Cuidado con decisiones impulsivas que no han sido bien pensadas. El caos puede ser tu aliado o tu enemigo.',
    'Reflexiona antes de actuar. No todo lo nuevo es beneficioso.',
    ['impulsividad', 'riesgo', 'incertidumbre', 'caos']
  ),
  createCardInterpretation(
    'Existe un equilibrio entre la aventura y la prudencia. Necesitas fe, pero también discernimiento.',
    'Confía en tu intuición, pero mantén los pies en la tierra.',
    ['balance', 'fe consciente', 'aventura calculada']
  )
);

export const LOCO_AMOR: InterpretationVariants = createVariants(
  createCardInterpretation(
    'Un nuevo romance inesperado está por llegar. Alguien especial entrará en tu vida de forma sorpresiva.',
    'Abre tu corazón a lo inesperado. El amor verdadero a menudo llega cuando menos lo esperas.',
    ['nuevo amor', 'sorpresa', 'pasión', 'libertad emocional'],
    'Un nuevo romance lleno de libertad y espontaneidad'
  ),
  createCardInterpretation(
    'Cuidado con enamorarte demasiado rápido sin conocer realmente a la persona. La impulsividad puede causar dolor.',
    'No confundas la pasión momentánea con el amor verdadero.',
    ['impulsividad amorosa', 'riesgo emocional', 'superficialidad'],
    'Enamorarse sin pensar puede traer consecuencias'
  ),
  createCardInterpretation(
    'El amor requiere tanto espontaneidad como compromiso. Necesitas libertad dentro de la relación.',
    'Busca a alguien que entienda tu necesidad de aventura y libertad.',
    ['amor libre', 'compatibilidad', 'aventura compartida'],
    'Un amor que permite la libertad y la aventura'
  )
);

export const LOCO_DINERO: InterpretationVariants = createVariants(
  createCardInterpretation(
    'Una oportunidad de inversión inesperada aparece. El riesgo calculado puede traer grandes ganancias.',
    'No temas tomar riesgos financieros si has hecho tu investigación.',
    ['inversión arriesgada', 'oportunidad', 'crecimiento', 'aventura financiera'],
    'Una oportunidad de inversión inesperada'
  ),
  createCardInterpretation(
    'Cuidado con gastos impulsivos y decisiones financieras sin reflexión. El dinero se puede perder fácilmente.',
    'Piensa dos veces antes de hacer grandes gastos o inversiones.',
    ['gasto impulsivo', 'pérdida', 'riesgo excesivo', 'imprudencia'],
    'Gastos impulsivos que pueden causar problemas'
  ),
  createCardInterpretation(
    'Equilibra tu deseo de aventura financiera con la prudencia. Algunos riesgos valen la pena, otros no.',
    'Toma riesgos calculados, no apuestas ciegas.',
    ['inversión inteligente', 'balance', 'oportunidad medida'],
    'Riesgos financieros bien calculados'
  )
);

export const LOCO_TRABAJO: InterpretationVariants = createVariants(
  createCardInterpretation(
    'Un nuevo proyecto o cambio de carrera está en el horizonte. Es momento de explorar nuevas posibilidades profesionales.',
    'Atrévete a cambiar de dirección si tu intuición te lo dice.',
    ['nuevo proyecto', 'cambio de carrera', 'innovación', 'oportunidad'],
    'Un nuevo proyecto o cambio de carrera'
  ),
  createCardInterpretation(
    'Cuidado con cambios de trabajo impulsivos sin un plan claro. Podrías perder estabilidad.',
    'No abandones tu empleo sin tener otro seguro.',
    ['cambio impulsivo', 'inestabilidad', 'riesgo laboral', 'falta de plan'],
    'Cambios laborales impulsivos'
  ),
  createCardInterpretation(
    'Considera nuevas oportunidades, pero con un plan. La innovación en tu trabajo actual también es posible.',
    'Explora nuevas posibilidades sin abandonar lo que funciona.',
    ['innovación', 'oportunidad medida', 'crecimiento profesional'],
    'Innovación en tu carrera actual'
  )
);

export const LOCO_CONSEJO: InterpretationVariants = createVariants(
  createCardInterpretation(
    'La vida te pide que tengas fe en ti mismo. Confía en tu intuición y en el proceso del universo.',
    'Atrévete a ser auténtico. El mundo necesita tu unicidad.',
    ['fe', 'autenticidad', 'confianza', 'libertad'],
    'Ten fe en ti mismo y en el universo'
  ),
  createCardInterpretation(
    'Cuidado con la impulsividad y la falta de dirección. Necesitas un plan, no solo esperanza.',
    'Reflexiona antes de actuar. La fe sin acción es solo fantasía.',
    ['reflexión', 'plan', 'responsabilidad', 'madurez'],
    'Necesitas reflexión y un plan claro'
  ),
  createCardInterpretation(
    'Equilibra tu fe con la acción. Ten confianza, pero también sé responsable de tus decisiones.',
    'Sé aventurero, pero también consciente de las consecuencias.',
    ['fe consciente', 'acción responsable', 'balance'],
    'Fe y acción en equilibrio'
  )
);

// EL MAGO (1)
export const MAGO_MESA: InterpretationVariants = createVariants(
  createCardInterpretation(
    'Tienes el poder en tus manos. Todo lo que necesitas para manifestar tu realidad está disponible ahora.',
    'Usa tus habilidades y recursos para crear lo que deseas.',
    ['poder', 'manifestación', 'habilidad', 'control'],
    'Tienes el poder para manifestar lo que deseas'
  ),
  createCardInterpretation(
    'Cuidado con el abuso de poder o la manipulación. Lo que construyes sin integridad se derrumbará.',
    'No uses tus habilidades para engañar o manipular a otros.',
    ['manipulación', 'engaño', 'abuso de poder', 'falta de ética'],
    'Cuidado con el abuso de poder'
  ),
  createCardInterpretation(
    'Tu poder es real, pero debe usarse con responsabilidad. Tienes la capacidad de crear cambios positivos.',
    'Usa tus dones para el bien de todos, no solo para ti.',
    ['poder responsable', 'capacidad', 'liderazgo ético'],
    'Poder usado con responsabilidad'
  )
);

export const MAGO_AMOR: InterpretationVariants = createVariants(
  createCardInterpretation(
    'Tu magnetismo personal es irresistible ahora. Atraes a quien deseas con tu carisma y seguridad.',
    'Confía en tu atractivo y en tu capacidad de seducción.',
    ['magnetismo', 'atracción', 'carisma', 'seguridad'],
    'Tu magnetismo personal atrae a otros'
  ),
  createCardInterpretation(
    'Cuidado con manipular emocionalmente a tu pareja o a quien te interesa. El engaño destruye la confianza.',
    'No uses tu inteligencia para jugar con los sentimientos de otros.',
    ['manipulación emocional', 'engaño', 'juegos', 'falta de sinceridad'],
    'Cuidado con la manipulación emocional'
  ),
  createCardInterpretation(
    'Tu capacidad de comunicación es tu mayor fortaleza en el amor. Sé honesto y auténtico.',
    'Usa tu inteligencia para entender y conectar con tu pareja.',
    ['comunicación honesta', 'conexión', 'autenticidad'],
    'Comunicación honesta en el amor'
  )
);

export const MAGO_DINERO: InterpretationVariants = createVariants(
  createCardInterpretation(
    'Tu habilidad para generar ingresos es excepcional. Usa tus talentos para crear abundancia.',
    'Confía en tu capacidad de ganar dinero a través de tus habilidades.',
    ['generación de ingresos', 'habilidad', 'abundancia', 'éxito financiero'],
    'Tu habilidad para generar ingresos'
  ),
  createCardInterpretation(
    'Cuidado con esquemas fraudulentos o dinero fácil. Lo que parece demasiado bueno probablemente lo es.',
    'No busques atajos financieros que comprometan tu integridad.',
    ['fraude', 'dinero fácil', 'esquemas', 'riesgo'],
    'Cuidado con el dinero fácil'
  ),
  createCardInterpretation(
    'Tu inteligencia financiera te permite tomar decisiones sabias. Diversifica tus ingresos.',
    'Usa tu capacidad de análisis para hacer crecer tu riqueza.',
    ['inteligencia financiera', 'diversificación', 'crecimiento'],
    'Inteligencia financiera'
  )
);

export const MAGO_TRABAJO: InterpretationVariants = createVariants(
  createCardInterpretation(
    'Tu competencia profesional es reconocida. Es momento de asumir más responsabilidad o buscar ascenso.',
    'Confía en tu capacidad para liderar y resolver problemas.',
    ['competencia', 'liderazgo', 'ascenso', 'reconocimiento'],
    'Tu competencia profesional es reconocida'
  ),
  createCardInterpretation(
    'Cuidado con la arrogancia o el abuso de autoridad. Tus colegas pueden volverse en tu contra.',
    'No uses tu posición para manipular o controlar a otros.',
    ['arrogancia', 'abuso de poder', 'conflicto laboral', 'pérdida de confianza'],
    'Cuidado con la arrogancia'
  ),
  createCardInterpretation(
    'Tu liderazgo ético es tu mayor fortaleza. Inspira a otros con tu ejemplo.',
    'Usa tu influencia para crear un ambiente laboral positivo.',
    ['liderazgo ético', 'inspiración', 'influencia positiva'],
    'Liderazgo ético'
  )
);

export const MAGO_CONSEJO: InterpretationVariants = createVariants(
  createCardInterpretation(
    'Reconoce tu poder personal. Tienes todo lo que necesitas para lograr tus objetivos.',
    'Deja de esperar a otros. Toma acción ahora.',
    ['poder personal', 'acción', 'responsabilidad', 'manifestación'],
    'Reconoce tu poder personal'
  ),
  createCardInterpretation(
    'Tu poder debe venir acompañado de integridad. La verdadera fuerza está en la honestidad.',
    'No busques poder a través de la manipulación.',
    ['integridad', 'honestidad', 'ética', 'responsabilidad'],
    'El poder debe venir con integridad'
  ),
  createCardInterpretation(
    'Usa tu poder para ayudar a otros. La verdadera maestría es servir.',
    'Tu capacidad es un don para compartir.',
    ['servicio', 'maestría', 'generosidad', 'liderazgo'],
    'Usa tu poder para servir'
  )
);

/**
 * Función para registrar todas las interpretaciones en la base de datos
 */
export function registerSectionData(): void {
  // Esta función será llamada durante la inicialización de la aplicación
  // para registrar todas las interpretaciones de secciones en la base de datos
  
  // Ejemplo de cómo se registraría:
  // const locoCard = tarotDB.getCard('maj_0');
  // if (locoCard) {
  //   locoCard.sections.mesa = {
  //     generic: LOCO_MESA,
  //     bySign: {},
  //     byElement: {}
  //   };
  //   locoCard.sections.amor = {
  //     generic: LOCO_AMOR,
  //     bySign: {},
  //     byElement: {}
  //   };
  //   // ... etc
  // }
}

/**
 * Mapeo de cartas a sus interpretaciones por sección
 */
export const CARD_SECTION_INTERPRETATIONS: Record<string, {
  mesa?: InterpretationVariants;
  amor?: InterpretationVariants;
  dinero?: InterpretationVariants;
  trabajo?: InterpretationVariants;
  consejo?: InterpretationVariants;
}> = {
  'maj_0': {
    mesa: LOCO_MESA,
    amor: LOCO_AMOR,
    dinero: LOCO_DINERO,
    trabajo: LOCO_TRABAJO,
    consejo: LOCO_CONSEJO,
  },
  'maj_1': {
    mesa: MAGO_MESA,
    amor: MAGO_AMOR,
    dinero: MAGO_DINERO,
    trabajo: MAGO_TRABAJO,
    consejo: MAGO_CONSEJO,
  },
  // ... Se continuarían agregando todas las cartas
};

/**
 * Función para obtener interpretación de una carta por sección
 */
export function getCardSectionInterpretation(
  cardId: string,
  section: string
): InterpretationVariants | null {
  const cardInterps = CARD_SECTION_INTERPRETATIONS[cardId];
  if (!cardInterps) return null;

  const sectionKey = section as keyof typeof cardInterps;
  return cardInterps[sectionKey] || null;
}

/**
 * Función para inicializar todas las interpretaciones de secciones
 */
export function initializeSectionInterpretations(): void {
  // Iterar sobre todas las cartas y secciones
  for (const [cardId, interpretations] of Object.entries(CARD_SECTION_INTERPRETATIONS)) {
    const card = tarotDB.getCard(cardId);
    if (card) {
      // Registrar cada sección
      for (const [section, variants] of Object.entries(interpretations)) {
        if (variants) {
          if (!card.sections[section as any]) {
            card.sections[section as any] = {
              generic: variants,
              bySign: {},
              byElement: {},
            };
          } else {
            card.sections[section as any]!.generic = variants;
          }
        }
      }
    }
  }
}
