// Base de datos de Numerología Pitagórica Detallada
// Significados distintos para Camino de Vida, Número del Alma y Año Personal

export interface NumerologyProfile {
  title: string;
  description: string;
  mission?: string; // Para Camino de Vida
  challenges?: string; // Para Camino de Vida
  desire?: string; // Para Número del Alma
  focus?: string; // Para Año Personal
}

export const lifePathDB: Record<number, NumerologyProfile> = {
  1: {
    title: "El Líder Pionero",
    description: "El Camino de Vida 1 es el del innovador, el líder y el individuo independiente. Tienes una energía creativa inagotable y una voluntad de hierro. No naciste para seguir a otros, sino para abrir nuevos caminos.",
    mission: "Tu misión es desarrollar la confianza en ti mismo y liderar con el ejemplo. Debes aprender a depender de tus propios recursos y a no temer a la soledad en la cima.",
    challenges: "El egoísmo, la impaciencia y la tendencia a dominar a los demás. Debes aprender que un buen líder también sabe escuchar."
  },
  2: {
    title: "El Diplomático Pacificador",
    description: "El Camino de Vida 2 es el del colaborador, el mediador y el amigo leal. Tu fuerza reside en tu sensibilidad y tu capacidad para ver los dos lados de una moneda. Eres el pegamento que mantiene unidos a los grupos.",
    mission: "Tu misión es crear armonía y cooperación en tu entorno. Vienes a enseñar el poder de la empatía, la paciencia y el trabajo en equipo.",
    challenges: "La hipersensibilidad y la tendencia a perderte en las necesidades de los demás. Debes aprender a poner límites y a no depender de la aprobación externa."
  },
  3: {
    title: "El Comunicador Creativo",
    description: "El Camino de Vida 3 es el del artista, el orador y el optimista eterno. Tienes el don de la palabra y la capacidad de inspirar a otros con tu alegría. La vida es tu escenario.",
    mission: "Tu misión es expresarte auténticamente a través del arte, la palabra o la creatividad. Vienes a traer luz y alegría al mundo.",
    challenges: "La dispersión, la superficialidad y el drama emocional. Debes aprender a enfocar tu energía y a no evadir los problemas profundos con humor."
  },
  4: {
    title: "El Constructor Práctico",
    description: "El Camino de Vida 4 es el del trabajador incansable, el organizador y el pilar de la sociedad. Valoras el orden, la estructura y la seguridad. Construyes sobre cimientos sólidos.",
    mission: "Tu misión es crear estabilidad y orden en el caos. Vienes a manifestar resultados tangibles a través del esfuerzo y la disciplina.",
    challenges: "La rigidez, la terquedad y la resistencia al cambio. Debes aprender a ser más flexible y a disfrutar del proceso, no solo del resultado."
  },
  5: {
    title: "El Aventurero Libre",
    description: "El Camino de Vida 5 es el del viajero, el agente de cambio y el amante de la libertad. Necesitas variedad y estimulación constante. Eres adaptable y curioso por naturaleza.",
    mission: "Tu misión es experimentar la libertad en todas sus formas y enseñar a otros a adaptarse al cambio. Vienes a romper estructuras obsoletas.",
    challenges: "La inestabilidad, la irresponsabilidad y el exceso de indulgencia. Debes aprender a comprometerte y a encontrar la libertad dentro de la disciplina."
  },
  6: {
    title: "El Cuidador Responsable",
    description: "El Camino de Vida 6 es el del sanador, el padre/madre y el protector. Tu enfoque está en el hogar, la familia y el servicio a la comunidad. Buscas la armonía y la belleza.",
    mission: "Tu misión es nutrir, proteger y servir a los demás con amor. Vienes a crear hogares y comunidades armoniosas.",
    challenges: "El perfeccionismo, la intromisión y el sacrificio excesivo. Debes aprender que no puedes salvar a todo el mundo y que debes cuidarte a ti mismo primero."
  },
  7: {
    title: "El Buscador Espiritual",
    description: "El Camino de Vida 7 es el del filósofo, el investigador y el místico. Buscas la verdad profunda detrás de las apariencias. Necesitas soledad para procesar tu sabiduría interior.",
    mission: "Tu misión es descubrir las verdades ocultas de la vida y desarrollar tu mente y espíritu. Vienes a ser un puente entre lo material y lo espiritual.",
    challenges: "El aislamiento, el cinismo y la desconexión emocional. Debes aprender a confiar en los demás y a compartir tu sabiduría sin arrogancia."
  },
  8: {
    title: "El Ejecutivo Poderoso",
    description: "El Camino de Vida 8 es el del empresario, el líder financiero y el visionario material. Entiendes el mundo del dinero y el poder. Buscas el éxito y el reconocimiento.",
    mission: "Tu misión es dominar el mundo material y utilizar el poder y la riqueza para el bien común. Vienes a construir imperios éticos.",
    challenges: "El materialismo, la obsesión por el control y la falta de escrúpulos. Debes aprender que el verdadero poder es el servicio."
  },
  9: {
    title: "El Humanitario Universal",
    description: "El Camino de Vida 9 es el del filántropo, el compasivo y el alma vieja. Tu amor abarca a toda la humanidad. Eres idealista y buscas hacer del mundo un lugar mejor.",
    mission: "Tu misión es servir a la humanidad y practicar el amor incondicional. Vienes a cerrar ciclos y a enseñar la compasión universal.",
    challenges: "El resentimiento, el fanatismo y la dificultad para soltar el pasado. Debes aprender a perdonar y a dejar ir."
  },
  11: {
    title: "El Maestro Iluminador",
    description: "El Camino de Vida 11 es un número maestro. Eres un canal de luz e inspiración. Tienes una intuición psíquica y una visión espiritual elevada. Eres un faro para los demás.",
    mission: "Tu misión es inspirar y elevar la conciencia de la humanidad. Vienes a traer revelaciones espirituales.",
    challenges: "La ansiedad nerviosa, la hipersensibilidad y el miedo a tu propio poder. Debes aprender a enraizar tu energía para no quemarte."
  },
  22: {
    title: "El Maestro Constructor",
    description: "El Camino de Vida 22 es el número maestro más poderoso en el plano material. Tienes la visión del 11 y la practicidad del 4. Puedes manifestar sueños imposibles en la realidad.",
    mission: "Tu misión es construir grandes proyectos que beneficien a la humanidad a gran escala. Vienes a dejar un legado tangible y duradero.",
    challenges: "El miedo al fracaso, la presión autoimpuesta y el uso del poder para fines egoístas. Debes aprender a pensar en grande sin perder la ética."
  },
  33: {
    title: "El Maestro Sanador",
    description: "El Camino de Vida 33 es el número del amor crístico y el servicio desinteresado. Es raro y poderoso. Tu capacidad de amar y sanar no tiene límites.",
    mission: "Tu misión es ser un ejemplo de amor incondicional y servicio. Vienes a sanar el corazón del mundo.",
    challenges: "El martirio, la carga emocional excesiva y el olvido de uno mismo. Debes aprender a equilibrar el dar con el recibir."
  }
};

export const soulNumberDB: Record<number, NumerologyProfile> = {
  1: {
    title: "Deseo de Independencia",
    description: "En lo profundo de tu alma, anhelas ser libre, autónomo y reconocido por tus logros individuales. No soportas que te digan qué hacer.",
    desire: "Ser el número uno y dirigir tu propio destino."
  },
  2: {
    title: "Deseo de Amor y Paz",
    description: "Tu alma anhela armonía, compañía y ser amada. Huyes del conflicto y buscas la conexión emocional profunda.",
    desire: "Amar y ser amado en un ambiente de paz."
  },
  3: {
    title: "Deseo de Autoexpresión",
    description: "Tu alma quiere brillar, ser escuchada y disfrutar de la vida. Necesitas expresar tu creatividad para sentirte vivo.",
    desire: "Inspirar alegría y ser reconocido por tu talento."
  },
  4: {
    title: "Deseo de Estabilidad",
    description: "Tu alma busca orden, seguridad y certeza. Te sientes feliz cuando todo está en su lugar y tienes un plan sólido.",
    desire: "Construir un futuro seguro y predecible."
  },
  5: {
    title: "Deseo de Libertad",
    description: "Tu alma grita por aventuras, viajes y nuevas experiencias. Te aterra la rutina y el encierro.",
    desire: "Experimentar todo lo que el mundo tiene para ofrecer sin ataduras."
  },
  6: {
    title: "Deseo de Cuidar",
    description: "Tu alma se realiza sirviendo a los demás, creando un hogar hermoso y protegiendo a tu familia. Necesitas sentirte útil.",
    desire: "Crear armonía y bienestar para tus seres queridos."
  },
  7: {
    title: "Deseo de Sabiduría",
    description: "Tu alma busca respuestas a los grandes misterios. Necesitas tiempo a solas para estudiar, meditar y comprender el universo.",
    desire: "Encontrar la verdad última y la paz interior."
  },
  8: {
    title: "Deseo de Poder y Logro",
    description: "Tu alma quiere conquistar el mundo material, tener éxito financiero y ejercer influencia. No te conformas con poco.",
    desire: "Alcanzar la libertad financiera y el reconocimiento."
  },
  9: {
    title: "Deseo de Bienestar Universal",
    description: "Tu alma es compasiva y quiere sanar al mundo. Te mueven las causas nobles y el amor universal.",
    desire: "Dejar el mundo mejor de lo que lo encontraste."
  },
  11: {
    title: "Deseo de Iluminación",
    description: "Tu alma busca la verdad espiritual y quiere ser un canal de inspiración divina. Sientes que tienes una misión especial.",
    desire: "Elevar la conciencia propia y ajena."
  },
  22: {
    title: "Deseo de Manifestación Global",
    description: "Tu alma quiere dejar una huella tangible y enorme en el mundo. Sueñas con proyectos que cambien la historia.",
    desire: "Convertir grandes ideales en realidades concretas."
  },
  33: {
    title: "Deseo de Sanación Cósmica",
    description: "Tu alma vibra con el amor puro. Quieres ser un bálsamo para el dolor ajeno.",
    desire: "Amar incondicionalmente y sanar a la humanidad."
  }
};

export const personalYearDB: Record<number, NumerologyProfile> = {
  1: {
    title: "Año de Nuevos Comienzos",
    description: "Este es el inicio de un ciclo de 9 años. Es momento de sembrar, iniciar proyectos y tomar decisiones audaces. Lo que empieces ahora definirá tu futuro.",
    focus: "Acción, iniciativa, independencia y nuevos proyectos."
  },
  2: {
    title: "Año de Paciencia y Relaciones",
    description: "Después del impulso del año 1, ahora toca esperar y regar las semillas. Es un año para cooperar, trabajar en pareja y desarrollar la paciencia.",
    focus: "Diplomacia, amor, paciencia y detalles."
  },
  3: {
    title: "Año de Expresión y Alegría",
    description: "Es un año social, creativo y divertido. Las cosas empiezan a brotar. Es momento de disfrutar, viajar y expresarte.",
    focus: "Creatividad, vida social, comunicación y optimismo."
  },
  4: {
    title: "Año de Trabajo y Estructura",
    description: "Toca ponerse serio. Es un año para trabajar duro, organizar tus finanzas y construir cimientos sólidos. No es momento de riesgos.",
    focus: "Disciplina, orden, salud y trabajo duro."
  },
  5: {
    title: "Año de Cambios y Libertad",
    description: "Prepárate para lo inesperado. Es un año de movimiento, viajes y cambios de rumbo. Rompe la rutina y adáptate.",
    focus: "Cambio, aventura, libertad y flexibilidad."
  },
  6: {
    title: "Año de Familia y Responsabilidad",
    description: "El foco vuelve al hogar. Es un año para cuidar de la familia, asumir responsabilidades domésticas y buscar la armonía.",
    focus: "Hogar, familia, servicio y amor."
  },
  7: {
    title: "Año de Introspección y Estudio",
    description: "Es un año sabático para el alma. Momento de estudiar, meditar y estar a solas. No fuerces el éxito material ahora.",
    focus: "Espiritualidad, descanso, análisis y soledad."
  },
  8: {
    title: "Año de Cosecha y Poder",
    description: "Es el año del karma y el dinero. Recogerás lo que has sembrado. Es momento de logros profesionales y éxito financiero.",
    focus: "Dinero, poder, negocios y autoridad."
  },
  9: {
    title: "Año de Cierre y Transformación",
    description: "Es el final del ciclo. Toca soltar lo que ya no sirve, perdonar y limpiar tu vida para prepararte para el nuevo ciclo.",
    focus: "Finales, perdón, limpieza y compasión."
  }
};
