// Base de Datos V8 Ultimate - Astrología y Numerología Profunda
// Interpretaciones detalladas para simular un experto real

export const zodiacSignsV8 = {
  aries: {
    name: "Aries",
    element: "Fuego",
    planet: "Marte",
    traits: ["Valiente", "Impulsivo", "Líder", "Apasionado"],
    description: "Como el primer signo del zodiaco, eres la chispa que enciende el fuego. Tu energía es inagotable y tu coraje legendario. Sin embargo, tu impaciencia puede ser tu talón de Aquiles. Eres un guerrero nato que necesita una causa por la cual luchar.",
    love_style: "En el amor, eres un cazador. Te gusta la conquista y la pasión intensa. Necesitas una pareja que pueda seguir tu ritmo y que no se ofenda por tu franqueza brutal.",
    money_style: "Gastas tan rápido como ganas. Eres excelente para iniciar negocios, pero necesitas ayuda para administrarlos a largo plazo."
  },
  taurus: {
    name: "Tauro",
    element: "Tierra",
    planet: "Venus",
    traits: ["Leal", "Terco", "Sensual", "Práctico"],
    description: "Eres la roca del zodiaco. Tu estabilidad y paciencia son admirables. Amas los placeres sensoriales: buena comida, masajes, lujo. Tu desafío es el cambio; prefieres la seguridad de lo conocido a la incertidumbre de lo nuevo.",
    love_style: "Buscas seguridad y lealtad absoluta. Eres posesivo pero extremadamente cariñoso y sensual. Una vez que te comprometes, es para siempre.",
    money_style: "Eres un imán para el dinero. Sabes ahorrar, invertir y construir patrimonio sólido. La seguridad financiera es tu prioridad."
  },
  gemini: {
    name: "Géminis",
    element: "Aire",
    planet: "Mercurio",
    traits: ["Curioso", "Adaptable", "Comunicativo", "Inquieto"],
    description: "Tu mente es una autopista de información a alta velocidad. Eres el eterno estudiante, curioso por todo pero experto en nada. Tu dualidad te permite ver todos los lados de una situación, pero a veces te cuesta tomar decisiones firmes.",
    love_style: "Necesitas estimulación mental antes que física. Te aburres fácilmente, así que tu pareja debe ser un conversador fascinante y estar dispuesta a la variedad.",
    money_style: "Puedes tener múltiples fuentes de ingreso gracias a tus variados talentos, pero el dinero se te puede ir en caprichos o hobbies pasajeros."
  },
  cancer: {
    name: "Cáncer",
    element: "Agua",
    planet: "La Luna",
    traits: ["Intuitivo", "Protector", "Emocional", "Hogareño"],
    description: "Sientes el mundo con una intensidad que pocos comprenden. Tu caparazón duro es solo para proteger tu interior suave y vulnerable. Eres el cuidador del zodiaco, siempre nutriendo a los demás, pero a veces olvidas nutrirte a ti mismo.",
    love_style: "Buscas un hogar, no solo una pareja. Necesitas seguridad emocional profunda. Cuando amas, lo haces con un instinto maternal/paternal feroz.",
    money_style: "Ahorras por miedo a la inseguridad. Eres prudente y prefieres tener un colchón financiero para proteger a tu familia."
  },
  leo: {
    name: "Leo",
    element: "Fuego",
    planet: "El Sol",
    traits: ["Carismático", "Generoso", "Dramático", "Orgulloso"],
    description: "Naciste para brillar. Tu carisma es magnético y tu corazón generoso. Necesitas ser visto y admirado, no por vanidad, sino porque tu luz está hecha para compartirla. Tu desafío es aprender que no siempre tienes que ser el protagonista.",
    love_style: "Amas con teatralidad y pasión. Eres leal y protector, pero necesitas que tu pareja te adore y te lo demuestre constantemente.",
    money_style: "Te gusta el lujo y la calidad. Eres generoso con tu dinero, a veces demasiado. Crees que siempre habrá más, y usualmente tienes razón."
  },
  virgo: {
    name: "Virgo",
    element: "Tierra",
    planet: "Mercurio",
    traits: ["Analítico", "Perfeccionista", "Servicial", "Crítico"],
    description: "Ves los detalles que todos los demás ignoran. Tu mente analítica busca la perfección y el orden en un mundo caótico. Tu vocación es el servicio y la mejora continua, pero debes tener cuidado de no ser tan duro contigo mismo.",
    love_style: "Demuestras amor con actos de servicio, no con grandes discursos. Buscas una pareja inteligente, limpia y ordenada. Eres exigente pero devoto.",
    money_style: "Eres el mejor administrador del zodiaco. No gastas en tonterías y siempre tienes un plan B financiero. La eficiencia es tu lema."
  },
  libra: {
    name: "Libra",
    element: "Aire",
    planet: "Venus",
    traits: ["Diplomático", "Encantador", "Indeciso", "Justo"],
    description: "Buscas el equilibrio y la armonía por encima de todo. Eres el pacificador natural, capaz de ver el punto de vista de todos. Tu amor por la belleza y el arte es profundo. Tu desafío es aprender a decir 'no' y tomar partido cuando es necesario.",
    love_style: "No sabes vivir sin pareja. El amor es tu estado natural. Buscas una relación de igualdad, romance y belleza estética.",
    money_style: "Gastas en belleza, arte y moda. A veces evitas mirar tus finanzas para no romper tu armonía mental, lo cual puede ser peligroso."
  },
  scorpio: {
    name: "Escorpio",
    element: "Agua",
    planet: "Plutón",
    traits: ["Intenso", "Misterioso", "Apasionado", "Transformador"],
    description: "Eres el signo más intenso y malinterpretado. Vives en las profundidades emocionales donde otros temen entrar. Tienes un poder de transformación y regeneración increíble. Tu mirada penetra el alma y detecta mentiras al instante.",
    love_style: "Todo o nada. Buscas fusión de almas, no citas casuales. Eres celoso y posesivo, pero tu lealtad es inquebrantable si no te traicionan.",
    money_style: "Eres excelente manejando el dinero de otros (inversiones, herencias). Tienes un instinto natural para los negocios y el poder oculto."
  },
  sagittarius: {
    name: "Sagitario",
    element: "Fuego",
    planet: "Júpiter",
    traits: ["Optimista", "Aventurero", "Filosófico", "Independiente"],
    description: "Eres el explorador eterno. Tu flecha siempre apunta a la verdad y al horizonte lejano. Tu optimismo es contagioso y tu sed de conocimiento insaciable. Valoras la libertad por encima de todo; nadie puede enjaularte.",
    love_style: "Necesitas un compañero de aventuras, no un carcelero. El amor debe ser divertido y expansivo. Huyes del drama y la posesividad.",
    money_style: "Confías en que el universo proveerá, y usualmente lo hace. Gastas en experiencias y viajes más que en cosas materiales."
  },
  capricorn: {
    name: "Capricornio",
    element: "Tierra",
    planet: "Saturno",
    traits: ["Ambicioso", "Disciplinado", "Prudente", "Responsable"],
    description: "Eres la cabra que escala la montaña paso a paso. Tu ambición no es por fama, sino por logros reales y tangibles. Eres el adulto del zodiaco, responsable y trabajador incansable. El éxito para ti es una maratón, no un sprint.",
    love_style: "Tomas el amor tan en serio como tu carrera. Buscas una pareja que aporte estatus o estabilidad. No juegas; si te comprometes, es sólido como una roca.",
    money_style: "El dinero es una herramienta de poder y seguridad. Eres frugal y estratégico. Construyes imperios lentamente pero seguros."
  },
  aquarius: {
    name: "Acuario",
    element: "Aire",
    planet: "Urano",
    traits: ["Original", "Humanitario", "Rebelde", "Intelectual"],
    description: "Vives en el futuro. Tu mente visionaria siempre está buscando cómo mejorar la sociedad. Eres el rebelde con causa, diferente a todos y orgulloso de serlo. Valoras la amistad y la comunidad más que el ego individual.",
    love_style: "Necesitas primero ser amigo de tu pareja. Buscas conexión intelectual y libertad. Las emociones pegajosas te asustan; prefieres el amor racional.",
    money_style: "Puedes tener altibajos financieros por tus ideas radicales. A veces te interesa más la causa social que el beneficio económico propio."
  },
  pisces: {
    name: "Piscis",
    element: "Agua",
    planet: "Neptuno",
    traits: ["Soñador", "Empático", "Artístico", "Místico"],
    description: "Vives con un pie en la realidad y otro en el mundo de los sueños. Tu empatía es tan fuerte que absorbes las emociones ajenas como una esponja. Eres el místico y el artista, conectado con lo divino y lo invisible.",
    love_style: "Amas el amor romántico y de cuento de hadas. Te entregas completamente y a veces te pierdes en el otro. Necesitas una pareja que te baje a tierra con suavidad.",
    money_style: "El dinero es un concepto abstracto para ti. Puedes ser muy generoso o muy caótico. Necesitas ayuda práctica para manejar tus finanzas."
  }
};

export const numerologyV8 = {
  lifePath: {
    1: "El Líder: Viniste a aprender a ser independiente y original. Tu misión es abrir caminos nuevos.",
    2: "El Diplomático: Viniste a aprender sobre cooperación y paz. Tu misión es unir a las personas.",
    3: "El Comunicador: Viniste a expresarte y traer alegría. Tu misión es inspirar con tu creatividad.",
    4: "El Constructor: Viniste a trabajar duro y crear bases sólidas. Tu misión es dar estructura y orden.",
    5: "El Aventurero: Viniste a experimentar la libertad y el cambio. Tu misión es adaptarte y explorar.",
    6: "El Cuidador: Viniste a aprender sobre responsabilidad y amor. Tu misión es servir y proteger a la familia.",
    7: "El Buscador: Viniste a analizar y buscar la verdad espiritual. Tu misión es encontrar sabiduría interior.",
    8: "El Ejecutivo: Viniste a manejar poder y dinero. Tu misión es lograr éxito material con ética.",
    9: "El Humanitario: Viniste a cerrar ciclos y ayudar al mundo. Tu misión es el amor universal y la compasión.",
    11: "El Maestro Espiritual (Maestro): Viniste a iluminar a otros con tu intuición elevada.",
    22: "El Maestro Constructor (Maestro): Viniste a materializar grandes sueños para la humanidad.",
    33: "El Maestro Sanador (Maestro): Viniste a sanar con amor incondicional puro."
  }
};
